package com.projectgalen.lib.jpa.utils;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: HibernateUtils.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.enums.JpaState;
import com.projectgalen.lib.jpa.utils.errors.DaoException;
import com.projectgalen.lib.jpa.utils.errors.SvcConstraintViolation;
import com.projectgalen.lib.jpa.utils.interfaces.EntityDoDelegate;
import com.projectgalen.lib.jpa.utils.interfaces.SessionDoDelegate;
import com.projectgalen.lib.jpa.utils.interfaces.SessionGetDelegate;
import com.projectgalen.lib.utils.PGProperties;
import com.projectgalen.lib.utils.reflection.Reflection;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PersistenceException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.exception.ConstraintViolationException;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.projectgalen.lib.utils.U.findNestedCause;

@SuppressWarnings({ "unused", "UnusedReturnValue" })
public class HibernateUtil {
    private static final PGProperties  props = PGProperties.getXMLProperties("settings.xml", HibernateUtil.class);
    private static final ReentrantLock lock  = new ReentrantLock(true);

    private HibernateUtil() { }

    public static void saveChanges(@NotNull JpaBase entity) { saveChanges(entity, true); }

    public static void saveChanges(@NotNull JpaBase entity, boolean deep) {
        withSessionDo((session, tx) -> {
            if(deep) withEntityDo(true, entity, child -> _saveChanges(session, tx, child));
            else _saveChanges(session, tx, entity);
            session.refresh(entity);
        });
        if(deep) withEntityDo(true, entity, child -> child.setJpaState(JpaState.NORMAL));
        else entity.setJpaState(JpaState.NORMAL);
    }

    public static void withEntityDo(@NotNull JpaBase parent, @NotNull EntityDoDelegate<JpaBase> delegate) { withEntityDo(true, parent, delegate); }

    public static void withEntityDo(boolean parentLast, @NotNull JpaBase parent, @NotNull EntityDoDelegate<JpaBase> delegate) {
        if(!parentLast) delegate.action(parent);

        Reflection.forEachField(parent.getClass(), field -> {
            if(field.isAnnotationPresent(ManyToOne.class) && JpaBase.class.isAssignableFrom(field.getType())) {
                try {
                    field.setAccessible(true);
                    JpaBase child = (JpaBase)field.get(parent);
                    if(child != null) withEntityDo(parentLast, child, delegate);
                }
                catch(Exception e) {
                    throw ((e instanceof DaoException) ? ((DaoException)e) : new DaoException(e));
                }
            }
            return false;
        });

        if(parentLast) delegate.action(parent);
    }

    public static void withSessionDo(@NotNull SessionDoDelegate delegate) {
        withSessionGet((session, tx) -> {
            delegate.action(session, tx);
            return null;
        });
    }

    public static <R> R withSessionGet(@NotNull SessionGetDelegate<R> delegate) {
        try(Session session = HibernateSessionFactory.sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            try {
                R result = delegate.get(session, tx);
                session.flush();
                tx.commit();
                return result;
            }
            catch(Throwable t) {
                try { tx.rollback(); } catch(Throwable t2) { t2.printStackTrace(System.err); }
                throw handleErrors(t);
            }
        }
    }

    private static void _saveChanges(@NotNull Session session, @NotNull Transaction tx, @NotNull JpaBase entity) {
        switch(entity.getJpaState()) {
            case DELETED:
            case NEW:
                session.persist(entity);
                break;
            case DIRTY:
                session.merge(entity);
                break;
        }
    }

    private static RuntimeException handleErrors(Throwable t) {
        if(t instanceof PersistenceException) {
            ConstraintViolationException cve = findNestedCause(t, ConstraintViolationException.class);
            if(cve != null) {
                SQLIntegrityConstraintViolationException sicve = findNestedCause(cve.getCause(), SQLIntegrityConstraintViolationException.class);

                if(sicve != null) {
                    Matcher m = Pattern.compile(props.getProperty("pgbudget.dao.dup_key_regexp")).matcher(sicve.getMessage());
                    if(m.matches()) throw new SvcConstraintViolation(m.group(1), m.group(2), m.group(3), cve.getConstraintName());
                }
            }
            throw (PersistenceException)t;
        }

        if(t instanceof Error) throw (Error)t;
        if(t instanceof DaoException) throw (DaoException)t;
        if(t instanceof RuntimeException) throw (RuntimeException)t;
        throw new DaoException(t);
    }

    private static final class HibernateSessionFactory {
        private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    }
}
