package com.projectgalen.lib.utils;

import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.math.BigInteger;

public class PGMath {
    private PGMath() {
    }

    public static @NotNull BigDecimal getBigDecimal(@NotNull Number value) {
        return ((value instanceof BigInteger) ? new BigDecimal((BigInteger)value) : BigDecimal.valueOf(value.doubleValue()));
    }
}
