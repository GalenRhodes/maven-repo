package com.projectgalen.lib.utils;

// ===========================================================================
//     PROJECT: PGUtils
//    FILENAME: PGCalendar.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: May 07, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import org.jetbrains.annotations.NotNull;

import java.util.*;

public class PGCalendar extends GregorianCalendar implements Cloneable {

    public PGCalendar(@NotNull Calendar c) {
        this(c, c.getTimeZone(), Locale.getDefault(Locale.Category.FORMAT));
    }

    public PGCalendar(@NotNull Calendar c, @NotNull TimeZone zone) {
        this(c, zone, Locale.getDefault(Locale.Category.FORMAT));
    }

    public PGCalendar(@NotNull Calendar c, @NotNull TimeZone zone, @NotNull Locale aLocale) {
        this(zone, aLocale);
        setTime(c.getTime());
    }

    public PGCalendar(@NotNull Calendar c, @NotNull Locale aLocale) {
        this(c, c.getTimeZone(), aLocale);
    }

    public PGCalendar() {
        super();
    }

    public PGCalendar(TimeZone zone) {
        super(zone);
    }

    public PGCalendar(Locale aLocale) {
        super(aLocale);
    }

    public PGCalendar(TimeZone zone, Locale aLocale) {
        super(zone, aLocale);
    }

    public PGCalendar(int year, int month, int dayOfMonth) {
        super(year, month, dayOfMonth);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute) {
        super(year, month, dayOfMonth, hourOfDay, minute);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, int second) {
        super(year, month, dayOfMonth, hourOfDay, minute, second);
    }

    public PGCalendar(int year, int month, int dayOfMonth, @NotNull TimeZone zone) {
        super(zone);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, @NotNull TimeZone zone) {
        super(zone);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, int second, @NotNull TimeZone zone) {
        super(zone);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
        set(SECOND, second);
    }

    public PGCalendar(int year, int month, int dayOfMonth, @NotNull Locale aLocale) {
        super(aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, @NotNull Locale aLocale) {
        super(aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, int second, @NotNull Locale aLocale) {
        super(aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
        set(SECOND, second);
    }

    public PGCalendar(int year, int month, int dayOfMonth, @NotNull TimeZone zone, @NotNull Locale aLocale) {
        super(zone, aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, @NotNull TimeZone zone, @NotNull Locale aLocale) {
        super(zone, aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
    }

    public PGCalendar(int year, int month, int dayOfMonth, int hourOfDay, int minute, int second, @NotNull TimeZone zone, @NotNull Locale aLocale) {
        super(zone, aLocale);
        set(YEAR, year);
        set(MONTH, month);
        set(DATE, dayOfMonth);
        set(HOUR_OF_DAY, hourOfDay);
        set(MINUTE, minute);
        set(SECOND, second);
    }

    public PGCalendar(@NotNull Date dt, @NotNull TimeZone zone, @NotNull Locale aLocale) {
        super(zone, aLocale);
        setTime(dt);
    }

    public PGCalendar(@NotNull Date dt) {
        super();
        setTime(dt);
    }

    public PGCalendar(@NotNull Date dt, @NotNull TimeZone zone) {
        super(zone);
        setTime(dt);
    }

    public PGCalendar(@NotNull Date dt, @NotNull Locale aLocale) {
        super(aLocale);
        setTime(dt);
    }

    @Override public PGCalendar clone() {
        return (PGCalendar)super.clone();
    }

    public int getAMPM() { return get(Calendar.AM_PM); }

    public int getAMPMHour() { return get(Calendar.HOUR); }

    public int getDate() { return get(Calendar.DATE); }

    public int getDayOfWeek() { return get(Calendar.DAY_OF_WEEK); }

    public int getDstOffset() { return get(Calendar.DST_OFFSET); }

    public int getHour() { return get(Calendar.HOUR_OF_DAY); }

    public int getMillisecond() { return get(Calendar.MILLISECOND); }

    public int getMinute() { return get(Calendar.MINUTE); }

    public int getMonth() { return get(Calendar.MONTH); }

    public int getSecond() { return get(Calendar.SECOND); }

    public int getYear() { return get(Calendar.YEAR); }

    public void setAMPM(int value) { set(Calendar.AM_PM, value); }

    public void setAMPMHour(int value) { set(Calendar.HOUR, value); }

    public void setDate(int value) { set(Calendar.DATE, value); }

    public void setDayOfWeek(int value) { set(Calendar.DAY_OF_WEEK, value); }

    public void setDstOffset(int value) { set(Calendar.DST_OFFSET, value); }

    public void setHour(int value) { set(Calendar.HOUR_OF_DAY, value); }

    public void setMillisecond(int value) { set(Calendar.MILLISECOND, value); }

    public void setMinute(int value) { set(Calendar.MINUTE, value); }

    public void setMonth(int value) { set(Calendar.MONTH, value); }

    public void setSecond(int value) { set(Calendar.SECOND, value); }

    public void setYear(int value) { set(Calendar.YEAR, value); }
}
