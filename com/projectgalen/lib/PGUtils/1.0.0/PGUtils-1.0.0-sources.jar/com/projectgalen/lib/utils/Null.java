package com.projectgalen.lib.utils;

import org.jetbrains.annotations.NotNull;

public class Null {
    private Null() {
    }

    @Override public String toString() {
        return "null";
    }

    public static Null NULL() {
        return NullHolder.INSTANCE;
    }

    public static <T> T get(@NotNull Object o) {
        if(NULL().equals(o)) return null;
        //noinspection unchecked
        return (T)o;
    }

    private static final class NullHolder {
        private static final Null INSTANCE = new Null();
    }
}
