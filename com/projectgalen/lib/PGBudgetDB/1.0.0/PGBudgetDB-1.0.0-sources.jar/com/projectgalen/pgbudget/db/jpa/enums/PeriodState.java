package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: PeriodState.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: May 05, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.pgbudget.db.C;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Range;

public enum PeriodState {

    NONE(-2), FUTURE(-1), IN_PROGRESS(0), CLOSED(1);

    @Range(from = -1, to = 1) private final int id;

    PeriodState(@Range(from = -1, to = 1) int id) {
        this.id = id;
    }

    public @Range(from = -1, to = 1) int getId() { return id; }

    @Override public @NotNull String toString() {
        return C.msgs.getString(String.format("enum.period_state.name.%d", id + 2));
    }

    public static @NotNull PeriodState getPeriodState(@Range(from = -1, to = 1) int id) {
        for(PeriodState e : PeriodState.values()) if(e.id == id) return e;
        throw new IllegalArgumentException(String.format("Not a valid %s ID: %d", "Period State", id));
    }
}
