package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: OtherPeriodDatesEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.OtherPeriodDatesEntity;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
@SuppressWarnings("unused")
public class _OtherPeriodDatesEntity extends JpaBase {

    protected @Column(name = "date_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         dateId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                       Long         budgetId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State        state;
    protected @Column(name = "other_date", nullable = false)                                                                                                             Date         otherDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                             BudgetEntity toBudget;

    protected _OtherPeriodDatesEntity() { }

    protected _OtherPeriodDatesEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof OtherPeriodDatesEntity) && _equals((OtherPeriodDatesEntity)o))));
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Long getDateId() {
        return Locks.getWithLock(lock, () -> this.dateId);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Date getOtherDate() {
        return Locks.getWithLock(lock, () -> this.otherDate);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public BudgetEntity getToBudget() {
        return Locks.getWithLock(lock, () -> this.toBudget);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(dateId, budgetId, state, otherDate, dateCreated, dateUpdated));
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setOtherDate(@NotNull Date otherDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.otherDate, otherDate)) {
                this.otherDate = otherDate;
                addValueToChangeMap("otherDate", this.otherDate);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToBudget(BudgetEntity toBudget) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toBudget, toBudget)) {
                this.toBudget = toBudget;
                addValueToChangeMap("budgetId", this.budgetId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull OtherPeriodDatesEntity other) {/*@f0*/
        return (Objects.equals(dateId, other.dateId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(state, other.state)
                && Objects.equals(otherDate, other.otherDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
