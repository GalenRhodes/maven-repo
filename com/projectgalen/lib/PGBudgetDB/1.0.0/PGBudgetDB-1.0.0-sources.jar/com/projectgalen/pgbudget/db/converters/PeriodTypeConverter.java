package com.projectgalen.pgbudget.db.converters;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: PeriodTypeConverter.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.EnumConverter;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import org.jetbrains.annotations.NotNull;

public class PeriodTypeConverter extends EnumConverter<PeriodType, Integer> {

    public PeriodTypeConverter() {
        this(PeriodType.OTHER);
    }

    public PeriodTypeConverter(@NotNull PeriodType defaultValue) {
        super(defaultValue.getId());
    }

    @Override
    public PeriodType[] getList() {
        return PeriodType.values();
    }

    @Override
    public Integer getValue(@NotNull PeriodType attribute) {
        return attribute.getId();
    }
}
