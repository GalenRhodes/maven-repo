package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "period", schema = "pgbudget")
public class PeriodEntity extends JpaBase {
    private @Column(name = "period_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY)                Long                           periodId;
    private @Column(name = "budget_id", precision = 19, scale = 0)                                                                        Long                           budgetId;
    private @Column(name = "kv_id", precision = 19, scale = 0)                                                                            Long                           kvId;
    private @Column(name = "prev_period_id", nullable = true, precision = 19, scale = 0)                                                  Long                           prevPeriodId;
    private @Column(name = "next_period_id", nullable = true, precision = 19, scale = 0)                                                  Long                           nextPeriodId;
    private @Column(name = "period_date")                                                                                                 Date                           periodDate;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                          state;
    private @Column(name = "roll_over_amount", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                              BigDecimal                     rollOverAmount;
    private @Column(name = "remaining_amount", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                              BigDecimal                     remainingAmount;
    private @Column(name = "total_income", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                  BigDecimal                     totalIncome;
    private @Column(name = "total_debit", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                   BigDecimal                     totalDebit;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp                      dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp                      dateUpdated;
    private @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                BudgetEntity                   toBudget;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                        KvInfoEntity                   toKv;
    private @ManyToOne @JoinColumn(name = "prev_period_id", referencedColumnName = "period_id")                                           PeriodEntity                   toPrevPeriod;
    private @ManyToOne @JoinColumn(name = "next_period_id", referencedColumnName = "period_id")                                           PeriodEntity                   toNextPeriod;
    private @OneToMany(mappedBy = "toPeriod", fetch = FetchType.LAZY)                                                                     Collection<PeriodIncomeEntity> toPeriodIncomes;
    private @OneToMany(mappedBy = "toPeriod", fetch = FetchType.LAZY)                                                                     Collection<PeriodItemEntity>   toPeriodItems;

    public PeriodEntity() { }

    public PeriodEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state           = State.ACTIVE;
        this.rollOverAmount  = BigDecimal.ZERO;
        this.remainingAmount = BigDecimal.ZERO;
        this.totalIncome     = BigDecimal.ZERO;
        this.totalDebit      = BigDecimal.ZERO;
        this.dateCreated     = Dates.getTimestamp();
        this.dateUpdated     = Dates.getTimestamp();
    }

    public Long getPeriodId() {
        return this.periodId;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Long getNextPeriodId() {
        return this.nextPeriodId;
    }

    public Date getPeriodDate() {
        return this.periodDate;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public BigDecimal getRollOverAmount() {
        return this.rollOverAmount;
    }

    public BigDecimal getRemainingAmount() {
        return this.remainingAmount;
    }

    public Long getPrevPeriodId() {
        return this.prevPeriodId;
    }

    public State getState() {
        return this.state;
    }

    public Collection<PeriodIncomeEntity> getToPeriodIncomes() {
        return Collections.unmodifiableCollection(this.toPeriodIncomes);
    }

    public Collection<PeriodItemEntity> getToPeriodItems() {
        return Collections.unmodifiableCollection(this.toPeriodItems);
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public PeriodEntity getToPrevPeriod() {
        return this.toPrevPeriod;
    }

    public PeriodEntity getToNextPeriod() {
        return this.toNextPeriod;
    }

    public BigDecimal getTotalDebit() {
        return this.totalDebit;
    }

    public BigDecimal getTotalIncome() {
        return this.totalIncome;
    }

    public void setBudgetId(@NotNull Long budgetId) {
        if(Objects.equals(this.budgetId, budgetId)) return;
        this.budgetId = budgetId;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setNextPeriodId(@Nullable Long nextPeriodId) {
        if(Objects.equals(this.nextPeriodId, nextPeriodId)) return;
        this.nextPeriodId = nextPeriodId;
        setAsDirty();
    }

    public void setPeriodDate(@NotNull Date periodDate) {
        if(Objects.equals(this.periodDate, periodDate)) return;
        this.periodDate = periodDate;
        setAsDirty();
    }

    public void setPeriodId(@NotNull Long periodId) {
        if(Objects.equals(this.periodId, periodId)) return;
        this.periodId = periodId;
        setAsDirty();
    }

    public void setPrevPeriodId(@Nullable Long prevPeriodId) {
        if(Objects.equals(this.prevPeriodId, prevPeriodId)) return;
        this.prevPeriodId = prevPeriodId;
        setAsDirty();
    }

    public void setRemainingAmount(@NotNull BigDecimal remainingAmount) {
        if(Objects.equals(this.remainingAmount, remainingAmount)) return;
        this.remainingAmount = remainingAmount;
        setAsDirty();
    }

    public void setRollOverAmount(@NotNull BigDecimal rollOverAmount) {
        if(Objects.equals(this.rollOverAmount, rollOverAmount)) return;
        this.rollOverAmount = rollOverAmount;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void setToNextPeriod(PeriodEntity toNextPeriod) {
        if(Objects.equals(this.toNextPeriod, toNextPeriod)) return;
        this.toNextPeriod = toNextPeriod;
        setAsDirty();
    }

    public void setToPrevPeriod(PeriodEntity toPrevPeriod) {
        if(Objects.equals(this.toPrevPeriod, toPrevPeriod)) return;
        this.toPrevPeriod = toPrevPeriod;
        setAsDirty();
    }

    public void setTotalDebit(@NotNull BigDecimal totalDebit) {
        if(Objects.equals(this.totalDebit, totalDebit)) return;
        this.totalDebit = totalDebit;
        setAsDirty();
    }

    public void setTotalIncome(@NotNull BigDecimal totalIncome) {
        if(Objects.equals(this.totalIncome, totalIncome)) return;
        this.totalIncome = totalIncome;
        setAsDirty();
    }

    public void addToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(Objects.equals(object.getToPeriod(), this)) return;
        if(object.getToPeriod() != null) object.getToPeriod().removeFromToPeriodIncomes(object);
        object.setToPeriod(this);
        if(!this.toPeriodIncomes.contains(object)) this.toPeriodIncomes.add(object);
        setAsDirty();
    }

    public void addToPeriodItems(@NotNull PeriodItemEntity object) {
        if(Objects.equals(object.getToPeriod(), this)) return;
        if(object.getToPeriod() != null) object.getToPeriod().removeFromToPeriodItems(object);
        object.setToPeriod(this);
        if(!this.toPeriodItems.contains(object)) this.toPeriodItems.add(object);
        setAsDirty();
    }

    public void removeFromToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(!Objects.equals(object.getToPeriod(), this)) return;
        object.setToPeriod(null);
        this.toPeriodIncomes.remove(object);
        setAsDirty();
    }

    public void removeFromToPeriodItems(@NotNull PeriodItemEntity object) {
        if(!Objects.equals(object.getToPeriod(), this)) return;
        object.setToPeriod(null);
        this.toPeriodItems.remove(object);
        setAsDirty();
    }
}
