package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.jpa.base._PeriodEntity;
import com.projectgalen.pgbudget.db.jpa.dao.PeriodEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodState;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = PeriodEntityDao.class)
@Entity
@Table(name = "period", schema = "pgbudget")
public class PeriodEntity extends _PeriodEntity {

    protected PeriodEntity() {
        super();
    }

    protected PeriodEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    @Contract("_, _ -> new")
    public static @NotNull PeriodEntity createPeriodEntity(@NotNull BudgetEntity budget, @NotNull Date dt) {
        return createPeriodEntity(budget, dt, null, null, null, null);
    }

    public static @NotNull PeriodEntity createPeriodEntity(@NotNull BudgetEntity budget,
                                                           @NotNull Date dt,
                                                           double incomeAmount,
                                                           double rollOverAmount,
                                                           double totalDebitAmount, double remainingAmount) {
        return createPeriodEntity(budget, dt, BigDecimal.valueOf(incomeAmount), BigDecimal.valueOf(rollOverAmount), BigDecimal.valueOf(totalDebitAmount), BigDecimal.valueOf(remainingAmount));
    }

    @Contract("_, _, _, _, _, _ -> new")
    public static @NotNull PeriodEntity createPeriodEntity(@NotNull BudgetEntity budget,
                                                           @NotNull Date dt,
                                                           BigDecimal incomeAmount,
                                                           BigDecimal rollOverAmount,
                                                           BigDecimal totalDebitAmount, BigDecimal remainingAmount) {
        PeriodEntity period = createPeriodEntity();
        period.setToBudget(budget);
        period.setPeriodDate(Dates.toSQLDate(dt));
        period.setTotalIncome(Objects.requireNonNullElse(incomeAmount, BigDecimal.ZERO));
        period.setRollOverAmount(Objects.requireNonNullElse(rollOverAmount, BigDecimal.ZERO));
        period.setRemainingAmount(Objects.requireNonNullElse(remainingAmount, BigDecimal.ZERO));
        period.setTotalDebit(Objects.requireNonNullElse(totalDebitAmount, BigDecimal.ZERO));
        return period;
    }

    @Contract(" -> new")
    public static @NotNull PeriodEntity createPeriodEntity() {
        PeriodEntity e = new PeriodEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        e.setPeriodState(PeriodState.NONE);
        return e;
    }
}
