package com.projectgalen.pgbudget.db.converters;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: StateConverter.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.EnumConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Converter;
import org.jetbrains.annotations.NotNull;

@Converter(autoApply = true)
public class StateConverter extends EnumConverter<State, Integer> {
    public StateConverter() {
        this(State.ACTIVE);
    }

    public StateConverter(@NotNull State defaultValue) {
        super(defaultValue.getValue());
    }

    @Override
    public State[] getList() {
        return State.values();
    }

    @Override
    public Integer getValue(@NotNull State attribute) {
        return attribute.getValue();
    }
}
