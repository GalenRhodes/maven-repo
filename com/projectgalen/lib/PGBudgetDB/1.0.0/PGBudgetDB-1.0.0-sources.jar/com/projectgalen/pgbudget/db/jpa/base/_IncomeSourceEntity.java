package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 24, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.dao.IncomeSourceEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _IncomeSourceEntity extends JpaBase {
    protected @Column(name = "income_source_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                           incomeSourceId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                                Long                           budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                                    Long                           kvId;
    protected @Column(name = "source_name", nullable = false, length = 255)                                                                                                                  String                         sourceName;
    protected @Column(name = "state", nullable = false, precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                                State                          state;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                                       BigDecimal                     amount;
    protected @Column(name = "start_date")                                                                                                                                                   Date                           startDate;
    protected @Column(name = "end_date")                                                                                                                                                     Date                           endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                           Timestamp                      dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                           Timestamp                      dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                                                 BudgetEntity                   toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                                         KvInfoEntity                   toKeyValueInfo;
    protected @OneToMany(mappedBy = "toIncomeSource", fetch = FetchType.LAZY)                                                                                                                Collection<PeriodIncomeEntity> toPeriodIncomes;
    protected @OneToMany(mappedBy = "toIncomeSource", fetch = FetchType.LAZY)                                                                                                                Collection<PeriodItemEntity>   toPeriodItems;

    public _IncomeSourceEntity() { }

    public _IncomeSourceEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.amount      = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public void addToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(Objects.equals(object.getToIncomeSource(), this)) return;
        if(object.getToIncomeSource() != null) object.getToIncomeSource().removeFromToPeriodIncomes(object);
        object.setToIncomeSource((IncomeSourceEntity)this);
        if(!this.toPeriodIncomes.contains(object)) this.toPeriodIncomes.add(object);
        setAsDirty();
    }

    public void addToPeriodItems(@NotNull PeriodItemEntity object) {
        if(Objects.equals(object.getToIncomeSource(), this)) return;
        if(object.getToIncomeSource() != null) object.getToIncomeSource().removeFromToPeriodItems(object);
        object.setToIncomeSource((IncomeSourceEntity)this);
        if(!this.toPeriodItems.contains(object)) this.toPeriodItems.add(object);
        setAsDirty();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof IncomeSourceEntity) && _equals((IncomeSourceEntity)o)));
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public Long getIncomeSourceId() {
        return this.incomeSourceId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getSourceName() {
        return this.sourceName;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public State getState() {
        return this.state;
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public Collection<PeriodIncomeEntity> getToPeriodIncomes() {
        return Collections.unmodifiableCollection(this.toPeriodIncomes);
    }

    public Collection<PeriodItemEntity> getToPeriodItems() {
        return Collections.unmodifiableCollection(this.toPeriodItems);
    }

    @Override
    public int hashCode() {
        return Objects.hash(incomeSourceId, budgetId, kvId, sourceName, state, amount, startDate, endDate, dateCreated, dateUpdated);
    }

    public void removeFromToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(!Objects.equals(object.getToIncomeSource(), this)) return;
        object.setToIncomeSource(null);
        this.toPeriodIncomes.remove(object);
        setAsDirty();
    }

    public void removeFromToPeriodItems(@NotNull PeriodItemEntity object) {
        if(!Objects.equals(object.getToIncomeSource(), this)) return;
        object.setToIncomeSource(null);
        this.toPeriodItems.remove(object);
        setAsDirty();
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setEndDate(@Nullable Date endDate) {
        if(Objects.equals(this.endDate, endDate)) return;
        this.endDate = endDate;
        setAsDirty();
    }

    public void setSourceName(@NotNull String sourceName) {
        if(Objects.equals(this.sourceName, sourceName)) return;
        this.sourceName = sourceName;
        setAsDirty();
    }

    public void setStartDate(@Nullable Date startDate) {
        if(Objects.equals(this.startDate, startDate)) return;
        this.startDate = startDate;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    private boolean _equals(@NotNull IncomeSourceEntity other) {/*@f0*/
        return (Objects.equals(incomeSourceId, other.incomeSourceId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(sourceName, other.sourceName)
                && Objects.equals(state, other.state)
                && Objects.equals(amount, other.amount)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/

    @Contract(pure = true)
    public static @NotNull IncomeSourceEntityDao getDao() {
        return IncomeSourceEntityDao.shared();
    }
}
