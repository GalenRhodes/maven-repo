package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.converters.BooleanConverter;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.IncomeSourceEntity;
import com.projectgalen.pgbudget.db.jpa.KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.PeriodIncomeEntity;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _IncomeSourceEntity extends JpaBase {

    protected @Column(name = "income_source_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         incomeSourceId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                                Long         budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                                    Long         kvId;
    protected @Column(name = "source_name", nullable = false)                                                                                                                     String       sourceName;
    protected @Column(name = "is_default", nullable = false, precision = 5) @Convert(converter = BooleanConverter.class) @PGDefaultValue("false")                                 Boolean      isDefault;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                                State        state;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                            BigDecimal   amount;
    protected @Column(name = "start_date")                                                                                                                                        Date         startDate;
    protected @Column(name = "end_date")                                                                                                                                          Date         endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                                      BudgetEntity toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                              KvInfoEntity toKeyValueInfo;

    protected _IncomeSourceEntity() { }

    protected _IncomeSourceEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.isDefault = false;
        this.state = State.ACTIVE;
        this.amount = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof IncomeSourceEntity) && _equals((IncomeSourceEntity)o))));
    }

    public BigDecimal getAmount() {
        return Locks.getWithLock(lock, () -> this.amount);
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Date getEndDate() {
        return Locks.getWithLock(lock, () -> this.endDate);
    }

    public Long getIncomeSourceId() {
        return Locks.getWithLock(lock, () -> this.incomeSourceId);
    }

    public Boolean getIsDefault() {
        return Locks.getWithLock(lock, () -> this.isDefault);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public String getSourceName() {
        return Locks.getWithLock(lock, () -> this.sourceName);
    }

    public Date getStartDate() {
        return Locks.getWithLock(lock, () -> this.startDate);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public BudgetEntity getToBudget() {
        return Locks.getWithLock(lock, () -> this.toBudget);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<PeriodIncomeEntity> getToPeriodIncomes() {
        return HibernateUtil.find(PeriodIncomeEntity.class, wrap("toIncomeSource"), wrap(this));
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(incomeSourceId, budgetId, kvId, sourceName, isDefault, state, amount, startDate, endDate, dateCreated, dateUpdated));
    }

    public void setAmount(@NotNull BigDecimal amount) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.amount, amount)) {
                this.amount = amount;
                addValueToChangeMap("amount", this.amount);
                setAsDirty();
            }
        });
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setEndDate(@Nullable Date endDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.endDate, endDate)) {
                this.endDate = endDate;
                addValueToChangeMap("endDate", this.endDate);
                setAsDirty();
            }
        });
    }

    public void setIsDefault(@NotNull Boolean isDefault) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.isDefault, isDefault)) {
                this.isDefault = isDefault;
                addValueToChangeMap("isDefault", this.isDefault);
                setAsDirty();
            }
        });
    }

    public void setSourceName(@NotNull String sourceName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.sourceName, sourceName)) {
                this.sourceName = sourceName;
                addValueToChangeMap("sourceName", this.sourceName);
                setAsDirty();
            }
        });
    }

    public void setStartDate(@Nullable Date startDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.startDate, startDate)) {
                this.startDate = startDate;
                addValueToChangeMap("startDate", this.startDate);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToBudget(BudgetEntity toBudget) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toBudget, toBudget)) {
                this.toBudget = toBudget;
                addValueToChangeMap("budgetId", this.budgetId);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull IncomeSourceEntity other) {/*@f0*/
        return (Objects.equals(incomeSourceId, other.incomeSourceId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(sourceName, other.sourceName)
                && Objects.equals(isDefault, other.isDefault)
                && Objects.equals(state, other.state)
                && Objects.equals(amount, other.amount)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
