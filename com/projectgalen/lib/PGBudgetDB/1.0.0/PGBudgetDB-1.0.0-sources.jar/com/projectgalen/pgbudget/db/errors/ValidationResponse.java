package com.projectgalen.pgbudget.db.errors;

// ===========================================================================
//     PROJECT: PGBudget
//    FILENAME: ValidationResponse.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: May 04, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.utils.U;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class ValidationResponse {
    private final boolean isValid;
    private final String  message;

    public ValidationResponse() {
        this(true, null);
    }

    public ValidationResponse(@NotNull String message) {
        this(false, message);
    }

    public ValidationResponse(boolean isValid, @Nullable String message) {
        this.isValid = isValid;
        this.message = (U.nz(message) ? message : (isValid ? "OKAY" : "ERROR"));
    }

    @Override public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof ValidationResponse)) return false;
        ValidationResponse that = (ValidationResponse)o;
        return isValid == that.isValid && Objects.equals(message, that.message);
    }

    public String getMessage() {
        return message;
    }

    @Override public int hashCode() {
        return Objects.hash(isValid, message);
    }

    public boolean isValid() {
        return isValid;
    }
}
