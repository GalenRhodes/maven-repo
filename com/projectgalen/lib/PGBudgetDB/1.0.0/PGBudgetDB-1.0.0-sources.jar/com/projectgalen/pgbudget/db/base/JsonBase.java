package com.projectgalen.pgbudget.db.base;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: JsonBase.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 23, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.annotations.PGJSON;

import java.util.Objects;

@PGJSON
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JsonBase {

    protected @JsonProperty("isNew")   boolean isNew;
    protected @JsonProperty("isDirty") boolean isDirty;

    public JsonBase() {
    }

    @Override
    public boolean equals(Object o) {
        return ((this == o) || ((o instanceof JpaBase) && _equals((JpaBase)o)));
    }

    @Override
    public int hashCode() {
        return Objects.hash(isNew, isDirty);
    }

    public @JsonIgnore boolean isDirty() {
        return isDirty;
    }

    public @JsonIgnore boolean isNew() {
        return isNew;
    }

    public @JsonIgnore void setDirty(boolean dirty) {
        isDirty = dirty;
    }

    public @JsonIgnore void setNew(boolean aNew) {
        isNew = aNew;
    }

    private boolean _equals(JpaBase jpaBase) {
        return ((isNew == jpaBase.isNew()) && (isDirty == jpaBase.isDirty()));
    }
}
