package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvDataEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 9, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.KvDataEntity;
import com.projectgalen.pgbudget.db.jpa.KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _KvDataEntity extends JpaBase {

    protected @Column(name = "kv_data_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         kvDataId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                              Long         kvId;
    protected @Column(name = "kv_key", nullable = false)                                                                                                                    String       kvKey;
    protected @Column(name = "kv_value", nullable = false)                                                                                                                  String       kvValue;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                          State        state;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                        KvInfoEntity toKeyValueInfo;

    protected _KvDataEntity() { }

    protected _KvDataEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getKvDataId() {
        return this.kvDataId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getKvKey() {
        return this.kvKey;
    }

    public String getKvValue() {
        return this.kvValue;
    }

    public State getState() {
        return this.state;
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof KvDataEntity) && _equals((KvDataEntity)o)));
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public void setKvKey(@NotNull String kvKey) {
        if(Objects.equals(this.kvKey, kvKey)) return;
        this.kvKey = kvKey;
        setAsDirty();
    }

    public void setKvValue(@NotNull String kvValue) {
        if(Objects.equals(this.kvValue, kvValue)) return;
        this.kvValue = kvValue;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    @Override
    public int hashCode() {
        return Objects.hash(kvDataId, kvId, kvKey, kvValue, state, dateCreated, dateUpdated);
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    private boolean _equals(@NotNull KvDataEntity other) {/*@f0*/
        return (Objects.equals(kvDataId, other.kvDataId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(kvKey, other.kvKey)
                && Objects.equals(kvValue, other.kvValue)
                && Objects.equals(state, other.state)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
