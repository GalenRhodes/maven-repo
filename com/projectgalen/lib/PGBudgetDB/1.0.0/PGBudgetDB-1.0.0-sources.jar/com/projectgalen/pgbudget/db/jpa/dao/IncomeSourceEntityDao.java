package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 7, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.pgbudget.db.jpa.IncomeSourceEntity;
import org.jetbrains.annotations.NotNull;

public final class IncomeSourceEntityDao extends AbstractDao<IncomeSourceEntity> {

    private IncomeSourceEntityDao() {
        super(IncomeSourceEntity.class);
    }

    @Override
    public @NotNull IncomeSourceEntity getNewEntity() {
        return super.getNewEntity();
    }

    public static @NotNull IncomeSourceEntityDao getInstance() {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        private static final IncomeSourceEntityDao INSTANCE = new IncomeSourceEntityDao();
    }
}
