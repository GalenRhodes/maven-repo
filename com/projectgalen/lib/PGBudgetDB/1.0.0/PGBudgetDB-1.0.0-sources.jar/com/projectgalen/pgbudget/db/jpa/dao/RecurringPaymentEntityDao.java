package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.pgbudget.db.jpa.RecurringPaymentEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RecurringPaymentEntityDao extends AbstractDao<RecurringPaymentEntity> {

    private RecurringPaymentEntityDao() {
        super(RecurringPaymentEntity.class);
    }

    public static void create(RecurringPaymentEntity entity) {
        Holder.INSTANCE._create(entity);
    }

    public static @NotNull RecurringPaymentEntity getNewEntity() {
        return Holder.INSTANCE._getNewEntity();
    }

    public static void delete(@NotNull RecurringPaymentEntity entity) {
        Holder.INSTANCE._delete(entity);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString) {
        return Holder.INSTANCE._find(queryString, null, true);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, boolean initializeResults) {
        return Holder.INSTANCE._find(queryString, null, initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters) {
        return Holder.INSTANCE._find(queryString, parameters, true);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters, boolean initializeResults) {
        return Holder.INSTANCE._find(queryString, parameters, initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> findAll(boolean initializeResults) {
        return Holder.INSTANCE._findAll(initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> findAll() {
        return Holder.INSTANCE._findAll(true);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @NotNull QueryAction<RecurringPaymentEntity, R> queryAction) {
        return Holder.INSTANCE._findWithAction(queryString, null, queryAction);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @Nullable Map<String, Object> parameters, @NotNull QueryAction<RecurringPaymentEntity, R> queryAction) {
        return Holder.INSTANCE._findWithAction(queryString, parameters, queryAction);
    }

    public static @Nullable RecurringPaymentEntity get(@NotNull Long paymentId) {
        String              queryString = "from RecurringPaymentEntity e where e.paymentId = :VAL1";
        Map<String, Object> params      = new LinkedHashMap<>();

        params.put("VAL1", paymentId);
        return Holder.INSTANCE._findWithAction(queryString, params, query -> Holder.INSTANCE.init(query.uniqueResult()));
    }

    public static @Nullable RecurringPaymentEntity get(@NotNull String searchField, @NotNull Object searchValue) {
        return Holder.INSTANCE._get(searchField, searchValue);
    }

    public static void update(@NotNull RecurringPaymentEntity entity) {
        Holder.INSTANCE._update(entity);
    }

    public static <R> R withSessionGet(@NotNull SessionAction<R> delegate) {
        return Holder.INSTANCE._withSessionGet(delegate);
    }

    public static void withSessionUpdate(@NotNull SessionUpdateAction delegate) {
        Holder.INSTANCE._withSessionUpdate(delegate, null);
    }

    public static void withSessionUpdate(@NotNull SessionUpdateAction delegate, @Nullable SessionPostCommitAction postCommitDelegate) {
        Holder.INSTANCE._withSessionUpdate(delegate, postCommitDelegate);
    }

    public static @NotNull RecurringPaymentEntityDao shared() {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        private static final RecurringPaymentEntityDao INSTANCE = new RecurringPaymentEntityDao();
    }
}
