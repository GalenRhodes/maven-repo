package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.jpa.RecurringPaymentEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

public final class RecurringPaymentEntityDao extends AbstractDao<RecurringPaymentEntity> {

    private RecurringPaymentEntityDao() {
        super(RecurringPaymentEntity.class);
    }

    public static @NotNull RecurringPaymentEntity getNewEntity() {
        return shared()._getNewEntity();
    }

    public static void create(RecurringPaymentEntity entity) {
        shared()._create(entity, true);
    }

    public static void create(RecurringPaymentEntity entity, boolean deep) {
        shared()._create(entity, deep);
    }

    public static void delete(@NotNull RecurringPaymentEntity entity) {
        shared()._delete(entity);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString) {
        return shared()._find(queryString, null, true);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, boolean initializeResults) {
        return shared()._find(queryString, null, initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters) {
        return shared()._find(queryString, parameters, true);
    }

    public static @NotNull List<RecurringPaymentEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters, boolean initializeResults) {
        return shared()._find(queryString, parameters, initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> findAll(boolean initializeResults) {
        return shared()._findAll(initializeResults);
    }

    public static @NotNull List<RecurringPaymentEntity> findAll() {
        return shared()._findAll(true);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @NotNull QueryAction<RecurringPaymentEntity, R> queryAction) {
        return shared()._findWithAction(queryString, null, queryAction);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @Nullable Map<String, Object> parameters, @NotNull QueryAction<RecurringPaymentEntity, R> queryAction) {
        return shared()._findWithAction(queryString, parameters, queryAction);
    }

    public static @Nullable RecurringPaymentEntity get(@NotNull Long paymentId) {
        return shared()._get(U.asArray("paymentId"), U.asArray(paymentId));
    }

    public static @Nullable RecurringPaymentEntity get(@NotNull String searchField, @NotNull Object searchValue) {
        return shared()._get(searchField, searchValue);
    }

    public static @NotNull RecurringPaymentEntityDao shared() {
        return Holder.INSTANCE;
    }

    public static void update(@NotNull RecurringPaymentEntity entity) {
        shared()._update(entity, true);
    }

    public static void update(@NotNull RecurringPaymentEntity entity, boolean deep) {
        shared()._update(entity, deep);
    }

    public static <R> R withSessionGet(@NotNull SessionAction<R> delegate) {
        return shared()._withSessionGet(delegate);
    }

    public static void withSessionUpdate(@NotNull SessionUpdateAction delegate) {
        shared()._withSessionUpdate(delegate);
    }

    private static final class Holder {
        private static final RecurringPaymentEntityDao INSTANCE = new RecurringPaymentEntityDao();
    }
}
