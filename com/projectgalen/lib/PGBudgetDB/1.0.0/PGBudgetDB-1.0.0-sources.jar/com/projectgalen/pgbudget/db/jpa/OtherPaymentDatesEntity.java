package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: OtherPaymentDatesEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 4, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.jpa.base._OtherPaymentDatesEntity;
import com.projectgalen.pgbudget.db.jpa.dao.OtherPaymentDatesEntityDao;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

@PGJPA(daoClass = OtherPaymentDatesEntityDao.class)
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Entity
@Table(name = "other_payment_dates", schema = "pgbudget")
public class OtherPaymentDatesEntity extends _OtherPaymentDatesEntity {

    protected OtherPaymentDatesEntity() { super(); }

    protected OtherPaymentDatesEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    @Contract(" -> new")
    public static @NotNull OtherPaymentDatesEntity getNewEntity() {
        return new OtherPaymentDatesEntity(false);
    }
}
