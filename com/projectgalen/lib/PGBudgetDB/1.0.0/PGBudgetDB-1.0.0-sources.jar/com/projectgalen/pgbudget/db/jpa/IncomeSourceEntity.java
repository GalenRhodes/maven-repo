package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.jpa.base._IncomeSourceEntity;
import com.projectgalen.pgbudget.db.jpa.dao.IncomeSourceEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = IncomeSourceEntityDao.class)
@Entity
@Table(name = "income_source", schema = "pgbudget")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class IncomeSourceEntity extends _IncomeSourceEntity {

    protected IncomeSourceEntity() { super(); }

    protected IncomeSourceEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public static @NotNull IncomeSourceEntity createNewEntity(@NotNull BudgetEntity budget, @NotNull String name, @NotNull BigDecimal amount, @Nullable Date startingDate, @Nullable Date endingDate) {
        IncomeSourceEntity incomeSource = getNewEntity();
        incomeSource.setSourceName(name);
        incomeSource.setAmount(amount);
        incomeSource.setStartDate(Dates.toSQLDate(startingDate));
        incomeSource.setEndDate(Dates.toSQLDate(endingDate));
        incomeSource.setToBudget(budget);
        incomeSource.saveChanges();
        return incomeSource;
    }

    @Contract(" -> new")
    public static @NotNull IncomeSourceEntity getNewEntity() {
        IncomeSourceEntity e = new IncomeSourceEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
