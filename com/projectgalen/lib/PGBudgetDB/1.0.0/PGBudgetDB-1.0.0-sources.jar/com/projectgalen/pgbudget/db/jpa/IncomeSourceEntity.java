package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._IncomeSourceEntity;
import com.projectgalen.pgbudget.db.jpa.dao.IncomeSourceEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = IncomeSourceEntityDao.class)
@Entity
@Table(name = "income_source", schema = "pgbudget")
public class IncomeSourceEntity extends _IncomeSourceEntity {

    protected IncomeSourceEntity() {
        super();
    }

    protected IncomeSourceEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public boolean isInRange(@NotNull Date date) {
        return Dates.isInRange(date, getStartDate(), getEndDate());
    }

    public boolean isInRange(@NotNull Calendar date) {
        return Dates.isInRange(date.getTime(), getStartDate(), getEndDate());
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    public static @NotNull IncomeSourceEntity createNewEntity(@NotNull BudgetEntity budget, @NotNull String name, @NotNull BigDecimal amount, @Nullable Date startingDate, @Nullable Date endingDate) {
        IncomeSourceEntity incomeSource = new IncomeSourceEntity(false);
        incomeSource.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        incomeSource.setSourceName(name);
        incomeSource.setAmount(amount);
        incomeSource.setStartDate(Dates.toSQLDate(startingDate));
        incomeSource.setEndDate(Dates.toSQLDate(endingDate));
        incomeSource.setToBudget(budget);
        incomeSource.saveChanges();
        return incomeSource;
    }

    public static @NotNull ValidationResponse validateIncomeSourceData(String name, BigDecimal amount, Date startingDate, Date endingDate) {
        if(U.z(name)) return new ValidationResponse("The name of the income source is required.");
        if(amount == null || amount.compareTo(BigDecimal.ZERO) < 0) return new ValidationResponse("The income amount cannot be less than zero.");
        if(startingDate != null && endingDate != null && startingDate.compareTo(endingDate) >= 0) return new ValidationResponse("The ending date must come after the starting date.");
        return new ValidationResponse();
    }
}
