package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: IncomeSourceEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "income_source", schema = "pgbudget")
public class IncomeSourceEntity extends JpaBase {
    private @Column(name = "income_source_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY)         Long                           incomeSourceId;
    private @Column(name = "budget_id", precision = 19, scale = 0)                                                                        Long                           budgetId;
    private @Column(name = "kv_id", precision = 19, scale = 0)                                                                            Long                           kvId;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                          state;
    private @Column(name = "start_date", nullable = true)                                                                                 Date                           startDate;
    private @Column(name = "end_date", nullable = true)                                                                                   Date                           endDate;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp                      dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp                      dateUpdated;
    private @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                BudgetEntity                   toBudget;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                        KvInfoEntity                   toKv;
    private @OneToMany(mappedBy = "toIncomeSource", fetch = FetchType.LAZY)                                                               Collection<PeriodIncomeEntity> toPeriodIncomes;
    private @OneToMany(mappedBy = "toIncomeSource", fetch = FetchType.LAZY)                                                               Collection<PeriodItemEntity>   toPeriodItems;

    public IncomeSourceEntity() { }

    public IncomeSourceEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getIncomeSourceId() {
        return this.incomeSourceId;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public State getState() {
        return this.state;
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public Collection<PeriodIncomeEntity> getToPeriodIncomes() {
        return Collections.unmodifiableCollection(this.toPeriodIncomes);
    }

    public Collection<PeriodItemEntity> getToPeriodItems() {
        return Collections.unmodifiableCollection(this.toPeriodItems);
    }

    public void setBudgetId(@NotNull Long budgetId) {
        if(Objects.equals(this.budgetId, budgetId)) return;
        this.budgetId = budgetId;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setEndDate(@Nullable Date endDate) {
        if(Objects.equals(this.endDate, endDate)) return;
        this.endDate = endDate;
        setAsDirty();
    }

    public void setIncomeSourceId(@NotNull Long incomeSourceId) {
        if(Objects.equals(this.incomeSourceId, incomeSourceId)) return;
        this.incomeSourceId = incomeSourceId;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setStartDate(@Nullable Date startDate) {
        if(Objects.equals(this.startDate, startDate)) return;
        this.startDate = startDate;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void addToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(Objects.equals(object.getToIncomeSource(), this)) return;
        if(object.getToIncomeSource() != null) object.getToIncomeSource().removeFromToPeriodIncomes(object);
        object.setToIncomeSource(this);
        if(!this.toPeriodIncomes.contains(object)) this.toPeriodIncomes.add(object);
        setAsDirty();
    }

    public void addToPeriodItems(@NotNull PeriodItemEntity object) {
        if(Objects.equals(object.getToIncomeSource(), this)) return;
        if(object.getToIncomeSource() != null) object.getToIncomeSource().removeFromToPeriodItems(object);
        object.setToIncomeSource(this);
        if(!this.toPeriodItems.contains(object)) this.toPeriodItems.add(object);
        setAsDirty();
    }

    public void removeFromToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(!Objects.equals(object.getToIncomeSource(), this)) return;
        object.setToIncomeSource(null);
        this.toPeriodIncomes.remove(object);
        setAsDirty();
    }

    public void removeFromToPeriodItems(@NotNull PeriodItemEntity object) {
        if(!Objects.equals(object.getToIncomeSource(), this)) return;
        object.setToIncomeSource(null);
        this.toPeriodItems.remove(object);
        setAsDirty();
    }
}
