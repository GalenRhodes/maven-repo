package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 4, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

@MappedSuperclass
public class _PeriodEntity extends JpaBase {

    protected @Column(name = "period_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         periodId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                         Long         budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                             Long         kvId;
    protected @Column(name = "prev_period_id", precision = 19, insertable = false, updatable = false)                                                                      Long         prevPeriodId;
    protected @Column(name = "next_period_id", precision = 19, insertable = false, updatable = false)                                                                      Long         nextPeriodId;
    protected @Column(name = "period_date", nullable = false)                                                                                                              Date         periodDate;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                         State        state;
    protected @Column(name = "roll_over_amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                           BigDecimal   rollOverAmount;
    protected @Column(name = "remaining_amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                           BigDecimal   remainingAmount;
    protected @Column(name = "total_income", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                               BigDecimal   totalIncome;
    protected @Column(name = "total_debit", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                BigDecimal   totalDebit;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                               BudgetEntity toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                       KvInfoEntity toKeyValueInfo;
    protected @ManyToOne @JoinColumn(name = "prev_period_id", referencedColumnName = "period_id")                                                                          PeriodEntity toPrevPeriod;
    protected @ManyToOne @JoinColumn(name = "next_period_id", referencedColumnName = "period_id")                                                                          PeriodEntity toNextPeriod;

    protected _PeriodEntity() { }

    protected _PeriodEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.rollOverAmount = BigDecimal.ZERO;
        this.remainingAmount = BigDecimal.ZERO;
        this.totalIncome = BigDecimal.ZERO;
        this.totalDebit = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof PeriodEntity) && _equals((PeriodEntity)o)));
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Long getNextPeriodId() {
        return this.nextPeriodId;
    }

    public Date getPeriodDate() {
        return this.periodDate;
    }

    public Long getPeriodId() {
        return this.periodId;
    }

    public Long getPrevPeriodId() {
        return this.prevPeriodId;
    }

    public BigDecimal getRemainingAmount() {
        return this.remainingAmount;
    }

    public BigDecimal getRollOverAmount() {
        return this.rollOverAmount;
    }

    public State getState() {
        return this.state;
    }

    public List<BankAccountsEntity> getToBankAccounts() {
        return HibernateUtil.find(BankAccountsEntity.class, PGArrays.wrap("toCurrentPeriod"), PGArrays.wrap(this));
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public PeriodEntity getToNextPeriod() {
        return this.toNextPeriod;
    }

    public List<PeriodIncomeEntity> getToPeriodIncomes() {
        return HibernateUtil.find(PeriodIncomeEntity.class, PGArrays.wrap("toPeriod"), PGArrays.wrap(this));
    }

    public List<PeriodItemEntity> getToPeriodItems() {
        return HibernateUtil.find(PeriodItemEntity.class, PGArrays.wrap("toPeriod"), PGArrays.wrap(this));
    }

    public PeriodEntity getToPrevPeriod() {
        return this.toPrevPeriod;
    }

    public BigDecimal getTotalDebit() {
        return this.totalDebit;
    }

    public BigDecimal getTotalIncome() {
        return this.totalIncome;
    }

    @Override
    public int hashCode() {
        return Objects.hash(periodId, budgetId, kvId, prevPeriodId, nextPeriodId, periodDate, state, rollOverAmount, remainingAmount, totalIncome, totalDebit, dateCreated, dateUpdated);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setPeriodDate(@NotNull Date periodDate) {
        if(Objects.equals(this.periodDate, periodDate)) return;
        this.periodDate = periodDate;
        setAsDirty();
    }

    public void setRemainingAmount(@NotNull BigDecimal remainingAmount) {
        if(Objects.equals(this.remainingAmount, remainingAmount)) return;
        this.remainingAmount = remainingAmount;
        setAsDirty();
    }

    public void setRollOverAmount(@NotNull BigDecimal rollOverAmount) {
        if(Objects.equals(this.rollOverAmount, rollOverAmount)) return;
        this.rollOverAmount = rollOverAmount;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setToNextPeriod(PeriodEntity toNextPeriod) {
        if(Objects.equals(this.toNextPeriod, toNextPeriod)) return;
        this.toNextPeriod = toNextPeriod;
        setAsDirty();
    }

    public void setToPrevPeriod(PeriodEntity toPrevPeriod) {
        if(Objects.equals(this.toPrevPeriod, toPrevPeriod)) return;
        this.toPrevPeriod = toPrevPeriod;
        setAsDirty();
    }

    public void setTotalDebit(@NotNull BigDecimal totalDebit) {
        if(Objects.equals(this.totalDebit, totalDebit)) return;
        this.totalDebit = totalDebit;
        setAsDirty();
    }

    public void setTotalIncome(@NotNull BigDecimal totalIncome) {
        if(Objects.equals(this.totalIncome, totalIncome)) return;
        this.totalIncome = totalIncome;
        setAsDirty();
    }

    private boolean _equals(@NotNull PeriodEntity other) {/*@f0*/
        return (Objects.equals(periodId, other.periodId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(prevPeriodId, other.prevPeriodId)
                && Objects.equals(nextPeriodId, other.nextPeriodId)
                && Objects.equals(periodDate, other.periodDate)
                && Objects.equals(state, other.state)
                && Objects.equals(rollOverAmount, other.rollOverAmount)
                && Objects.equals(remainingAmount, other.remainingAmount)
                && Objects.equals(totalIncome, other.totalIncome)
                && Objects.equals(totalDebit, other.totalDebit)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
