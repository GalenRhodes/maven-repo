package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.PeriodStateConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodState;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings({ "unused", "SpellCheckingInspection" })
public class _PeriodEntity extends JpaBase {

    protected @Column(name = "period_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         periodId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                         Long         budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                             Long         kvId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                         State        state;
    protected @Column(name = "period_date", nullable = false)                                                                                                              Date         periodDate;
    protected @Column(name = "period_state", nullable = false, precision = 10) @Convert(converter = PeriodStateConverter.class) @PGDefaultValue("PeriodState.NONE")        PeriodState  periodState;
    protected @Column(name = "roll_over_amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                           BigDecimal   rollOverAmount;
    protected @Column(name = "remaining_amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                           BigDecimal   remainingAmount;
    protected @Column(name = "total_income", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                               BigDecimal   totalIncome;
    protected @Column(name = "total_debit", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                BigDecimal   totalDebit;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                               BudgetEntity toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                       KvInfoEntity toKeyValueInfo;

    protected _PeriodEntity() { }

    protected _PeriodEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.periodState = PeriodState.NONE;
        this.rollOverAmount = BigDecimal.ZERO;
        this.remainingAmount = BigDecimal.ZERO;
        this.totalIncome = BigDecimal.ZERO;
        this.totalDebit = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof PeriodEntity) && _equals((PeriodEntity)o))));
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public Date getPeriodDate() {
        return Locks.getWithLock(lock, () -> this.periodDate);
    }

    public Long getPeriodId() {
        return Locks.getWithLock(lock, () -> this.periodId);
    }

    public PeriodState getPeriodState() {
        return Locks.getWithLock(lock, () -> this.periodState);
    }

    public BigDecimal getRemainingAmount() {
        return Locks.getWithLock(lock, () -> this.remainingAmount);
    }

    public BigDecimal getRollOverAmount() {
        return Locks.getWithLock(lock, () -> this.rollOverAmount);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public List<BankAccountsEntity> getToBankAccounts() {
        return HibernateUtil.find(BankAccountsEntity.class, wrap("toCurrentPeriod"), wrap(this));
    }

    public BudgetEntity getToBudget() {
        return Locks.getWithLock(lock, () -> this.toBudget);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<PeriodIncomeEntity> getToPeriodIncomes() {
        return HibernateUtil.find(PeriodIncomeEntity.class, wrap("toPeriod"), wrap(this));
    }

    public List<PeriodItemEntity> getToPeriodItems() {
        return HibernateUtil.find(PeriodItemEntity.class, wrap("toPeriod"), wrap(this));
    }

    public BigDecimal getTotalDebit() {
        return Locks.getWithLock(lock, () -> this.totalDebit);
    }

    public BigDecimal getTotalIncome() {
        return Locks.getWithLock(lock, () -> this.totalIncome);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(periodId, budgetId, kvId, state, periodDate, periodState, rollOverAmount, remainingAmount, totalIncome, totalDebit, dateCreated, dateUpdated));
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setPeriodDate(@NotNull Date periodDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.periodDate, periodDate)) {
                this.periodDate = periodDate;
                addValueToChangeMap("periodDate", this.periodDate);
                setAsDirty();
            }
        });
    }

    public void setPeriodState(@NotNull PeriodState periodState) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.periodState, periodState)) {
                this.periodState = periodState;
                addValueToChangeMap("periodState", this.periodState);
                setAsDirty();
            }
        });
    }

    public void setRemainingAmount(@NotNull BigDecimal remainingAmount) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.remainingAmount, remainingAmount)) {
                this.remainingAmount = remainingAmount;
                addValueToChangeMap("remainingAmount", this.remainingAmount);
                setAsDirty();
            }
        });
    }

    public void setRollOverAmount(@NotNull BigDecimal rollOverAmount) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.rollOverAmount, rollOverAmount)) {
                this.rollOverAmount = rollOverAmount;
                addValueToChangeMap("rollOverAmount", this.rollOverAmount);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToBudget(BudgetEntity toBudget) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toBudget, toBudget)) {
                this.toBudget = toBudget;
                addValueToChangeMap("budgetId", this.budgetId);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    public void setTotalDebit(@NotNull BigDecimal totalDebit) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.totalDebit, totalDebit)) {
                this.totalDebit = totalDebit;
                addValueToChangeMap("totalDebit", this.totalDebit);
                setAsDirty();
            }
        });
    }

    public void setTotalIncome(@NotNull BigDecimal totalIncome) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.totalIncome, totalIncome)) {
                this.totalIncome = totalIncome;
                addValueToChangeMap("totalIncome", this.totalIncome);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull PeriodEntity other) {/*@f0*/
        return (Objects.equals(periodId, other.periodId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(periodDate, other.periodDate)
                && Objects.equals(periodState, other.periodState)
                && Objects.equals(rollOverAmount, other.rollOverAmount)
                && Objects.equals(remainingAmount, other.remainingAmount)
                && Objects.equals(totalIncome, other.totalIncome)
                && Objects.equals(totalDebit, other.totalDebit)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
