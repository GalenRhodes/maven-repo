package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: CategoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 9, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import jakarta.persistence.*;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _CategoryEntity extends JpaBase {
    protected @Column(name = "category_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                               categoryId;
    protected @Column(name = "user_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                             Long                               userId;
    protected @Column(name = "name", length = 255)                                                                                                                    String                             name;
    protected @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                           State                              state;
    protected @Column(name = "date_created") @PGCurrentTimestamp                                                                                                      Timestamp                          dateCreated;
    protected @Column(name = "date_updated") @PGCurrentTimestamp                                                                                                      Timestamp                          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                              UsersEntity                        toUser;
    protected @OneToMany(mappedBy = "toCategory", fetch = FetchType.LAZY)                                                                                             Collection<RecurringPaymentEntity> toRecurringPayments;

    public _CategoryEntity() {}

    public _CategoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getName() {
        return this.name;
    }

    public State getState() {
        return this.state;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public void setName(@NotNull String name) {
        if(Objects.equals(this.name, name)) return;
        this.name = name;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToCategory(), this)) return;
        if(object.getToCategory() != null) object.getToCategory().removeFromToRecurringPayments(object);
        object.setToCategory((CategoryEntity)this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToCategory(), this)) return;
        object.setToCategory(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }


}
