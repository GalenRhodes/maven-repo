package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: CategoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 22, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.CategoryEntity;
import com.projectgalen.pgbudget.db.jpa.RecurringPaymentEntity;
import com.projectgalen.pgbudget.db.jpa.UsersEntity;
import com.projectgalen.pgbudget.db.jpa.dao.CategoryEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _CategoryEntity extends JpaBase {
    protected @Column(name = "category_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                               categoryId;
    protected @Column(name = "user_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                             Long                               userId;
    protected @Column(name = "name", nullable = false, length = 255)                                                                                                                    String                             name;
    protected @Column(name = "state", nullable = false, precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                           State                              state;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                      Timestamp                          dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                      Timestamp                          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                                                UsersEntity                        toUser;
    protected @OneToMany(mappedBy = "toCategory", fetch = FetchType.LAZY)                                                                                                               Collection<RecurringPaymentEntity> toRecurringPayments;

    public _CategoryEntity() { }

    public _CategoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToCategory(), this)) return;
        if(object.getToCategory() != null) object.getToCategory().removeFromToRecurringPayments(object);
        object.setToCategory((CategoryEntity)this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof CategoryEntity) && _equals((CategoryEntity)o)));
    }

    public String getName() {
        return this.name;
    }

    public State getState() {
        return this.state;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public Long getUserId() {
        return this.userId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(categoryId, userId, name, state, dateCreated, dateUpdated);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void setName(@NotNull String name) {
        if(Objects.equals(this.name, name)) return;
        this.name = name;
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToCategory(), this)) return;
        object.setToCategory(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    @Contract(pure = true)
    public static @NotNull CategoryEntityDao getDao() {
        return CategoryEntityDao.shared();
    }

    private boolean _equals(@NotNull CategoryEntity other) {/*@f0*/
        return (Objects.equals(categoryId, other.categoryId)
                && Objects.equals(userId, other.userId)
                && Objects.equals(name, other.name)
                && Objects.equals(state, other.state)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
