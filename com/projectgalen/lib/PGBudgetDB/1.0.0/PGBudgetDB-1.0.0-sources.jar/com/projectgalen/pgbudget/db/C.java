package com.projectgalen.pgbudget.db;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: Messages.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: April 19, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.utils.Kalendar;
import com.projectgalen.lib.utils.PGProperties;
import com.projectgalen.lib.utils.PGResourceBundle;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Calendar;
import java.util.Date;

public final class C {
    public static final PGResourceBundle msgs  = PGResourceBundle.getXMLPGBundle("com.projectgalen.pgbudget.db.Messages");
    public static final PGProperties     props = PGProperties.getXMLProperties("Settings.xml", C.class);

    private C() {
    }

    public static @NotNull Kalendar enumerateDates(@NotNull Kalendar start, @NotNull Kalendar end, @NotNull IncrementCalendar incLambda, @NotNull ForDate forDateLambda) {
        Kalendar c = start.clone();
        while(c.compareTo(end) <= 0) {
            forDateLambda.action(c);
            incLambda.increment(c);
        }
        return c;
    }

    public static @NotNull Kalendar getNextYear(@NotNull Calendar calendar) {
        Kalendar copy = new Kalendar(calendar);
        copy.addYears(1);
        return copy;
    }

    public static boolean isDateInPartialRange(@NotNull Date now, @Nullable Date start, @Nullable Date end) {
        return (((start == null) || (start.compareTo(now) >= 0)) && ((end == null) || (end.compareTo(now) < 0)));
    }

    public static boolean isDateInPartialRange(@NotNull Calendar now, @Nullable Calendar start, @Nullable Calendar end) {
        return (((start == null) || (start.compareTo(now) >= 0)) && ((end == null) || (end.compareTo(now) < 0)));
    }

    public static boolean isDateInRange(@NotNull Date now, @Nullable Date start, @Nullable Date end) {
        return (((start == null) || (start.compareTo(now) >= 0)) && ((end == null) || (end.compareTo(now) <= 0)));
    }

    public static boolean isDateInRange(@NotNull Calendar now, @Nullable Calendar start, @Nullable Calendar end) {
        return (((start == null) || (start.compareTo(now) >= 0)) && ((end == null) || (end.compareTo(now) <= 0)));
    }

    public static String nullify(@Nullable String str) {
        if(str == null) return null;
        str = str.trim();
        if(str.length() > 0) return str;
        return null;
    }

    public interface ForDate {
        void action(Kalendar c);
    }

    public interface IncrementCalendar {
        void increment(Kalendar c);
    }
}
