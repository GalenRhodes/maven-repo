package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.jpa.UsersEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

public final class UsersEntityDao extends AbstractDao<UsersEntity> {

    private UsersEntityDao() {
        super(UsersEntity.class);
    }

    public static @NotNull UsersEntity getNewEntity() {
        UsersEntity user = shared()._getNewEntity();
        user.setToKeyValueInfo(KvInfoEntityDao.getNewEntity());
        return user;
    }

    public static void create(UsersEntity entity) {
        shared()._create(entity, true);
    }

    public static void create(UsersEntity entity, boolean deep) {
        shared()._create(entity, deep);
    }

    public static void delete(@NotNull UsersEntity entity) {
        shared()._delete(entity);
    }

    public static @NotNull List<UsersEntity> find(@NotNull String queryString) {
        return shared()._find(queryString, null, true);
    }

    public static @NotNull List<UsersEntity> find(@NotNull String queryString, boolean initializeResults) {
        return shared()._find(queryString, null, initializeResults);
    }

    public static @NotNull List<UsersEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters) {
        return shared()._find(queryString, parameters, true);
    }

    public static @NotNull List<UsersEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters, boolean initializeResults) {
        return shared()._find(queryString, parameters, initializeResults);
    }

    public static @NotNull List<UsersEntity> findAll(boolean initializeResults) {
        return shared()._findAll(initializeResults);
    }

    public static @NotNull List<UsersEntity> findAll() {
        return shared()._findAll(true);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @NotNull QueryAction<UsersEntity, R> queryAction) {
        return shared()._findWithAction(queryString, null, queryAction);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @Nullable Map<String, Object> parameters, @NotNull QueryAction<UsersEntity, R> queryAction) {
        return shared()._findWithAction(queryString, parameters, queryAction);
    }

    public static @Nullable UsersEntity get(@NotNull Long userId) {
        return shared()._get(U.asArray("userId"), U.asArray(userId));
    }

    public static @Nullable UsersEntity get(@NotNull String searchField, @NotNull Object searchValue) {
        return shared()._get(searchField, searchValue);
    }

    public static @Nullable UsersEntity getByUsername(@NotNull String username) {
        return shared()._get("username", username);
    }

    public static @NotNull UsersEntityDao shared() {
        return Holder.INSTANCE;
    }

    public static void update(@NotNull UsersEntity entity) {
        shared()._update(entity, true);
    }

    public static void update(@NotNull UsersEntity entity, boolean deep) {
        shared()._update(entity, deep);
    }

    public static <R> R withSessionGet(@NotNull SessionAction<R> delegate) {
        return shared()._withSessionGet(delegate);
    }

    public static void withSessionUpdate(@NotNull SessionUpdateAction delegate) {
        shared()._withSessionUpdate(delegate);
    }

    private static final class Holder {
        private static final UsersEntityDao INSTANCE = new UsersEntityDao();
    }
}
