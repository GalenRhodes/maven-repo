package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvDataEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.events.JpaEventBase.EventType;
import com.projectgalen.pgbudget.db.events.users.UsersKeyValueEvent;
import com.projectgalen.pgbudget.db.events.users.UsersKeyValueListener;
import com.projectgalen.pgbudget.db.jpa.base._KvDataEntity;
import com.projectgalen.pgbudget.db.jpa.dao.KvDataEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@SuppressWarnings("UnusedReturnValue")
@PGJPA(daoClass = KvDataEntityDao.class)
@Entity
@Table(name = "kv_data", schema = "pgbudget")
public class KvDataEntity extends _KvDataEntity {

    protected KvDataEntity() {
        super();
    }

    protected KvDataEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        saveChanges(deep, (didValueChange("state") && (getState() == State.INACTIVE)) ? EventType.Removed : EventType.Changed);
    }

    private void saveChanges(boolean deep, EventType eventType) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
        UsersEntity user = HibernateUtil.get(UsersEntity.class, wrap("toKeyValueInfo", "state"), wrap(getToKeyValueInfo(), State.ACTIVE));
        if(user != null) user.fireUsersEvent(UsersKeyValueListener.class, new UsersKeyValueEvent(user, eventType, this));
    }

    @Contract("_,_,_ -> new")
    public static @NotNull KvDataEntity createNew(@NotNull String key, @NotNull String value, @NotNull KvInfoEntity info) {
        KvDataEntity kvData = new KvDataEntity(false);
        kvData.setKvKey(key);
        kvData.setKvValue(value);
        kvData.setToKeyValueInfo(info);
        kvData.saveChanges(true, EventType.Added);
        return kvData;
    }
}
