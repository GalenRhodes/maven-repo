package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: SessionEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 17, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.pgbudget.db.jpa.SessionEntity;
import com.projectgalen.pgbudget.db.jpa.UsersEntity;
import org.jetbrains.annotations.NotNull;

public final class SessionEntityDao extends AbstractDao<SessionEntity> {

    private SessionEntityDao() {
        super(SessionEntity.class);
    }

    @Override
    public @NotNull SessionEntity getNewEntity() {
        SessionEntity session = super.getNewEntity();
        session.setToKeyValueInfo(KvInfoEntityDao.shared().getNewEntity());
        session.setToLogin(LoginHistoryEntityDao.shared().getNewEntity());
        return session;
    }

    public @NotNull SessionEntity getNewEntity(@NotNull UsersEntity user) {
        SessionEntity session = getNewEntity();
        session.getToLogin().setToUser(user);
        user.setDateLastLogin(session.getToLogin().getDateLogin());
        return session;
    }

    public static @NotNull SessionEntityDao shared() {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        private static final SessionEntityDao INSTANCE = new SessionEntityDao();
    }
}
