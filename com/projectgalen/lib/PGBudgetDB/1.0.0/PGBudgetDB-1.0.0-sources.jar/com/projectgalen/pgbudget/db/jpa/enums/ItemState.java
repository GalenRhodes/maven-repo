package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: ItemState.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: April 21, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.pgbudget.db.C;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Range;

import static com.projectgalen.pgbudget.db.C.msgs;

public enum ItemState {
    NONE(0), AUTO(1), PENDING(2), CLEARED(3);

    @Range(from = 0, to = 3)
    private final int id;

    ItemState(@Range(from = 0, to = 3) int id) {
        this.id = id;
    }

    public @Range(from = 0, to = 3) int getId() {
        return id;
    }

    @Override
    public @NotNull String toString() {
        return C.msgs.getString(String.format("enum.item_state_name.%d", id), super.toString());
    }

    public static @NotNull ItemState getType(@Range(from = 0, to = 3) int id) {
        for(ItemState e : ItemState.values()) if(e.id == id) return e;
        throw new IllegalArgumentException(msgs.format("msg.err.invalid_enum_id", msgs.getString("msg.item_state"), id));
    }
}
