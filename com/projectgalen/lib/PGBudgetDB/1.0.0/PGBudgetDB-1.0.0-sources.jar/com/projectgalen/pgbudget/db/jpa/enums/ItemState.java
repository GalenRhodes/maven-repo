package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: ItemState.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: April 21, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import org.jetbrains.annotations.Range;

public enum ItemState {
    NONE(0), AUTO(1), PENDING(2), CLEARED(3);

    @Range(from = 0, to = 3)
    private final int id;

    ItemState(@Range(from = 0, to = 3) int id) {
        this.id = id;
    }

    public static ItemState getType(@Range(from = 0, to = 3) int id) {
        switch (id) {/*@f0*/
            case 0:
                return NONE;
            case 1:
                return AUTO;
            case 2:
                return PENDING;
            case 3:
                return CLEARED;
            default:
                throw new IllegalArgumentException("Index out of bounds");
        }/*@f1*/
    }

    public @Range(from = 0, to = 3) int getId() {
        return id;
    }

    @Override
    public String toString() {
        switch (this) {/*@f0*/
            case NONE:
                return "None";
            case AUTO:
                return "Auto";
            case PENDING:
                return "Pending";
            case CLEARED:
                return "Cleared";
            default:
                return super.toString();
        }/*@f1*/
    }
}
