package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: LoginHistoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.jpa.LoginHistoryEntity;
import com.projectgalen.pgbudget.db.jpa.SessionEntity;
import com.projectgalen.pgbudget.db.jpa.UsersEntity;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _LoginHistoryEntity extends JpaBase {

    protected @Column(name = "history_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long        historyId;
    protected @Column(name = "user_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                            Long        userId;
    protected @Column(name = "date_login", nullable = false) @PGCurrentTimestamp                                                                                            Timestamp   dateLogin;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                                    UsersEntity toUser;

    protected _LoginHistoryEntity() { }

    protected _LoginHistoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.dateLogin = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof LoginHistoryEntity) && _equals((LoginHistoryEntity)o))));
    }

    public Timestamp getDateLogin() {
        return Locks.getWithLock(lock, () -> this.dateLogin);
    }

    public Long getHistoryId() {
        return Locks.getWithLock(lock, () -> this.historyId);
    }

    public List<SessionEntity> getToSessions() {
        return HibernateUtil.find(SessionEntity.class, wrap("toLogin"), wrap(this));
    }

    public UsersEntity getToUser() {
        return Locks.getWithLock(lock, () -> this.toUser);
    }

    public Long getUserId() {
        return Locks.getWithLock(lock, () -> this.userId);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(historyId, userId, dateLogin));
    }

    public void setDateLogin(@NotNull Timestamp dateLogin) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateLogin, dateLogin)) {
                this.dateLogin = dateLogin;
                addValueToChangeMap("dateLogin", this.dateLogin);
                setAsDirty();
            }
        });
    }

    public void setToUser(UsersEntity toUser) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toUser, toUser)) {
                this.toUser = toUser;
                addValueToChangeMap("userId", this.userId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull LoginHistoryEntity other) {/*@f0*/
        return (Objects.equals(historyId, other.historyId)
                && Objects.equals(userId, other.userId)
                && Objects.equals(dateLogin, other.dateLogin));
    }/*@f1*/
}
