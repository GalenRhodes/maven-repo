package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: LoginHistoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 15, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.dao.LoginHistoryEntityDao;
import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@MappedSuperclass
public class _LoginHistoryEntity extends JpaBase {

    protected @Column(name = "history_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long        historyId;
    protected @Column(name = "user_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                            Long        userId;
    protected @Column(name = "date_login", nullable = false) @PGCurrentTimestamp                                                                                            Timestamp   dateLogin;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                                    UsersEntity toUser;

    protected _LoginHistoryEntity() {}

    protected _LoginHistoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.dateLogin = Dates.getTimestamp();
    }

    public Long getHistoryId() {
        return this.historyId;
    }

    public Long getUserId() {
        return this.userId;
    }

    public Timestamp getDateLogin() {
        return this.dateLogin;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public List<SessionEntity> getToSessions() {
        return HibernateUtil.find(SessionEntity.class, PGArrays.wrap("toLogin"), PGArrays.wrap(this));
    }

    public void setDateLogin(@NotNull Timestamp dateLogin) {
        if(Objects.equals(this.dateLogin, dateLogin)) return;
        this.dateLogin = dateLogin;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof LoginHistoryEntity) && _equals((LoginHistoryEntity)o)));
    }

    @Override
    public int hashCode() {
        return Objects.hash(historyId, userId, dateLogin);
    }

    private boolean _equals(@NotNull LoginHistoryEntity other) {/*@f0*/
        return (Objects.equals(historyId, other.historyId)
                && Objects.equals(userId, other.userId)
                && Objects.equals(dateLogin, other.dateLogin));
    }/*@f1*/
}
