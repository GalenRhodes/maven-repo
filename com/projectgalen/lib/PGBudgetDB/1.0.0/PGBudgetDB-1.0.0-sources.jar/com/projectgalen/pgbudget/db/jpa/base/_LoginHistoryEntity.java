package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: LoginHistoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 9, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.pgbudget.db.jpa.LoginHistoryEntity;
import com.projectgalen.pgbudget.db.jpa.SessionEntity;
import com.projectgalen.pgbudget.db.jpa.UsersEntity;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _LoginHistoryEntity extends JpaBase {
    protected @Column(name = "history_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                      historyId;
    protected @Column(name = "user_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                            Long                      userId;
    protected @Column(name = "date_login") @PGCurrentTimestamp                                                                                                       Timestamp                 dateLogin;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                             UsersEntity               toUser;
    protected @OneToMany(mappedBy = "toLogin", fetch = FetchType.LAZY)                                                                                               Collection<SessionEntity> toSessions;

    public _LoginHistoryEntity() { }

    public _LoginHistoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.dateLogin = Dates.getTimestamp();
    }

    public Timestamp getDateLogin() {
        return this.dateLogin;
    }

    public Long getHistoryId() {
        return this.historyId;
    }

    public Collection<SessionEntity> getToSessions() {
        return Collections.unmodifiableCollection(this.toSessions);
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public Long getUserId() {
        return this.userId;
    }

    public void setDateLogin(@NotNull Timestamp dateLogin) {
        if(Objects.equals(this.dateLogin, dateLogin)) return;
        this.dateLogin = dateLogin;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void addToSessions(@NotNull SessionEntity object) {
        if(Objects.equals(object.getToLogin(), this)) return;
        if(object.getToLogin() != null) object.getToLogin().removeFromToSessions(object);
        object.setToLogin((LoginHistoryEntity)this);
        if(!this.toSessions.contains(object)) this.toSessions.add(object);
        setAsDirty();
    }

    public void removeFromToSessions(@NotNull SessionEntity object) {
        if(!Objects.equals(object.getToLogin(), this)) return;
        object.setToLogin(null);
        this.toSessions.remove(object);
        setAsDirty();
    }
}
