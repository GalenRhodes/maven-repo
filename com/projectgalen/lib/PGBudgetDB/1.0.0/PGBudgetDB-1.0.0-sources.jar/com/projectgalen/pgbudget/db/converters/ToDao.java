package com.projectgalen.pgbudget.db.converters;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: ToDao.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.utils.IO;
import com.projectgalen.lib.utils.PGProperties;
import com.projectgalen.lib.utils.PGResourceBundle;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.macro.Macro;
import com.projectgalen.pgbudget.db.jpa.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.Properties;

public class ToDao {

    private static final PGProperties     props       = PGProperties.getProperties("ToDaoSettings.properties", ToDao.class);
    private static final PGResourceBundle msgs        = PGResourceBundle.getPGBundle("com.projectgalen.pgbudget.db.converters.ToDaoMessages");
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(props.getProperty("dao.format.date"));
    private static final SimpleDateFormat YEAR_FORMAT = new SimpleDateFormat(props.getProperty("dao.format.year"));

    public ToDao() { }

    public static void main(String[] args) {
        try {
            Properties p = new Properties();
            p.setProperty("somekey", "(\\w+)");
            p.store(System.out, null);

            String s = p.getProperty("somekey");
            System.out.println(s);
            System.exit(0);

            Class<?>[] clsList = {
                    BudgetEntity.class,
                    CategoryEntity.class,
                    IncomeSourceEntity.class,
                    KvDataEntity.class,
                    KvInfoEntity.class,
                    LoginHistoryEntity.class,
                    PeriodEntity.class,
                    PeriodIncomeEntity.class,
                    PeriodItemEntity.class,
                    RecurringPaymentEntity.class,
                    SessionEntity.class,
                    UsersEntity.class
            };
            String classPath = props.getProperty("dao.classpath");
            File   filePath  = new File(props.getProperty("dao.file.path")).getAbsoluteFile();
            String template  = IO.readFile(Objects.requireNonNull(ToDao.class.getResourceAsStream(props.getProperty("dao.template.file"))), StandardCharsets.UTF_8);
            Date   date      = new Date();

            //noinspection ResultOfMethodCallIgnored
            filePath.mkdirs();

            System.out.printf(msgs.getString("msg.writing.to"), filePath);

            for(Class<?> cls : clsList) {
                String jpaName = U.getPart(cls.getName(), "\\.", U.Parts.LAST);
                String daoName = U.concat(jpaName, props.getProperty("dao.suffix.class"));

                String fileText = Macro.replaceMacros(template, macroName -> {
                    switch(macroName) {/*@f:0*/
                        case "dao_classpath": return classPath;
                        case "dao_classname": return daoName;
                        case "jpa_classname": return jpaName;
                        case "date":          return DATE_FORMAT.format(date);
                        case "year":          return YEAR_FORMAT.format(date);
                        case "project":       return props.getProperty("dao.header.project");
                        case "author":        return props.getProperty("dao.header.author");
                        case "group":         return props.getProperty("dao.header.group");
                        case "ide":           return props.getProperty("dao.header.ide");
                        default:              return null;
                    }/*@f:1*/
                });

                File out = new File(filePath, U.concat(daoName, props.getProperty("dao.suffix.file")));

                try(BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8))) {
                    writer.write(fileText);
                    writer.flush();
                }
            }

            System.exit(0);
        }
        catch(Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }
}
