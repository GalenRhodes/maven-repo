package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodItemEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "period_item", schema = "pgbudget")
public class PeriodItemEntity extends JpaBase {
    private @Column(name = "item_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                   itemId;
    private @Column(name = "period_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                       Long                   periodId;
    private @Column(name = "recurring_id", nullable = true, precision = 19, scale = 0, insertable = false, updatable = false)                                   Long                   recurringId;
    private @Column(name = "income_source_id", nullable = true, precision = 19, scale = 0, insertable = false, updatable = false)                               Long                   incomeSourceId;
    private @Column(name = "kv_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                           Long                   kvId;
    private @Column(name = "payee_name", length = 255)                                                                                                          String                 payeeName;
    private @Column(name = "amount", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                              BigDecimal             amount;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State                  state;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                                                  Timestamp              dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                                                  Timestamp              dateUpdated;
    private @ManyToOne @JoinColumn(name = "period_id", referencedColumnName = "period_id")                                                                      PeriodEntity           toPeriod;
    private @ManyToOne @JoinColumn(name = "recurring_id", referencedColumnName = "payment_id")                                                                  RecurringPaymentEntity toRecurring;
    private @ManyToOne @JoinColumn(name = "income_source_id", referencedColumnName = "income_source_id")                                                        IncomeSourceEntity     toIncomeSource;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                              KvInfoEntity           toKv;

    public PeriodItemEntity() { }

    public PeriodItemEntity(@SuppressWarnings("unused") boolean dummy) {
        this.amount      = BigDecimal.ZERO;
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Long getIncomeSourceId() {
        return this.incomeSourceId;
    }

    public Long getItemId() {
        return this.itemId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public Long getPeriodId() {
        return this.periodId;
    }

    public Long getRecurringId() {
        return this.recurringId;
    }

    public State getState() {
        return this.state;
    }

    public IncomeSourceEntity getToIncomeSource() {
        return this.toIncomeSource;
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public PeriodEntity getToPeriod() {
        return this.toPeriod;
    }

    public RecurringPaymentEntity getToRecurring() {
        return this.toRecurring;
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setIncomeSourceId(@Nullable Long incomeSourceId) {
        if(Objects.equals(this.incomeSourceId, incomeSourceId)) return;
        this.incomeSourceId = incomeSourceId;
        setAsDirty();
    }

    public void setItemId(@NotNull Long itemId) {
        if(Objects.equals(this.itemId, itemId)) return;
        this.itemId = itemId;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setPayeeName(@NotNull String payeeName) {
        if(Objects.equals(this.payeeName, payeeName)) return;
        this.payeeName = payeeName;
        setAsDirty();
    }

    public void setPeriodId(@NotNull Long periodId) {
        if(Objects.equals(this.periodId, periodId)) return;
        this.periodId = periodId;
        setAsDirty();
    }

    public void setRecurringId(@Nullable Long recurringId) {
        if(Objects.equals(this.recurringId, recurringId)) return;
        this.recurringId = recurringId;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToIncomeSource(IncomeSourceEntity toIncomeSource) {
        if(Objects.equals(this.toIncomeSource, toIncomeSource)) return;
        this.toIncomeSource = toIncomeSource;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void setToPeriod(PeriodEntity toPeriod) {
        if(Objects.equals(this.toPeriod, toPeriod)) return;
        this.toPeriod = toPeriod;
        setAsDirty();
    }

    public void setToRecurring(RecurringPaymentEntity toRecurring) {
        if(Objects.equals(this.toRecurring, toRecurring)) return;
        this.toRecurring = toRecurring;
        setAsDirty();
    }
}
