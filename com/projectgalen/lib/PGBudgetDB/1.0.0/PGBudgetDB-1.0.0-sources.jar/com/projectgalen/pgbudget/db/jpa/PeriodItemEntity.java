package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodItemEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.jpa.base._PeriodItemEntity;
import com.projectgalen.pgbudget.db.jpa.dao.PeriodItemEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.ItemState;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = PeriodItemEntityDao.class)
@Entity
@Table(name = "period_item", schema = "pgbudget")
public class PeriodItemEntity extends _PeriodItemEntity {

    protected PeriodItemEntity() {
        super();
    }

    protected PeriodItemEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public static @NotNull PeriodItemEntity createNewPeriodItem(@NotNull Calendar periodDate, @NotNull RecurringPaymentEntity recurringPayment) {
        return createNewPeriodItem(periodDate.getTime(), recurringPayment);
    }

    @Contract("_, _ -> new")
    public static @NotNull PeriodItemEntity createNewPeriodItem(@NotNull Date periodDate, @NotNull RecurringPaymentEntity recurringPayment) {
        PeriodItemEntity e = new PeriodItemEntity(false);
        e.setPayeeName(recurringPayment.getPayeeName());
        e.setAmount(recurringPayment.getAmount());
        e.setItemState(recurringPayment.getIsAutopaid() ? (periodDate.before(new Date()) ? ItemState.PENDING : ItemState.AUTO) : ItemState.NONE);
        e.setToCategory(recurringPayment.getToCategory());
        e.setToRecurring(recurringPayment);
        e.setToBank(Objects.requireNonNullElse(recurringPayment.getToBank(), recurringPayment.getToBudget().getDefaultBankAccountActiveOn(periodDate)));
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
