package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodItemEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.jpa.base._PeriodItemEntity;
import com.projectgalen.pgbudget.db.jpa.dao.PeriodItemEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.ItemState;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = PeriodItemEntityDao.class)
@Entity
@Table(name = "period_item", schema = "pgbudget")
public class PeriodItemEntity extends _PeriodItemEntity {

    protected PeriodItemEntity() {
        super();
    }

    protected PeriodItemEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Contract("_, _, _, _ -> new")
    public static @NotNull PeriodItemEntity createNewPeriodItem(int count, @NotNull Date thisPeriodDate, @NotNull Date nextPeriodDate, @NotNull RecurringPaymentEntity recurringPayment) {
        Date               now         = new java.sql.Date(new Date().getTime());
        String             payee       = recurringPayment.getPayeeName();
        BigDecimal         amount      = recurringPayment.getAmount().multiply(BigDecimal.valueOf(count));
        CategoryEntity     category    = recurringPayment.getToCategory();
        Boolean            isAutopaid  = recurringPayment.getIsAutopaid();
        BankAccountsEntity bank        = recurringPayment.getToBank();
        BankAccountsEntity defaultBank = recurringPayment.getToBudget().getDefaultBankAccountActiveOn(thisPeriodDate);
        PeriodItemEntity   e           = getNewEntity();

        e.setToRecurring(recurringPayment);
        e.setPayeeName(payee);
        e.setAmount(amount);
        e.setItemState(isAutopaid ? (now.before(thisPeriodDate) ? ItemState.AUTO : ItemState.PENDING) : ItemState.NONE);
        e.setToCategory(category);
        e.setToBank(Objects.requireNonNullElse(bank, defaultBank));
        return e;
    }

    @Contract("-> new")
    public static @NotNull PeriodItemEntity getNewEntity() {
        PeriodItemEntity e = new PeriodItemEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
