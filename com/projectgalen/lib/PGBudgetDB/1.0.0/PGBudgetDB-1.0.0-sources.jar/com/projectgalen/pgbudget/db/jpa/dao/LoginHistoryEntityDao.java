package com.projectgalen.pgbudget.db.jpa.dao;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: LoginHistoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.AbstractDao;
import com.projectgalen.pgbudget.db.jpa.LoginHistoryEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.projectgalen.lib.utils.U;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class LoginHistoryEntityDao extends AbstractDao<LoginHistoryEntity> {

    private LoginHistoryEntityDao() {
        super(LoginHistoryEntity.class);
    }

    public static void create(LoginHistoryEntity entity) {
        shared()._create(entity, true);
    }

    public static void create(LoginHistoryEntity entity, boolean deep) {
        shared()._create(entity, deep);
    }

    public static @NotNull LoginHistoryEntity getNewEntity() {
        return shared()._getNewEntity();
    }

    public static void delete(@NotNull LoginHistoryEntity entity) {
        shared()._delete(entity);
    }

    public static @NotNull List<LoginHistoryEntity> find(@NotNull String queryString) {
        return shared()._find(queryString, null, true);
    }

    public static @NotNull List<LoginHistoryEntity> find(@NotNull String queryString, boolean initializeResults) {
        return shared()._find(queryString, null, initializeResults);
    }

    public static @NotNull List<LoginHistoryEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters) {
        return shared()._find(queryString, parameters, true);
    }

    public static @NotNull List<LoginHistoryEntity> find(@NotNull String queryString, @Nullable Map<String, Object> parameters, boolean initializeResults) {
        return shared()._find(queryString, parameters, initializeResults);
    }

    public static @NotNull List<LoginHistoryEntity> findAll(boolean initializeResults) {
        return shared()._findAll(initializeResults);
    }

    public static @NotNull List<LoginHistoryEntity> findAll() {
        return shared()._findAll(true);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @NotNull QueryAction<LoginHistoryEntity, R> queryAction) {
        return shared()._findWithAction(queryString, null, queryAction);
    }

    public static <R> @Nullable R findWithAction(@NotNull String queryString, @Nullable Map<String, Object> parameters, @NotNull QueryAction<LoginHistoryEntity, R> queryAction) {
        return shared()._findWithAction(queryString, parameters, queryAction);
    }

    public static @Nullable LoginHistoryEntity get(@NotNull Long historyId) {
        return shared()._get(U.asArray("historyId"), U.asArray(historyId));
    }

    public static @Nullable LoginHistoryEntity get(@NotNull String searchField, @NotNull Object searchValue) {
        return shared()._get(searchField, searchValue);
    }

    public static void update(@NotNull LoginHistoryEntity entity) {
        shared()._update(entity, true);
    }

    public static void update(@NotNull LoginHistoryEntity entity, boolean deep) {
        shared()._update(entity, deep);
    }

    public static <R> R withSessionGet(@NotNull SessionAction<R> delegate) {
        return shared()._withSessionGet(delegate);
    }

    public static void withSessionUpdate(@NotNull SessionUpdateAction delegate) {
        shared()._withSessionUpdate(delegate);
    }

    public static @NotNull LoginHistoryEntityDao shared() {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        private static final LoginHistoryEntityDao INSTANCE = new LoginHistoryEntityDao();
    }
}
