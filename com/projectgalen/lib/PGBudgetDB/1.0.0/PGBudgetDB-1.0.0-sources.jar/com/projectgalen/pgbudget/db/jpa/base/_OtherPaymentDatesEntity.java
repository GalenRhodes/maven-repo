package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: OtherPaymentDatesEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 15, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.MonthConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.OtherPaymentDatesEntity;
import com.projectgalen.pgbudget.db.jpa.RecurringPaymentEntity;
import com.projectgalen.pgbudget.db.jpa.enums.Month;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _OtherPaymentDatesEntity extends JpaBase {

    protected @Column(name = "date_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id                               Long                   dateId;
    protected @Column(name = "payment_id", nullable = false, precision = 19, insertable = false, updatable = false)                                Long                   paymentId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                  state;
    protected @Column(name = "due_month", nullable = false, precision = 10) @Convert(converter = MonthConverter.class)                             Month                  dueMonth;
    protected @Column(name = "due_date", nullable = false, precision = 10)                                                                         Integer                dueDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                 Timestamp              dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                 Timestamp              dateUpdated;
    protected @ManyToOne @JoinColumn(name = "payment_id", referencedColumnName = "payment_id")                                                     RecurringPaymentEntity toPayment;

    protected _OtherPaymentDatesEntity() { }

    protected _OtherPaymentDatesEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof OtherPaymentDatesEntity) && _equals((OtherPaymentDatesEntity)o)));
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Long getDateId() {
        return this.dateId;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Integer getDueDate() {
        return this.dueDate;
    }

    public Month getDueMonth() {
        return this.dueMonth;
    }

    public Long getPaymentId() {
        return this.paymentId;
    }

    public State getState() {
        return this.state;
    }

    public RecurringPaymentEntity getToPayment() {
        return this.toPayment;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateId, paymentId, state, dueMonth, dueDate, dateCreated, dateUpdated);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setDueDate(@NotNull Integer dueDate) {
        if(Objects.equals(this.dueDate, dueDate)) return;
        this.dueDate = dueDate;
        setAsDirty();
    }

    public void setDueMonth(@NotNull Month dueMonth) {
        if(Objects.equals(this.dueMonth, dueMonth)) return;
        this.dueMonth = dueMonth;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToPayment(RecurringPaymentEntity toPayment) {
        if(Objects.equals(this.toPayment, toPayment)) return;
        this.toPayment = toPayment;
        setAsDirty();
    }

    private boolean _equals(@NotNull OtherPaymentDatesEntity other) {/*@f0*/
        return (Objects.equals(dateId, other.dateId)
                && Objects.equals(paymentId, other.paymentId)
                && Objects.equals(state, other.state)
                && Objects.equals(dueMonth, other.dueMonth)
                && Objects.equals(dueDate, other.dueDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
