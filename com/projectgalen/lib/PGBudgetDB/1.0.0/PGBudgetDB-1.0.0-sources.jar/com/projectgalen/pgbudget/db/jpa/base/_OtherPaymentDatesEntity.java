package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: OtherPaymentDatesEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 5, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.pgbudget.db.converters.MonthConverter;
import com.projectgalen.pgbudget.db.jpa.OtherPaymentDatesEntity;
import com.projectgalen.pgbudget.db.jpa.RecurringPaymentEntity;
import com.projectgalen.pgbudget.db.jpa.enums.Month;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _OtherPaymentDatesEntity extends JpaBase {

    protected @Column(name = "date_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id   Long                   dateId;
    protected @Column(name = "payment_id", nullable = false, precision = 19, insertable = false, updatable = false)    Long                   paymentId;
    protected @Column(name = "due_month", nullable = false, precision = 10) @Convert(converter = MonthConverter.class) Month                  dueMonth;
    protected @Column(name = "due_date", nullable = false, precision = 10)                                             Integer                dueDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                     Timestamp              dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                     Timestamp              dateUpdated;
    protected @ManyToOne @JoinColumn(name = "payment_id", referencedColumnName = "payment_id")                         RecurringPaymentEntity toPayment;

    protected _OtherPaymentDatesEntity() { }

    protected _OtherPaymentDatesEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getDateId() {
        return this.dateId;
    }

    public Long getPaymentId() {
        return this.paymentId;
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof OtherPaymentDatesEntity) && _equals((OtherPaymentDatesEntity)o)));
    }

    public Integer getDueDate() {
        return this.dueDate;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public RecurringPaymentEntity getToPayment() {
        return this.toPayment;
    }

    public Month getDueMonth() {
        return this.dueMonth;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateId, paymentId, dueMonth, dueDate, dateCreated, dateUpdated);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToPayment(RecurringPaymentEntity toPayment) {
        if(Objects.equals(this.toPayment, toPayment)) return;
        this.toPayment = toPayment;
        setAsDirty();
    }

    public void setDueDate(@NotNull Integer dueDate) {
        if(Objects.equals(this.dueDate, dueDate)) return;
        this.dueDate = dueDate;
        setAsDirty();
    }

    public void setDueMonth(@NotNull Month dueMonth) {
        if(Objects.equals(this.dueMonth, dueMonth)) return;
        this.dueMonth = dueMonth;
        setAsDirty();
    }

    private boolean _equals(@NotNull OtherPaymentDatesEntity other) {/*@f0*/
        return (Objects.equals(dateId, other.dateId)
                && Objects.equals(paymentId, other.paymentId)
                && Objects.equals(dueMonth, other.dueMonth)
                && Objects.equals(dueDate, other.dueDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
