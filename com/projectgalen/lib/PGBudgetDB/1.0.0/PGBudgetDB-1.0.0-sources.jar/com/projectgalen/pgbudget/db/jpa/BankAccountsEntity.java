package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BankAccountsEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.jpa.base._BankAccountsEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BankAccountsEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

@PGJPA(daoClass = BankAccountsEntityDao.class)
@Entity
@Table(name = "bank_accounts", schema = "pgbudget")
public class BankAccountsEntity extends _BankAccountsEntity {

    public BankAccountsEntity() { super(); }

    public BankAccountsEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    @Override
    public State getState() {
        return (Objects.requireNonNullElse(super.getState(), State.INACTIVE));
    }

    public static @NotNull BankAccountsEntity getNewEntity() {
        BankAccountsEntity bankAccount = BankAccountsEntityDao.shared().getNewEntity();
        bankAccount.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return bankAccount;
    }
}
