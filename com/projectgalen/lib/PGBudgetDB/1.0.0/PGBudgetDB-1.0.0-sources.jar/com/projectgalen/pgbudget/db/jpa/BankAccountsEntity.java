package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BankAccountsEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGResourceBundle;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.C;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._BankAccountsEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BankAccountsEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = BankAccountsEntityDao.class)
@Entity
@Table(name = "bank_accounts", schema = "pgbudget")
public class BankAccountsEntity extends _BankAccountsEntity {
    private static final PGResourceBundle msgs = C.msgs;

    protected BankAccountsEntity() {
        super();
    }

    protected BankAccountsEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Contract("_, _, _, _, _ -> new")
    public static @NotNull BankAccountsEntity createNewBankAccount(@NotNull BudgetEntity budget, @NotNull String name, @NotNull BigDecimal balance, Date startDate, Date endDate) {
        BankAccountsEntity bankAccount = new BankAccountsEntity(false);
        bankAccount.setBankName(name);
        bankAccount.setCurrentBalance(balance);
        bankAccount.setStartDate(Dates.toSQLDate(startDate));
        bankAccount.setEndDate(Dates.toSQLDate(endDate));
        bankAccount.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        bankAccount.setToBudget(budget);
        bankAccount.saveChanges();
        return bankAccount;
    }

    @Contract("_, _, _ -> new")
    public static @NotNull ValidationResponse validateBankAccountData(String name, Date startDate, Date endDate) {
        if(U.z(name)) return new ValidationResponse(msgs.getString("validate.bank_account.bank_name_required"));
        if((startDate != null) && (endDate != null) && startDate.after(endDate)) return new ValidationResponse(msgs.getString("validate.bank_account.start_date_after_end_date"));
        return new ValidationResponse();
    }
}
