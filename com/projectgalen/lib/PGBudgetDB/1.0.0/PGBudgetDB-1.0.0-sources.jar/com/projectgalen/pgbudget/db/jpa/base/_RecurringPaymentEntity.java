package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.converters.BooleanConverter;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.lib.utils.enums.Month;
import com.projectgalen.lib.utils.enums.WeekDay;
import com.projectgalen.pgbudget.db.converters.DueFrequencyConverter;
import com.projectgalen.pgbudget.db.converters.MonthConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.converters.WeekDayConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.DueFrequency;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _RecurringPaymentEntity extends JpaBase {

    protected @Column(name = "payment_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long               paymentId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                          Long               budgetId;
    protected @Column(name = "category_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                        Long               categoryId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                              Long               kvId;
    protected @Column(name = "bank_id", precision = 19, insertable = false, updatable = false)                                                                              Long               bankId;
    protected @Column(name = "payee_name", nullable = false)                                                                                                                String             payeeName;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                          State              state;
    protected @Column(name = "is_autopaid", nullable = false, precision = 3) @Convert(converter = BooleanConverter.class) @PGDefaultValue("false")                          Boolean            isAutopaid;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2)                                                                                         BigDecimal         amount;
    protected @Column(name = "due_frequency", nullable = false, precision = 10) @Convert(converter = DueFrequencyConverter.class) @PGDefaultValue("DueFrequency.MONTHLY")   DueFrequency       dueFrequency;
    protected @Column(name = "due_month", precision = 10) @Convert(converter = MonthConverter.class)                                                                        Month              dueMonth;
    protected @Column(name = "due_month2", precision = 10) @Convert(converter = MonthConverter.class)                                                                       Month              dueMonth2;
    protected @Column(name = "due_date", precision = 10)                                                                                                                    Integer            dueDate;
    protected @Column(name = "due_date2", precision = 10)                                                                                                                   Integer            dueDate2;
    protected @Column(name = "due_weekday", precision = 10) @Convert(converter = WeekDayConverter.class)                                                                    WeekDay            dueWeekday;
    protected @Column(name = "due_weekday2", precision = 10) @Convert(converter = WeekDayConverter.class)                                                                   WeekDay            dueWeekday2;
    protected @Column(name = "start_date")                                                                                                                                  Date               startDate;
    protected @Column(name = "end_date")                                                                                                                                    Date               endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp          dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                                BudgetEntity       toBudget;
    protected @ManyToOne @JoinColumn(name = "category_id", referencedColumnName = "category_id")                                                                            CategoryEntity     toCategory;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                        KvInfoEntity       toKeyValueInfo;
    protected @ManyToOne @JoinColumn(name = "bank_id", referencedColumnName = "bank_id")                                                                                    BankAccountsEntity toBank;

    protected _RecurringPaymentEntity() { }

    protected _RecurringPaymentEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.isAutopaid = false;
        this.dueFrequency = DueFrequency.MONTHLY;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof RecurringPaymentEntity) && _equals((RecurringPaymentEntity)o))));
    }

    public BigDecimal getAmount() {
        return Locks.getWithLock(lock, () -> this.amount);
    }

    public Long getBankId() {
        return Locks.getWithLock(lock, () -> this.bankId);
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public Long getCategoryId() {
        return Locks.getWithLock(lock, () -> this.categoryId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Integer getDueDate() {
        return Locks.getWithLock(lock, () -> this.dueDate);
    }

    public Integer getDueDate2() {
        return Locks.getWithLock(lock, () -> this.dueDate2);
    }

    public DueFrequency getDueFrequency() {
        return Locks.getWithLock(lock, () -> this.dueFrequency);
    }

    public Month getDueMonth() {
        return Locks.getWithLock(lock, () -> this.dueMonth);
    }

    public Month getDueMonth2() {
        return Locks.getWithLock(lock, () -> this.dueMonth2);
    }

    public WeekDay getDueWeekday() {
        return Locks.getWithLock(lock, () -> this.dueWeekday);
    }

    public WeekDay getDueWeekday2() {
        return Locks.getWithLock(lock, () -> this.dueWeekday2);
    }

    public Date getEndDate() {
        return Locks.getWithLock(lock, () -> this.endDate);
    }

    public Boolean getIsAutopaid() {
        return Locks.getWithLock(lock, () -> this.isAutopaid);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public String getPayeeName() {
        return Locks.getWithLock(lock, () -> this.payeeName);
    }

    public Long getPaymentId() {
        return Locks.getWithLock(lock, () -> this.paymentId);
    }

    public Date getStartDate() {
        return Locks.getWithLock(lock, () -> this.startDate);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public BankAccountsEntity getToBank() {
        return Locks.getWithLock(lock, () -> this.toBank);
    }

    public BudgetEntity getToBudget() {
        return Locks.getWithLock(lock, () -> this.toBudget);
    }

    public CategoryEntity getToCategory() {
        return Locks.getWithLock(lock, () -> this.toCategory);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<OtherPaymentDatesEntity> getToOtherPaymentDates() {
        return HibernateUtil.find(OtherPaymentDatesEntity.class, wrap("toPayment"), wrap(this));
    }

    public List<PeriodItemEntity> getToPeriodItems() {
        return HibernateUtil.find(PeriodItemEntity.class, wrap("toRecurring"), wrap(this));
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(paymentId, budgetId, categoryId, kvId, bankId, payeeName, state, isAutopaid, amount, dueFrequency, dueMonth, dueMonth2, dueDate, dueDate2, dueWeekday, dueWeekday2, startDate, endDate, dateCreated, dateUpdated));
    }

    public void setAmount(@NotNull BigDecimal amount) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.amount, amount)) {
                this.amount = amount;
                addValueToChangeMap("amount", this.amount);
                setAsDirty();
            }
        });
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setDueDate(@Nullable Integer dueDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueDate, dueDate)) {
                this.dueDate = dueDate;
                addValueToChangeMap("dueDate", this.dueDate);
                setAsDirty();
            }
        });
    }

    public void setDueDate2(@Nullable Integer dueDate2) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueDate2, dueDate2)) {
                this.dueDate2 = dueDate2;
                addValueToChangeMap("dueDate2", this.dueDate2);
                setAsDirty();
            }
        });
    }

    public void setDueFrequency(@NotNull DueFrequency dueFrequency) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueFrequency, dueFrequency)) {
                this.dueFrequency = dueFrequency;
                addValueToChangeMap("dueFrequency", this.dueFrequency);
                setAsDirty();
            }
        });
    }

    public void setDueMonth(@Nullable Month dueMonth) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueMonth, dueMonth)) {
                this.dueMonth = dueMonth;
                addValueToChangeMap("dueMonth", this.dueMonth);
                setAsDirty();
            }
        });
    }

    public void setDueMonth2(@Nullable Month dueMonth2) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueMonth2, dueMonth2)) {
                this.dueMonth2 = dueMonth2;
                addValueToChangeMap("dueMonth2", this.dueMonth2);
                setAsDirty();
            }
        });
    }

    public void setDueWeekday(@Nullable WeekDay dueWeekday) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueWeekday, dueWeekday)) {
                this.dueWeekday = dueWeekday;
                addValueToChangeMap("dueWeekday", this.dueWeekday);
                setAsDirty();
            }
        });
    }

    public void setDueWeekday2(@Nullable WeekDay dueWeekday2) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dueWeekday2, dueWeekday2)) {
                this.dueWeekday2 = dueWeekday2;
                addValueToChangeMap("dueWeekday2", this.dueWeekday2);
                setAsDirty();
            }
        });
    }

    public void setEndDate(@Nullable Date endDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.endDate, endDate)) {
                this.endDate = endDate;
                addValueToChangeMap("endDate", this.endDate);
                setAsDirty();
            }
        });
    }

    public void setIsAutopaid(@NotNull Boolean isAutopaid) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.isAutopaid, isAutopaid)) {
                this.isAutopaid = isAutopaid;
                addValueToChangeMap("isAutopaid", this.isAutopaid);
                setAsDirty();
            }
        });
    }

    public void setPayeeName(@NotNull String payeeName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.payeeName, payeeName)) {
                this.payeeName = payeeName;
                addValueToChangeMap("payeeName", this.payeeName);
                setAsDirty();
            }
        });
    }

    public void setStartDate(@Nullable Date startDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.startDate, startDate)) {
                this.startDate = startDate;
                addValueToChangeMap("startDate", this.startDate);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToBank(BankAccountsEntity toBank) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toBank, toBank)) {
                this.toBank = toBank;
                addValueToChangeMap("bankId", this.bankId);
                setAsDirty();
            }
        });
    }

    public void setToBudget(BudgetEntity toBudget) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toBudget, toBudget)) {
                this.toBudget = toBudget;
                addValueToChangeMap("budgetId", this.budgetId);
                setAsDirty();
            }
        });
    }

    public void setToCategory(CategoryEntity toCategory) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toCategory, toCategory)) {
                this.toCategory = toCategory;
                addValueToChangeMap("categoryId", this.categoryId);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull RecurringPaymentEntity other) {/*@f0*/
        return (Objects.equals(paymentId, other.paymentId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(categoryId, other.categoryId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(bankId, other.bankId)
                && Objects.equals(payeeName, other.payeeName)
                && Objects.equals(state, other.state)
                && Objects.equals(isAutopaid, other.isAutopaid)
                && Objects.equals(amount, other.amount)
                && Objects.equals(dueFrequency, other.dueFrequency)
                && Objects.equals(dueMonth, other.dueMonth)
                && Objects.equals(dueMonth2, other.dueMonth2)
                && Objects.equals(dueDate, other.dueDate)
                && Objects.equals(dueDate2, other.dueDate2)
                && Objects.equals(dueWeekday, other.dueWeekday)
                && Objects.equals(dueWeekday2, other.dueWeekday2)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
