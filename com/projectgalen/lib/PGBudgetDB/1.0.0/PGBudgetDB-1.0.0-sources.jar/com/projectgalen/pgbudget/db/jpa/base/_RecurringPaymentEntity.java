package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 4, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.DueFrequencyConverter;
import com.projectgalen.pgbudget.db.converters.MonthConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.converters.WeekDayConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.dao.RecurringPaymentEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.DueFrequency;
import com.projectgalen.pgbudget.db.jpa.enums.Month;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import com.projectgalen.pgbudget.db.jpa.enums.WeekDay;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@MappedSuperclass
public class _RecurringPaymentEntity extends JpaBase {

    protected @Column(name = "payment_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long           paymentId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                          Long           budgetId;
    protected @Column(name = "category_id", precision = 19, insertable = false, updatable = false)                                                                          Long           categoryId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                              Long           kvId;
    protected @Column(name = "payee_name", nullable = false)                                                                                                                String         payeeName;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                          State          state;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2)                                                                                         BigDecimal     amount;
    protected @Column(name = "due_frequency", nullable = false, precision = 10) @Convert(converter = DueFrequencyConverter.class) @PGDefaultValue("DueFrequency.MONTHLY")   DueFrequency   dueFrequency;
    protected @Column(name = "due_month", precision = 10) @Convert(converter = MonthConverter.class)                                                                        Month          dueMonth;
    protected @Column(name = "due_month2", precision = 10) @Convert(converter = MonthConverter.class)                                                                       Month          dueMonth2;
    protected @Column(name = "due_date", precision = 10)                                                                                                                    Integer        dueDate;
    protected @Column(name = "due_date2", precision = 10)                                                                                                                   Integer        dueDate2;
    protected @Column(name = "due_weekday", precision = 10) @Convert(converter = WeekDayConverter.class)                                                                    WeekDay        dueWeekday;
    protected @Column(name = "due_weekday2", precision = 10) @Convert(converter = WeekDayConverter.class)                                                                   WeekDay        dueWeekday2;
    protected @Column(name = "start_date")                                                                                                                                  Date           startDate;
    protected @Column(name = "end_date")                                                                                                                                    Date           endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp      dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                          Timestamp      dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                                BudgetEntity   toBudget;
    protected @ManyToOne @JoinColumn(name = "category_id", referencedColumnName = "category_id")                                                                            CategoryEntity toCategory;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                        KvInfoEntity   toKeyValueInfo;

    protected _RecurringPaymentEntity() {}

    protected _RecurringPaymentEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state        = State.ACTIVE;
        this.dueFrequency = DueFrequency.MONTHLY;
        this.dateCreated  = Dates.getTimestamp();
        this.dateUpdated  = Dates.getTimestamp();
    }

    public Long getPaymentId() {
        return this.paymentId;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public State getState() {
        return this.state;
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public DueFrequency getDueFrequency() {
        return this.dueFrequency;
    }

    public Month getDueMonth() {
        return this.dueMonth;
    }

    public Month getDueMonth2() {
        return this.dueMonth2;
    }

    public Integer getDueDate() {
        return this.dueDate;
    }

    public Integer getDueDate2() {
        return this.dueDate2;
    }

    public WeekDay getDueWeekday() {
        return this.dueWeekday;
    }

    public WeekDay getDueWeekday2() {
        return this.dueWeekday2;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public CategoryEntity getToCategory() {
        return this.toCategory;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public List<OtherPaymentDatesEntity> getToOtherPaymentDates() {
        return HibernateUtil.find(OtherPaymentDatesEntity.class, PGArrays.wrap("toPayment"), PGArrays.wrap(this));
    }

    public List<PeriodItemEntity> getToPeriodItems() {
        return HibernateUtil.find(PeriodItemEntity.class, PGArrays.wrap("toRecurring"), PGArrays.wrap(this));
    }

    public void setPayeeName(@NotNull String payeeName) {
        if(Objects.equals(this.payeeName, payeeName)) return;
        this.payeeName = payeeName;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setDueFrequency(@NotNull DueFrequency dueFrequency) {
        if(Objects.equals(this.dueFrequency, dueFrequency)) return;
        this.dueFrequency = dueFrequency;
        setAsDirty();
    }

    public void setDueMonth(@Nullable Month dueMonth) {
        if(Objects.equals(this.dueMonth, dueMonth)) return;
        this.dueMonth = dueMonth;
        setAsDirty();
    }

    public void setDueMonth2(@Nullable Month dueMonth2) {
        if(Objects.equals(this.dueMonth2, dueMonth2)) return;
        this.dueMonth2 = dueMonth2;
        setAsDirty();
    }

    public void setDueDate(@Nullable Integer dueDate) {
        if(Objects.equals(this.dueDate, dueDate)) return;
        this.dueDate = dueDate;
        setAsDirty();
    }

    public void setDueDate2(@Nullable Integer dueDate2) {
        if(Objects.equals(this.dueDate2, dueDate2)) return;
        this.dueDate2 = dueDate2;
        setAsDirty();
    }

    public void setDueWeekday(@Nullable WeekDay dueWeekday) {
        if(Objects.equals(this.dueWeekday, dueWeekday)) return;
        this.dueWeekday = dueWeekday;
        setAsDirty();
    }

    public void setDueWeekday2(@Nullable WeekDay dueWeekday2) {
        if(Objects.equals(this.dueWeekday2, dueWeekday2)) return;
        this.dueWeekday2 = dueWeekday2;
        setAsDirty();
    }

    public void setStartDate(@Nullable Date startDate) {
        if(Objects.equals(this.startDate, startDate)) return;
        this.startDate = startDate;
        setAsDirty();
    }

    public void setEndDate(@Nullable Date endDate) {
        if(Objects.equals(this.endDate, endDate)) return;
        this.endDate = endDate;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToCategory(CategoryEntity toCategory) {
        if(Objects.equals(this.toCategory, toCategory)) return;
        this.toCategory = toCategory;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof RecurringPaymentEntity) && _equals((RecurringPaymentEntity)o)));
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentId, budgetId, categoryId, kvId, payeeName, state, amount, dueFrequency, dueMonth, dueMonth2, dueDate, dueDate2, dueWeekday, dueWeekday2, startDate, endDate, dateCreated, dateUpdated);
    }

    private boolean _equals(@NotNull RecurringPaymentEntity other) {/*@f0*/
        return (Objects.equals(paymentId, other.paymentId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(categoryId, other.categoryId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(payeeName, other.payeeName)
                && Objects.equals(state, other.state)
                && Objects.equals(amount, other.amount)
                && Objects.equals(dueFrequency, other.dueFrequency)
                && Objects.equals(dueMonth, other.dueMonth)
                && Objects.equals(dueMonth2, other.dueMonth2)
                && Objects.equals(dueDate, other.dueDate)
                && Objects.equals(dueDate2, other.dueDate2)
                && Objects.equals(dueWeekday, other.dueWeekday)
                && Objects.equals(dueWeekday2, other.dueWeekday2)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
