package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvInfoEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.BankAccountsEntity;
import com.projectgalen.pgbudget.db.jpa.KvDataEntity;
import com.projectgalen.pgbudget.db.jpa.KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _KvInfoEntity extends JpaBase {

    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long      kvId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                     State     state;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                     Timestamp dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                     Timestamp dateUpdated;

    protected _KvInfoEntity() { }

    protected _KvInfoEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof KvInfoEntity) && _equals((KvInfoEntity)o))));
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public List<BankAccountsEntity> getToBankAccounts() {
        return HibernateUtil.find(BankAccountsEntity.class, wrap("toKeyValueInfo"), wrap(this));
    }

    public List<KvDataEntity> getToKvDatas() {
        return HibernateUtil.find(KvDataEntity.class, wrap("toKeyValueInfo"), wrap(this));
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(kvId, state, dateCreated, dateUpdated));
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull KvInfoEntity other) {/*@f0*/
        return (Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
