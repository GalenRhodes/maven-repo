package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodItemEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 18, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.ItemStateConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.ItemState;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _PeriodItemEntity extends JpaBase {

    protected @Column(name = "item_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                   itemId;
    protected @Column(name = "period_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                       Long                   periodId;
    protected @Column(name = "category_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                     Long                   categoryId;
    protected @Column(name = "recurring_id", precision = 19, insertable = false, updatable = false)                                                                      Long                   recurringId;
    protected @Column(name = "bank_id", precision = 19, insertable = false, updatable = false)                                                                           Long                   bankId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                           Long                   kvId;
    protected @Column(name = "payee_name", nullable = false)                                                                                                             String                 payeeName;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                   BigDecimal             amount;
    protected @Column(name = "item_state", nullable = false, precision = 10) @Convert(converter = ItemStateConverter.class) @PGDefaultValue("ItemState.NONE")            ItemState              itemState;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State                  state;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp              dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp              dateUpdated;
    protected @ManyToOne @JoinColumn(name = "period_id", referencedColumnName = "period_id")                                                                             PeriodEntity           toPeriod;
    protected @ManyToOne @JoinColumn(name = "category_id", referencedColumnName = "category_id")                                                                         CategoryEntity         toCategory;
    protected @ManyToOne @JoinColumn(name = "recurring_id", referencedColumnName = "payment_id")                                                                         RecurringPaymentEntity toRecurring;
    protected @ManyToOne @JoinColumn(name = "bank_id", referencedColumnName = "bank_id")                                                                                 BankAccountsEntity     toBank;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                     KvInfoEntity           toKeyValueInfo;

    protected _PeriodItemEntity() { }

    protected _PeriodItemEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.amount = BigDecimal.ZERO;
        this.itemState = ItemState.NONE;
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof PeriodItemEntity) && _equals((PeriodItemEntity)o)));
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Long getBankId() {
        return this.bankId;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Long getItemId() {
        return this.itemId;
    }

    public ItemState getItemState() {
        return this.itemState;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public Long getPeriodId() {
        return this.periodId;
    }

    public Long getRecurringId() {
        return this.recurringId;
    }

    public State getState() {
        return this.state;
    }

    public BankAccountsEntity getToBank() {
        return this.toBank;
    }

    public CategoryEntity getToCategory() {
        return this.toCategory;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public PeriodEntity getToPeriod() {
        return this.toPeriod;
    }

    public RecurringPaymentEntity getToRecurring() {
        return this.toRecurring;
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemId, periodId, categoryId, recurringId, bankId, kvId, payeeName, amount, itemState, state, dateCreated, dateUpdated);
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setItemState(@NotNull ItemState itemState) {
        if(Objects.equals(this.itemState, itemState)) return;
        this.itemState = itemState;
        setAsDirty();
    }

    public void setPayeeName(@NotNull String payeeName) {
        if(Objects.equals(this.payeeName, payeeName)) return;
        this.payeeName = payeeName;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBank(BankAccountsEntity toBank) {
        if(Objects.equals(this.toBank, toBank)) return;
        this.toBank = toBank;
        setAsDirty();
    }

    public void setToCategory(CategoryEntity toCategory) {
        if(Objects.equals(this.toCategory, toCategory)) return;
        this.toCategory = toCategory;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setToPeriod(PeriodEntity toPeriod) {
        if(Objects.equals(this.toPeriod, toPeriod)) return;
        this.toPeriod = toPeriod;
        setAsDirty();
    }

    public void setToRecurring(RecurringPaymentEntity toRecurring) {
        if(Objects.equals(this.toRecurring, toRecurring)) return;
        this.toRecurring = toRecurring;
        setAsDirty();
    }

    private boolean _equals(@NotNull PeriodItemEntity other) {/*@f0*/
        return (Objects.equals(itemId, other.itemId)
                && Objects.equals(periodId, other.periodId)
                && Objects.equals(categoryId, other.categoryId)
                && Objects.equals(recurringId, other.recurringId)
                && Objects.equals(bankId, other.bankId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(payeeName, other.payeeName)
                && Objects.equals(amount, other.amount)
                && Objects.equals(itemState, other.itemState)
                && Objects.equals(state, other.state)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
