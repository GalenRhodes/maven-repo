package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.jpa.base._UsersEntity;
import com.projectgalen.pgbudget.db.jpa.dao.UsersEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.pgbudget.db.C.nullify;

@PGJPA(daoClass = UsersEntityDao.class)
@Entity
@Table(name = "users", schema = "pgbudget")
public class UsersEntity extends _UsersEntity {

    protected UsersEntity() {
        super();
    }

    protected UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Transient
    public @NotNull List<BudgetEntity> getActiveBudgets() {
        return HibernateUtil.find(BudgetEntity.class, PGArrays.wrap("state", "userId"), PGArrays.wrap(State.ACTIVE, userId), PGArrays.wrap("name"));
    }

    @Transient
    public @NotNull List<CategoryEntity> getActiveCategories() {
        return HibernateUtil.find(CategoryEntity.class, PGArrays.wrap("state", "userId"), PGArrays.wrap(State.ACTIVE, userId), PGArrays.wrap("name"));
    }

    @Transient
    public @Nullable LoginHistoryEntity getLastLogin() {
        List<LoginHistoryEntity> list = HibernateUtil.find(LoginHistoryEntity.class, PGArrays.wrap("userId"), PGArrays.wrap((Object)userId), PGArrays.wrap("dateLogin desc"));
        return (list.isEmpty() ? null : list.get(0));
    }

    @Transient
    public @Nullable SessionEntity getLastSession() {
        LoginHistoryEntity login = getLastLogin();
        if(login == null) return null;
        List<SessionEntity> list = HibernateUtil.find(SessionEntity.class, PGArrays.wrap("toLogin"), PGArrays.wrap(login), PGArrays.wrap("dateCreated desc"));
        return (list.isEmpty() ? null : list.get(0));
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public static @NotNull UsersEntity createUser(@NotNull String username,
                                                  char @NotNull [] password,
                                                  @Nullable String prefix,
                                                  @NotNull String firstName,
                                                  @Nullable String middleName,
                                                  @NotNull String lastName,
                                                  @Nullable String suffix,
                                                  @NotNull String email,
                                                  @NotNull Date dob,
                                                  String[] initialCategories) {
        UsersEntity user = UsersEntity.getNewEntity();
        user.setNamePrefix(nullify(prefix));
        user.setNameSuffix(nullify(suffix));
        user.setUsername(username);
        user.setEmailAddress(email);
        user.setFirstName(firstName);
        user.setMiddleName(nullify(middleName));
        user.setLastName(lastName);
        user.setDateOfBirth(new java.sql.Date(dob.getTime()));
        user.setPassword(U.sha3_256Hash(password));
        user.saveChanges();

        for(String category : Objects.requireNonNullElse(initialCategories, new String[0])) {
            CategoryEntity categoryEntity = CategoryEntity.getNewEntity();
            categoryEntity.setName(category);
            categoryEntity.setToUser(user);
            categoryEntity.saveChanges();
        }

        return user;
    }

    /**
     * This will search ALL users regardless of their state.
     *
     * @param username the username to search for.
     *
     * @return the user with that username or null if the username was not found.
     */
    public static @Nullable UsersEntity getAllByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, "username", username);
    }

    public static @Nullable UsersEntity getByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, PGArrays.wrap("state", "username"), PGArrays.wrap(State.ACTIVE, username));
    }

    @Contract(" -> new")
    public static @NotNull UsersEntity getNewEntity() {
        UsersEntity e = new UsersEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
