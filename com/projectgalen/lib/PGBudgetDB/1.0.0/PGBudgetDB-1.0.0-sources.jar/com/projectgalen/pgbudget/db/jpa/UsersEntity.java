package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.events.JpaEventListenerList;
import com.projectgalen.pgbudget.db.events.users.UsersEvent;
import com.projectgalen.pgbudget.db.events.users.UsersEventListener;
import com.projectgalen.pgbudget.db.jpa.base._UsersEntity;
import com.projectgalen.pgbudget.db.jpa.dao.UsersEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;
import static com.projectgalen.lib.utils.PGCollections.getFirst;
import static com.projectgalen.pgbudget.db.C.nullify;

@SuppressWarnings({ "unused", "SpellCheckingInspection" })
@PGJPA(daoClass = UsersEntityDao.class)
@Entity
@Table(name = "users", schema = "pgbudget")
public class UsersEntity extends _UsersEntity {

    protected final JpaEventListenerList listenerList = new JpaEventListenerList();

    protected UsersEntity() {
        super();
    }

    protected UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @SuppressWarnings("unchecked")
    @Transient
    public <T extends JpaBase> void addUsersEventListener(@NotNull UsersEventListener<T> listener) {
        listenerList.addListener((Class<UsersEventListener<T>>)listener.getClass(), listener);
    }

    public <T extends JpaBase, L extends UsersEventListener<T>> void fireUsersEvent(@NotNull Class<? extends UsersEventListener<T>> listenerClass, @NotNull UsersEvent<T> event) {
        for(UsersEventListener<T> listener : listenerList.getListeners(listenerClass)) {
            listener.handleUsersEvent(event);
        }
    }

    @SuppressWarnings("unchecked")
    @Transient
    public <T extends JpaBase> void removeUsersEventListener(@NotNull UsersEventListener<T> listener) {
        listenerList.addListener((Class<UsersEventListener<T>>)listener.getClass(), listener);
    }

    @Transient
    public @NotNull List<BudgetEntity> getActiveBudgets() {
        return HibernateUtil.find(BudgetEntity.class, wrap("state", "toUser"), wrap(State.ACTIVE, this), wrap("name"));
    }

    @Transient
    public @NotNull List<CategoryEntity> getActiveCategories() {
        return HibernateUtil.find(CategoryEntity.class, wrap("state", "toUser"), wrap(State.ACTIVE, this), wrap("name"));
    }

    @Transient
    public @Nullable CategoryEntity getCategoryWithName(@NotNull String name) {
        List<CategoryEntity> list = HibernateUtil.find(CategoryEntity.class, wrap("state", "toUser", "name"), wrap(State.ACTIVE, this, name), 0, 1);
        return getFirst(list);
    }

    @Transient
    public @Nullable CategoryEntity getDefaultCategory() {
        List<CategoryEntity> list = HibernateUtil.find(CategoryEntity.class, wrap("state", "toUser", "isDefault"), wrap(State.ACTIVE, this, true), wrap("name"), 0, 1);
        return getFirst(list);
    }

    @Transient
    public @Nullable LoginHistoryEntity getLastLogin() {
        List<LoginHistoryEntity> list = HibernateUtil.find(LoginHistoryEntity.class, wrap("toUser"), wrap(this), wrap("dateLogin desc"), 0, 1);
        return getFirst(list);
    }

    @Transient
    public @Nullable SessionEntity getLastSession() {
        LoginHistoryEntity login = getLastLogin();
        if(login == null) return null;
        List<SessionEntity> list = HibernateUtil.find(SessionEntity.class, wrap("toLogin"), wrap(login), wrap("dateCreated desc"), 0, 1);
        return getFirst(list);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    public static @NotNull UsersEntity createUser(@NotNull String username,
                                                  char @NotNull [] password,
                                                  @Nullable String prefix,
                                                  @NotNull String firstName,
                                                  @Nullable String middleName,
                                                  @NotNull String lastName,
                                                  @Nullable String suffix,
                                                  @NotNull String email,
                                                  @NotNull Date dob,
                                                  String[] initialCategories) {
        UsersEntity user = UsersEntity.getNewEntity();
        user.setNamePrefix(nullify(prefix));
        user.setNameSuffix(nullify(suffix));
        user.setUsername(username);
        user.setEmailAddress(email);
        user.setFirstName(firstName);
        user.setMiddleName(nullify(middleName));
        user.setLastName(lastName);
        user.setDateOfBirth(new java.sql.Date(dob.getTime()));
        user.setPassword(U.sha3_256Hash(password));
        user.saveChanges();

        for(String category : Objects.requireNonNullElse(initialCategories, new String[]{ "*Misc" })) {
            boolean isDefaut = category.startsWith("*");
            if(isDefaut) category = category.substring(1);
            CategoryEntity.createNewCategory(user, category, isDefaut).saveChanges();
        }

        return user;
    }

    public static @Nullable UsersEntity getActiveByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, wrap("state", "username"), wrap(State.ACTIVE, username));
    }

    public static @Nullable UsersEntity getAnyByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, wrap("username"), wrap(username));
    }

    @Contract(" -> new")
    public static @NotNull UsersEntity getNewEntity() {
        UsersEntity e = new UsersEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
