package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.jpa.base._UsersEntity;
import com.projectgalen.pgbudget.db.jpa.dao.UsersEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.projectgalen.pgbudget.db.C.nullify;

@PGJPA(daoClass = UsersEntityDao.class)
@Entity
@Table(name = "users", schema = "pgbudget")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class UsersEntity extends _UsersEntity {

    protected UsersEntity() { super(); }

    protected UsersEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    public static @Nullable UsersEntity getAllByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, "username", username);
    }

    public static @Nullable UsersEntity getByUsername(@NotNull String username) {
        return HibernateUtil.get(UsersEntity.class, U.asArray("state", "username"), U.asArray(State.ACTIVE.getValue(), username));
    }

    @Transient
    public @NotNull List<BudgetEntity> getActiveBudgets() {
        List<BudgetEntity> list = new ArrayList<>();
        refresh();
        for(BudgetEntity budget : getToBudgets()) if(budget.getState() == State.ACTIVE) list.add(budget);
        return list;
    }

    @Transient
    public @NotNull List<CategoryEntity> getActiveCategories() {
        List<CategoryEntity> list = new ArrayList<>();
        for(CategoryEntity category : getToCategories()) if(category.getState() == State.ACTIVE) list.add(category);
        list.sort(Comparator.comparing(CategoryEntity::getName));
        return list;
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public static @NotNull UsersEntity createUser(@NotNull String username, char @NotNull [] password, @Nullable String prefix, @NotNull String firstName, @Nullable String middleName, @NotNull String lastName, @Nullable String suffix, @NotNull String email, @NotNull Date dob, String[] initialCategories) {
        UsersEntity user = UsersEntity.getNewEntity();
        user.setNamePrefix(nullify(prefix));
        user.setNameSuffix(nullify(suffix));
        user.setUsername(username);
        user.setEmailAddress(email);
        user.setFirstName(firstName);
        user.setMiddleName(nullify(middleName));
        user.setLastName(lastName);
        user.setDateOfBirth(new java.sql.Date(dob.getTime()));
        user.setPassword(U.sha3_256Hash(password));
        user.saveChanges();

        for(String category : Objects.requireNonNullElse(initialCategories, new String[0])) {
            CategoryEntity categoryEntity = CategoryEntity.getNewEntity();
            categoryEntity.setName(category);
            categoryEntity.setToUser(user);
            categoryEntity.saveChanges();
        }

        return user;
    }

    @Contract(" -> new")
    public static @NotNull UsersEntity getNewEntity() {
        UsersEntity e = new UsersEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
}
