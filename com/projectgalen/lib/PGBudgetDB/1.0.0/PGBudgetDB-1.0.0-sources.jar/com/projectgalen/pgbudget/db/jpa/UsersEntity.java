package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "users", schema = "pgbudget")
public class UsersEntity extends JpaBase {
    private @Column(name = "user_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                           userId;
    private @Column(name = "kv_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                           Long                           kvId;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State                          state;
    private @Column(name = "username", unique = true, length = 255)                                                                                             String                         username;
    private @Column(name = "password", length = 255)                                                                                                            String                         password;
    private @Column(name = "email_address", length = 255)                                                                                                       String                         emailAddress;
    private @Column(name = "first_name", length = 255)                                                                                                          String                         firstName;
    private @Column(name = "middle_name", nullable = true, length = 255)                                                                                        String                         middleName;
    private @Column(name = "last_name", length = 255)                                                                                                           String                         lastName;
    private @Column(name = "date_of_birth", nullable = true)                                                                                                    Date                           dateOfBirth;
    private @Column(name = "date_last_login", nullable = true)                                                                                                  Timestamp                      dateLastLogin;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                                                  Timestamp                      dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                                                  Timestamp                      dateUpdated;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                              KvInfoEntity                   toKv;
    private @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                             Collection<BudgetEntity>       toBudgets;
    private @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                             Collection<CategoryEntity>     toCategories;
    private @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                             Collection<LoginHistoryEntity> toLoginHistories;

    public UsersEntity() { }

    public UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateLastLogin() {
        return this.dateLastLogin;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public String getPassword() {
        return this.password;
    }

    public State getState() {
        return this.state;
    }

    public Collection<BudgetEntity> getToBudgets() {
        return Collections.unmodifiableCollection(this.toBudgets);
    }

    public Collection<CategoryEntity> getToCategories() {
        return Collections.unmodifiableCollection(this.toCategories);
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public Collection<LoginHistoryEntity> getToLoginHistories() {
        return Collections.unmodifiableCollection(this.toLoginHistories);
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getUsername() {
        return this.username;
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateLastLogin(@Nullable Timestamp dateLastLogin) {
        if(Objects.equals(this.dateLastLogin, dateLastLogin)) return;
        this.dateLastLogin = dateLastLogin;
        setAsDirty();
    }

    public void setDateOfBirth(@NotNull Date dateOfBirth) {
        if(Objects.equals(this.dateOfBirth, dateOfBirth)) return;
        this.dateOfBirth = dateOfBirth;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setFirstName(@NotNull String firstName) {
        if(Objects.equals(this.firstName, firstName)) return;
        this.firstName = firstName;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setLastName(@NotNull String lastName) {
        if(Objects.equals(this.lastName, lastName)) return;
        this.lastName = lastName;
        setAsDirty();
    }

    public void setMiddleName(@Nullable String middleName) {
        if(Objects.equals(this.middleName, middleName)) return;
        this.middleName = middleName;
        setAsDirty();
    }

    public void setPassword(@NotNull String password) {
        if(Objects.equals(this.password, password)) return;
        this.password = password;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void setUserId(@NotNull Long userId) {
        if(Objects.equals(this.userId, userId)) return;
        this.userId = userId;
        setAsDirty();
    }

    public void setUsername(@NotNull String username) {
        if(Objects.equals(this.username, username)) return;
        this.username = username;
        setAsDirty();
    }

    public void addToBudgets(@NotNull BudgetEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToBudgets(object);
        object.setToUser(this);
        if(!this.toBudgets.contains(object)) this.toBudgets.add(object);
        setAsDirty();
    }

    public void addToCategories(@NotNull CategoryEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToCategories(object);
        object.setToUser(this);
        if(!this.toCategories.contains(object)) this.toCategories.add(object);
        setAsDirty();
    }

    public void addToLoginHistories(@NotNull LoginHistoryEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToLoginHistories(object);
        object.setToUser(this);
        if(!this.toLoginHistories.contains(object)) this.toLoginHistories.add(object);
        setAsDirty();
    }

    public void removeFromToBudgets(@NotNull BudgetEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toBudgets.remove(object);
        setAsDirty();
    }

    public void removeFromToCategories(@NotNull CategoryEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toCategories.remove(object);
        setAsDirty();
    }

    public void removeFromToLoginHistories(@NotNull LoginHistoryEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toLoginHistories.remove(object);
        setAsDirty();
    }
}
