package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodIncomeEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.IncomeSourceEntity;
import com.projectgalen.pgbudget.db.jpa.KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.PeriodEntity;
import com.projectgalen.pgbudget.db.jpa.PeriodIncomeEntity;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
@SuppressWarnings("unused")
public class _PeriodIncomeEntity extends JpaBase {

    protected @Column(name = "period_income_source_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long               periodIncomeSourceId;
    protected @Column(name = "period_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                                       Long               periodId;
    protected @Column(name = "income_source_id", precision = 19, insertable = false, updatable = false)                                                                                  Long               incomeSourceId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                                           Long               kvId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                                       State              state;
    protected @Column(name = "source_name", nullable = false)                                                                                                                            String             sourceName;
    protected @Column(name = "amount", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                                   BigDecimal         amount;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                       Timestamp          dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                       Timestamp          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "period_id", referencedColumnName = "period_id")                                                                                             PeriodEntity       toPeriod;
    protected @ManyToOne @JoinColumn(name = "income_source_id", referencedColumnName = "income_source_id")                                                                               IncomeSourceEntity toIncomeSource;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                                     KvInfoEntity       toKeyValueInfo;

    protected _PeriodIncomeEntity() { }

    protected _PeriodIncomeEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.amount = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof PeriodIncomeEntity) && _equals((PeriodIncomeEntity)o))));
    }

    public BigDecimal getAmount() {
        return Locks.getWithLock(lock, () -> this.amount);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Long getIncomeSourceId() {
        return Locks.getWithLock(lock, () -> this.incomeSourceId);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public Long getPeriodId() {
        return Locks.getWithLock(lock, () -> this.periodId);
    }

    public Long getPeriodIncomeSourceId() {
        return Locks.getWithLock(lock, () -> this.periodIncomeSourceId);
    }

    public String getSourceName() {
        return Locks.getWithLock(lock, () -> this.sourceName);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public IncomeSourceEntity getToIncomeSource() {
        return Locks.getWithLock(lock, () -> this.toIncomeSource);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public PeriodEntity getToPeriod() {
        return Locks.getWithLock(lock, () -> this.toPeriod);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(periodIncomeSourceId, periodId, incomeSourceId, kvId, state, sourceName, amount, dateCreated, dateUpdated));
    }

    public void setAmount(@NotNull BigDecimal amount) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.amount, amount)) {
                this.amount = amount;
                addValueToChangeMap("amount", this.amount);
                setAsDirty();
            }
        });
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setSourceName(@NotNull String sourceName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.sourceName, sourceName)) {
                this.sourceName = sourceName;
                addValueToChangeMap("sourceName", this.sourceName);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToIncomeSource(IncomeSourceEntity toIncomeSource) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toIncomeSource, toIncomeSource)) {
                this.toIncomeSource = toIncomeSource;
                addValueToChangeMap("incomeSourceId", this.incomeSourceId);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    public void setToPeriod(PeriodEntity toPeriod) {
        Locks.doWithLock(lock, () -> {
            if(Objects.equals(this.toPeriod, toPeriod)) {
                this.toPeriod = toPeriod;
                addValueToChangeMap("periodId", this.periodId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull PeriodIncomeEntity other) {/*@f0*/
        return (Objects.equals(periodIncomeSourceId, other.periodIncomeSourceId)
                && Objects.equals(periodId, other.periodId)
                && Objects.equals(incomeSourceId, other.incomeSourceId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(sourceName, other.sourceName)
                && Objects.equals(amount, other.amount)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
