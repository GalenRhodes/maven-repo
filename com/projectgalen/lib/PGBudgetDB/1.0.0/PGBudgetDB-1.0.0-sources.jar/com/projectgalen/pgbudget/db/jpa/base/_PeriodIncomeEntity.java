package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: PeriodIncomeEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 10, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import jakarta.persistence.*;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _PeriodIncomeEntity extends JpaBase {
    protected @Column(name = "period_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id                             Long               periodId;
    protected @Column(name = "income_source_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id                      Long               incomeSourceId;
    protected @Column(name = "kv_id", precision = 19, scale = 0, insertable = false, updatable = false)                                     Long               kvId;
    protected @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State              state;
    protected @Column(name = "amount", precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                        BigDecimal         amount;
    protected @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp          dateCreated;
    protected @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "period_id", referencedColumnName = "period_id")                                                PeriodEntity       toPeriod;
    protected @ManyToOne @JoinColumn(name = "income_source_id", referencedColumnName = "income_source_id")                                  IncomeSourceEntity toIncomeSource;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                        KvInfoEntity       toKeyValueInfo;

    public _PeriodIncomeEntity() {}

    public _PeriodIncomeEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.amount      = BigDecimal.ZERO;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getPeriodId() {
        return this.periodId;
    }

    public Long getIncomeSourceId() {
        return this.incomeSourceId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public State getState() {
        return this.state;
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public PeriodEntity getToPeriod() {
        return this.toPeriod;
    }

    public IncomeSourceEntity getToIncomeSource() {
        return this.toIncomeSource;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToPeriod(PeriodEntity toPeriod) {
        if(Objects.equals(this.toPeriod, toPeriod)) return;
        this.toPeriod = toPeriod;
        setAsDirty();
    }

    public void setToIncomeSource(IncomeSourceEntity toIncomeSource) {
        if(Objects.equals(this.toIncomeSource, toIncomeSource)) return;
        this.toIncomeSource = toIncomeSource;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }


}
