package com.projectgalen.pgbudget.db.events;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: JpaEventListenerList.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: May 24, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.utils.Streams;
import org.jetbrains.annotations.NotNull;

import java.util.EventListener;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

@SuppressWarnings("unused")
public class JpaEventListenerList {

    private final Set<ListenerEntry> listeners = new LinkedHashSet<>();

    public JpaEventListenerList() { }

    public <T extends EventListener> void addListener(@NotNull Class<T> listenerClass, @NotNull T listener) {
        synchronized(listeners) { listeners.add(new ListenerEntry(listenerClass, listener)); }
    }

    @SuppressWarnings("unchecked")
    public <T extends EventListener> T @NotNull [] getListeners(@NotNull Class<T> listenerClass) {
        return Streams.toArray(listenerClass, listeners.stream().filter(l -> l.getListenerClass() == listenerClass).map(l -> (T)l.getListener()));
    }

    public <T extends EventListener> void removeListener(@NotNull Class<T> listenerClass, @NotNull T listener) {
        synchronized(listeners) { listeners.remove(new ListenerEntry(listenerClass, listener)); }
    }

    private static class ListenerEntry {
        private final @NotNull Class<? extends EventListener> listenerClass;
        private final @NotNull EventListener                  listener;

        public ListenerEntry(@NotNull Class<? extends EventListener> listenerClass, @NotNull EventListener listener) {
            this.listenerClass = listenerClass;
            this.listener = listener;
        }

        @Override
        public boolean equals(Object o) {
            return ((this == o) || ((o instanceof ListenerEntry) && _equals((ListenerEntry)o)));
        }

        public @NotNull EventListener getListener() {
            return listener;
        }

        public @NotNull Class<?> getListenerClass() {
            return listenerClass;
        }

        @Override
        public int hashCode() {
            return Objects.hash(listenerClass, listener);
        }

        private boolean _equals(@NotNull ListenerEntry other) {
            return (Objects.equals(listenerClass, other.listenerClass) && Objects.equals(listener, other.listener));
        }
    }
}
