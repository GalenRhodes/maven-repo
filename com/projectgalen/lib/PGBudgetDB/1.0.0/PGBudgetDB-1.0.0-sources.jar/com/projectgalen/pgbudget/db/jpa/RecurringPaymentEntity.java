package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.enums.Month;
import com.projectgalen.lib.utils.enums.WeekDay;
import com.projectgalen.pgbudget.db.C;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._RecurringPaymentEntity;
import com.projectgalen.pgbudget.db.jpa.dao.RecurringPaymentEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.DueFrequency;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

@PGJPA(daoClass = RecurringPaymentEntityDao.class)
@Entity
@Table(name = "recurring_payment", schema = "pgbudget")
public class RecurringPaymentEntity extends _RecurringPaymentEntity {

    protected RecurringPaymentEntity() {
        super();
    }

    protected RecurringPaymentEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    public boolean isInRange(@NotNull Date date) {
        return Dates.isInRange(date, getStartDate(), getEndDate());
    }

    public boolean isInRange(@NotNull Calendar date) {
        return Dates.isInRange(date.getTime(), getStartDate(), getEndDate());
    }

    public void populateRecurringPayment(@NotNull String payee,
                                         @NotNull BigDecimal amount,
                                         @NotNull CategoryEntity category,
                                         @NotNull DueFrequency frequency,
                                         boolean isAuto,
                                         Date startDate,
                                         Date endDate,
                                         Integer dayOfMonth,
                                         Integer dayOfMonth1,
                                         Integer dayOfMonth2,
                                         WeekDay weekDay,
                                         WeekDay weekDay1,
                                         WeekDay weekDay2,
                                         Month yearMonth,
                                         Integer yearDate,
                                         Month yearMonth1,
                                         Integer yearDate1,
                                         Month yearMonth2,
                                         Integer yearDate2) {
        setPayeeName(U.tr(payee));
        setAmount(amount);
        setIsAutopaid(isAuto);
        setToCategory(category);
        setDueFrequency(frequency);
        setStartDate(Dates.toSQLDate(startDate));
        setEndDate(Dates.toSQLDate(endDate));
        setDueDate(null);
        setDueDate2(null);
        setDueWeekday(null);
        setDueWeekday2(null);
        setDueMonth(null);
        setDueMonth2(null);

        switch(frequency) {
            case MONTHLY:
                setDueDate(dayOfMonth);
                break;
            case TWICE_MONTHLY:
                setDueDate(dayOfMonth1);
                setDueDate2(dayOfMonth2);
                break;
            case WEEKLY:
                setDueWeekday(weekDay);
                break;
            case BIWEEKLY:
                setDueWeekday(weekDay1);
                setDueWeekday2(weekDay2);
                break;
            case YEARLY:
                setDueMonth(yearMonth);
                setDueDate(yearDate);
                break;
            case TWICE_YEARLY:
                setDueMonth(yearMonth1);
                setDueDate(yearDate1);
                setDueMonth2(yearMonth2);
                setDueDate2(yearDate2);
                break;
            case OTHER:
                break;
        }
        saveChanges();
    }

    @Override public void saveChanges() {
        saveChanges(true);
    }

    @Override public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    public static @NotNull RecurringPaymentEntity createNewRecurringPaymentEntity(@NotNull BudgetEntity budget,
                                                                                  @NotNull String payee,
                                                                                  @NotNull BigDecimal amount,
                                                                                  @NotNull CategoryEntity category,
                                                                                  @NotNull DueFrequency frequency,
                                                                                  boolean isAuto,
                                                                                  Date startDate,
                                                                                  Date endDate,
                                                                                  Integer dayOfMonth,
                                                                                  Integer dayOfMonth1,
                                                                                  Integer dayOfMonth2,
                                                                                  WeekDay weekDay,
                                                                                  WeekDay weekDay1,
                                                                                  WeekDay weekDay2,
                                                                                  Month yearMonth,
                                                                                  Integer yearDate,
                                                                                  Month yearMonth1,
                                                                                  Integer yearDate1,
                                                                                  Month yearMonth2,
                                                                                  Integer yearDate2) {
        RecurringPaymentEntity entity = new RecurringPaymentEntity(false);
        entity.setToBudget(budget);
        entity.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        entity.populateRecurringPayment(payee,
                                        amount,
                                        category,
                                        frequency,
                                        isAuto,
                                        startDate,
                                        endDate,
                                        dayOfMonth,
                                        dayOfMonth1,
                                        dayOfMonth2,
                                        weekDay,
                                        weekDay1,
                                        weekDay2,
                                        yearMonth,
                                        yearDate,
                                        yearMonth1,
                                        yearDate1,
                                        yearMonth2,
                                        yearDate2);
        return entity;
    }

    public static @NotNull ValidationResponse validateRecurringPaymentData(String payee,
                                                                           BigDecimal amount,
                                                                           CategoryEntity category,
                                                                           @NotNull DueFrequency frequency,
                                                                           boolean isAuto,
                                                                           Date startDate,
                                                                           Date endDate,
                                                                           Integer dayOfMonth,
                                                                           Integer dayOfMonth1,
                                                                           Integer dayOfMonth2,
                                                                           WeekDay weekDay,
                                                                           WeekDay weekDay1,
                                                                           WeekDay weekDay2,
                                                                           Month yearMonth,
                                                                           Integer yearDate,
                                                                           Month yearMonth1,
                                                                           Integer yearDate1,
                                                                           Month yearMonth2,
                                                                           Integer yearDate2) {
        if(U.z(payee)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.payee_required"));
        if(amount.compareTo(BigDecimal.ZERO) <= 0) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.pos_amount_req"));
        if(category == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.cat_req"));
        if((startDate != null) && (endDate != null) && (startDate.compareTo(endDate) >= 0)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.edate_b4_sdate"));
        if((endDate != null) && (endDate.compareTo(new Date()) <= 0)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.edate_past"));

        switch(frequency) {
            case MONTHLY:
                if(dayOfMonth == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.dom_req"));
                break;
            case TWICE_MONTHLY:
                if(dayOfMonth1 == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.dom1_req"));
                if(dayOfMonth2 == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.dom2_req"));
                break;
            case WEEKLY:
                if(weekDay == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.wd_req"));
                break;
            case BIWEEKLY:
                if(weekDay1 == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.wd1_req"));
                if(weekDay2 == null) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.wd2_req"));
                break;
            case YEARLY:
                if((yearMonth == null) || (yearDate == null)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.mad_req"));
                break;
            case TWICE_YEARLY:
                if((yearMonth1 == null) || (yearDate1 == null)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.mad1_req"));
                if((yearMonth2 == null) || (yearDate2 == null)) return new ValidationResponse(C.msgs.getString("validate.recurring_payment.mad2_req"));
                break;
            default:
                return new ValidationResponse(C.msgs.getString("validate.recurring_payment.freq_req"));
        }

        return new ValidationResponse();
    }
}
