package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.DueFrequencyConverter;
import com.projectgalen.pgbudget.db.converters.MonthConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.DueFrequency;
import com.projectgalen.pgbudget.db.jpa.enums.Month;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "recurring_payment", schema = "pgbudget")
public class RecurringPaymentEntity extends JpaBase {
    private @Column(name = "payment_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                         paymentId;
    private @Column(name = "budget_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                          Long                         budgetId;
    private @Column(name = "category_id", nullable = true, precision = 19, scale = 0, insertable = false, updatable = false)                                       Long                         categoryId;
    private @Column(name = "kv_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                              Long                         kvId;
    private @Column(name = "payee_name", length = 255)                                                                                                             String                       payeeName;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                          State                        state;
    private @Column(name = "amount", precision = 10, scale = 2)                                                                                                    BigDecimal                   amount;
    private @Column(name = "due_frequency", precision = 10, scale = 0) @Convert(converter = DueFrequencyConverter.class) @PGDefaultValue("DueFrequency.OTHER")     DueFrequency                 dueFrequency;
    private @Column(name = "due_month", nullable = true, precision = 10, scale = 0) @Convert(converter = MonthConverter.class)                                     Month                        dueMonth;
    private @Column(name = "due_date", precision = 10, scale = 0)                                                                                                  Integer                      dueDate;
    private @Column(name = "start_date", nullable = true)                                                                                                          Date                         startDate;
    private @Column(name = "end_date", nullable = true)                                                                                                            Date                         endDate;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                                                     Timestamp                    dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                                                     Timestamp                    dateUpdated;
    private @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                         BudgetEntity                 toBudget;
    private @ManyToOne @JoinColumn(name = "category_id", referencedColumnName = "category_id")                                                                     CategoryEntity               toCategory;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                 KvInfoEntity                 toKv;
    private @OneToMany(mappedBy = "toRecurring", fetch = FetchType.LAZY)                                                                                           Collection<PeriodItemEntity> toPeriodItems;

    public RecurringPaymentEntity() { }

    public RecurringPaymentEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state        = State.ACTIVE;
        this.dueFrequency = DueFrequency.OTHER;
        this.dateCreated  = Dates.getTimestamp();
        this.dateUpdated  = Dates.getTimestamp();
    }

    public BigDecimal getAmount() {
        return this.amount;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Integer getDueDate() {
        return this.dueDate;
    }

    public DueFrequency getDueFrequency() {
        return this.dueFrequency;
    }

    public Month getDueMonth() {
        return this.dueMonth;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getPayeeName() {
        return this.payeeName;
    }

    public Long getPaymentId() {
        return this.paymentId;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public State getState() {
        return this.state;
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public CategoryEntity getToCategory() {
        return this.toCategory;
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public Collection<PeriodItemEntity> getToPeriodItems() {
        return Collections.unmodifiableCollection(this.toPeriodItems);
    }

    public void setAmount(@NotNull BigDecimal amount) {
        if(Objects.equals(this.amount, amount)) return;
        this.amount = amount;
        setAsDirty();
    }

    public void setBudgetId(@NotNull Long budgetId) {
        if(Objects.equals(this.budgetId, budgetId)) return;
        this.budgetId = budgetId;
        setAsDirty();
    }

    public void setCategoryId(@Nullable Long categoryId) {
        if(Objects.equals(this.categoryId, categoryId)) return;
        this.categoryId = categoryId;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setDueDate(@NotNull Integer dueDate) {
        if(Objects.equals(this.dueDate, dueDate)) return;
        this.dueDate = dueDate;
        setAsDirty();
    }

    public void setDueFrequency(@NotNull DueFrequency dueFrequency) {
        if(Objects.equals(this.dueFrequency, dueFrequency)) return;
        this.dueFrequency = dueFrequency;
        setAsDirty();
    }

    public void setDueMonth(@Nullable Month dueMonth) {
        if(Objects.equals(this.dueMonth, dueMonth)) return;
        this.dueMonth = dueMonth;
        setAsDirty();
    }

    public void setEndDate(@Nullable Date endDate) {
        if(Objects.equals(this.endDate, endDate)) return;
        this.endDate = endDate;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setPayeeName(@NotNull String payeeName) {
        if(Objects.equals(this.payeeName, payeeName)) return;
        this.payeeName = payeeName;
        setAsDirty();
    }

    public void setPaymentId(@NotNull Long paymentId) {
        if(Objects.equals(this.paymentId, paymentId)) return;
        this.paymentId = paymentId;
        setAsDirty();
    }

    public void setStartDate(@Nullable Date startDate) {
        if(Objects.equals(this.startDate, startDate)) return;
        this.startDate = startDate;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToCategory(CategoryEntity toCategory) {
        if(Objects.equals(this.toCategory, toCategory)) return;
        this.toCategory = toCategory;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void addToPeriodItems(@NotNull PeriodItemEntity object) {
        if(Objects.equals(object.getToRecurring(), this)) return;
        if(object.getToRecurring() != null) object.getToRecurring().removeFromToPeriodItems(object);
        object.setToRecurring(this);
        if(!this.toPeriodItems.contains(object)) this.toPeriodItems.add(object);
        setAsDirty();
    }

    public void removeFromToPeriodItems(@NotNull PeriodItemEntity object) {
        if(!Objects.equals(object.getToRecurring(), this)) return;
        object.setToRecurring(null);
        this.toPeriodItems.remove(object);
        setAsDirty();
    }
}
