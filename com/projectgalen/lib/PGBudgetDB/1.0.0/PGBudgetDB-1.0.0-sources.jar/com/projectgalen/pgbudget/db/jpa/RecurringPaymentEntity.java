package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: RecurringPaymentEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._RecurringPaymentEntity;
import com.projectgalen.pgbudget.db.jpa.dao.RecurringPaymentEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.DueFrequency;
import com.projectgalen.pgbudget.db.jpa.enums.Month;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import com.projectgalen.pgbudget.db.jpa.enums.WeekDay;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.util.Objects;

@PGJPA(daoClass = RecurringPaymentEntityDao.class)
@Entity
@Table(name = "recurring_payment", schema = "pgbudget")
public class RecurringPaymentEntity extends _RecurringPaymentEntity {

    protected RecurringPaymentEntity() {
        super();
    }

    protected RecurringPaymentEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Contract(" -> new")
    public static @NotNull RecurringPaymentEntity getNewEntity() {
        RecurringPaymentEntity e = new RecurringPaymentEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }
    
    public static @NotNull ValidationResponse validate(String payee, BigDecimal amount, CategoryEntity category, DueFrequency dueFrequency, Month month1, Integer date1, Month month2, Integer date2, WeekDay weekDay1, WeekDay weekDay2) {
        if(U.z(payee)) return new ValidationResponse("Payee is required.");
        if(amount.compareTo(BigDecimal.ZERO) <= 0) return new ValidationResponse("A positive amount is required.");
        if(category == null) return new ValidationResponse("Category is required.");

        switch(dueFrequency) {
            case MONTHLY:
                if(date1 == null) return new ValidationResponse("The day of the month is required.");
                break;
            case TWICE_MONTHLY:
                if(date1 == null) return new ValidationResponse("The 1st day of the month is required.");
                if(date2 == null) return new ValidationResponse("The 2nd day of the month is required.");
                break;
            case WEEKLY:
                if(weekDay1 == null) return new ValidationResponse("The day of the week is required.");
                break;
            case BIWEEKLY:
                if(weekDay1 == null) return new ValidationResponse("The 1st day of the week is required.");
                if(weekDay2 == null) return new ValidationResponse("The 2nd day of the week is required.");
                break;
            case YEARLY:
                if((month1 == null) || (date1 == null)) return new ValidationResponse("The month and date are required.");
                break;
            case TWICE_YEARLY:
                if((month1 == null) || (date1 == null)) return new ValidationResponse("The 1st month and date are required.");
                if((month2 == null) || (date2 == null)) return new ValidationResponse("The 2nd month and date are required.");
                break;
            default:
                return new ValidationResponse("You must choose a payment frequency.");
        }
        return new ValidationResponse();
    }

}
