package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: LoginHistoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.events.JpaEventBase.EventType;
import com.projectgalen.pgbudget.db.events.users.UsersLoginEvent;
import com.projectgalen.pgbudget.db.events.users.UsersLoginListener;
import com.projectgalen.pgbudget.db.jpa.base._LoginHistoryEntity;
import com.projectgalen.pgbudget.db.jpa.dao.LoginHistoryEntityDao;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.NotNull;

@PGJPA(daoClass = LoginHistoryEntityDao.class)
@Entity
@Table(name = "login_history", schema = "pgbudget")
public class LoginHistoryEntity extends _LoginHistoryEntity {

    protected LoginHistoryEntity() {
        super();
    }

    protected LoginHistoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public void saveChanges(boolean deep) {
        _saveChanges(deep, EventType.Changed);
    }

    private void _saveChanges(boolean deep, EventType eventType) {
        super.saveChanges(deep);
        getToUser().fireUsersEvent(UsersLoginListener.class, new UsersLoginEvent(getToUser(), eventType, this));
    }

    public static @NotNull LoginHistoryEntity createNewLoginHistory(@NotNull UsersEntity user) {
        LoginHistoryEntity e = new LoginHistoryEntity(false);
        e.setToUser(user);
        user.setDateLastLogin(e.getDateLogin());
        e._saveChanges(true, EventType.Added);
        return e;
    }
}
