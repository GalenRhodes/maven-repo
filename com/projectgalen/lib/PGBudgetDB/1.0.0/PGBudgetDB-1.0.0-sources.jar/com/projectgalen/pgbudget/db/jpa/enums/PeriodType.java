package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: PeriodType.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Range;

import static com.projectgalen.pgbudget.db.C.msgs;

public enum PeriodType {

    OTHER(0), MONTHLY(1), WEEKLY(2), BIWEEKLY(3), TWICE_MONTHLY(4);

    private final @Range(from = 0, to = 4) int id;

    PeriodType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    @Override
    public @NotNull String toString() {
        return msgs.getString(String.format("enum.period_type.name.%d", id));
    }

    public static @NotNull PeriodType getType(@Range(from = 0, to = 4) int id) {
        for(PeriodType e : PeriodType.values()) if(e.id == id) return e;
        throw new IllegalArgumentException(msgs.format("msg.err.invalid_enum_id", msgs.getString("msgs.period_type"), id));
    }
}
