package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: PeriodType.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.pgbudget.db.C;
import org.jetbrains.annotations.Range;

public enum PeriodType {

    OTHER(0), MONTHLY(1), WEEKLY(2), BIWEEKLY(3), TWICE_MONTHLY(4);

    private final @Range(from = 0, to = 4) int id;

    PeriodType(int id) {
        this.id = id;
    }

    public int getId() { return id; }

    @Override
    public String toString() {
        switch(id) {/*@f0*/
            case 0: return C.msgs.getString("enum.period_type.name.0");
            case 1: return C.msgs.getString("enum.period_type.name.1");
            case 2: return C.msgs.getString("enum.period_type.name.2");
            case 3: return C.msgs.getString("enum.period_type.name.3");
            case 4: return C.msgs.getString("enum.period_type.name.4");
            default: return super.toString();
        }/*@f1*/
    }

    public static PeriodType getType(@Range(from = 0, to = 4) int id) {
        switch(id) {/*@f0*/
            case 1: return MONTHLY;
            case 2: return WEEKLY;
            case 3: return BIWEEKLY;
            case 4: return TWICE_MONTHLY;
            default: return OTHER;
        }/*@f1*/
    }
}
