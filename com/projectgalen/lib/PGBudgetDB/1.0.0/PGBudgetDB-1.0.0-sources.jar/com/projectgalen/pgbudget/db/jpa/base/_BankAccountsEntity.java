package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BankAccountsEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.converters.BooleanConverter;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings({ "unused", "SpellCheckingInspection" })
public class _BankAccountsEntity extends JpaBase {

    protected @Column(name = "bank_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         bankId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                       Long         budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                           Long         kvId;
    protected @Column(name = "current_period_id", precision = 19, insertable = false, updatable = false)                                                                 Long         currentPeriodId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State        state;
    protected @Column(name = "bank_name", nullable = false)                                                                                                              String       bankName;
    protected @Column(name = "bank_name_abbreviation", nullable = false, length = 5)                                                                                     String       bankNameAbbreviation;
    protected @Column(name = "current_balance", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                          BigDecimal   currentBalance;
    protected @Column(name = "is_default", nullable = false, precision = 3) @Convert(converter = BooleanConverter.class) @PGDefaultValue("false")                        Boolean      isDefault;
    protected @Column(name = "start_date")                                                                                                                               Date         startDate;
    protected @Column(name = "end_date")                                                                                                                                 Date         endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                             BudgetEntity toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                     KvInfoEntity toKeyValueInfo;
    protected @ManyToOne @JoinColumn(name = "current_period_id", referencedColumnName = "period_id")                                                                     PeriodEntity toCurrentPeriod;

    protected _BankAccountsEntity() { }

    protected _BankAccountsEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.currentBalance = BigDecimal.ZERO;
        this.isDefault = false;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof BankAccountsEntity) && _equals((BankAccountsEntity)o))));
    }

    public Long getBankId() {
        return Locks.getWithLock(lock, () -> this.bankId);
    }

    public String getBankName() {
        return Locks.getWithLock(lock, () -> this.bankName);
    }

    public String getBankNameAbbreviation() {
        return Locks.getWithLock(lock, () -> this.bankNameAbbreviation);
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public BigDecimal getCurrentBalance() {
        return Locks.getWithLock(lock, () -> this.currentBalance);
    }

    public Long getCurrentPeriodId() {
        return Locks.getWithLock(lock, () -> this.currentPeriodId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Date getEndDate() {
        return Locks.getWithLock(lock, () -> this.endDate);
    }

    public Boolean getIsDefault() {
        return Locks.getWithLock(lock, () -> this.isDefault);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public Date getStartDate() {
        return Locks.getWithLock(lock, () -> this.startDate);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public BudgetEntity getToBudget() {
        return Locks.getWithLock(lock, () -> this.toBudget);
    }

    public PeriodEntity getToCurrentPeriod() {
        return Locks.getWithLock(lock, () -> this.toCurrentPeriod);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<PeriodItemEntity> getToPeriodItems() {
        return HibernateUtil.find(PeriodItemEntity.class, wrap("toBank"), wrap(this));
    }

    public List<RecurringPaymentEntity> getToRecurringPayments() {
        return HibernateUtil.find(RecurringPaymentEntity.class, wrap("toBank"), wrap(this));
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(bankId, budgetId, kvId, currentPeriodId, state, bankName, bankNameAbbreviation, currentBalance, isDefault, startDate, endDate, dateCreated, dateUpdated));
    }

    public void setBankName(@NotNull String bankName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.bankName, bankName)) {
                this.bankName = bankName;
                addValueToChangeMap("bankName", this.bankName);
                setAsDirty();
            }
        });
    }

    public void setBankNameAbbreviation(@NotNull String bankNameAbbreviation) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.bankNameAbbreviation, bankNameAbbreviation)) {
                this.bankNameAbbreviation = bankNameAbbreviation;
                addValueToChangeMap("bankNameAbbreviation", this.bankNameAbbreviation);
                setAsDirty();
            }
        });
    }

    public void setCurrentBalance(@NotNull BigDecimal currentBalance) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.currentBalance, currentBalance)) {
                this.currentBalance = currentBalance;
                addValueToChangeMap("currentBalance", this.currentBalance);
                setAsDirty();
            }
        });
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setEndDate(@Nullable Date endDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.endDate, endDate)) {
                this.endDate = endDate;
                addValueToChangeMap("endDate", this.endDate);
                setAsDirty();
            }
        });
    }

    public void setIsDefault(@NotNull Boolean isDefault) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.isDefault, isDefault)) {
                this.isDefault = isDefault;
                addValueToChangeMap("isDefault", this.isDefault);
                setAsDirty();
            }
        });
    }

    public void setStartDate(@Nullable Date startDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.startDate, startDate)) {
                this.startDate = startDate;
                addValueToChangeMap("startDate", this.startDate);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToBudget(BudgetEntity toBudget) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toBudget, toBudget)) {
                this.toBudget = toBudget;
                addValueToChangeMap("budgetId", this.budgetId);
                setAsDirty();
            }
        });
    }

    public void setToCurrentPeriod(PeriodEntity toCurrentPeriod) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toCurrentPeriod, toCurrentPeriod)) {
                this.toCurrentPeriod = toCurrentPeriod;
                addValueToChangeMap("currentPeriodId", this.currentPeriodId);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull BankAccountsEntity other) {/*@f0*/
        return (Objects.equals(bankId, other.bankId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(currentPeriodId, other.currentPeriodId)
                && Objects.equals(state, other.state)
                && Objects.equals(bankName, other.bankName)
                && Objects.equals(bankNameAbbreviation, other.bankNameAbbreviation)
                && Objects.equals(currentBalance, other.currentBalance)
                && Objects.equals(isDefault, other.isDefault)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
