package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BankAccountsEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.BankAccountsEntity;
import com.projectgalen.pgbudget.db.jpa.BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.PeriodEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BankAccountsEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@MappedSuperclass
public class _BankAccountsEntity extends JpaBase {
    protected @Column(name = "bank_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         bankId;
    protected @Column(name = "budget_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                       Long         budgetId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                           Long         kvId;
    protected @Column(name = "current_period_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                                 Long         currentPeriodId;
    protected @Column(name = "state", nullable = false, precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State        state;
    protected @Column(name = "bank_name", nullable = false, length = 255)                                                                                                           String       bankName;
    protected @Column(name = "current_balance", nullable = false, precision = 10, scale = 2) @PGDefaultValue("BigDecimal.ZERO")                                                     BigDecimal   currentBalance;
    protected @Column(name = "start_date")                                                                                                                                          Date         startDate;
    protected @Column(name = "end_date")                                                                                                                                            Date         endDate;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                  Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                  Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "budget_id", referencedColumnName = "budget_id")                                                                                        BudgetEntity toBudget;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                                KvInfoEntity toKeyValueInfo;
    protected @ManyToOne @JoinColumn(name = "current_period_id", referencedColumnName = "period_id")                                                                                PeriodEntity toCurrentPeriod;

    public _BankAccountsEntity() { }

    public _BankAccountsEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state          = State.ACTIVE;
        this.currentBalance = BigDecimal.ZERO;
        this.dateCreated    = Dates.getTimestamp();
        this.dateUpdated    = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof BankAccountsEntity) && _equals((BankAccountsEntity)o)));
    }

    public Long getBankId() {
        return this.bankId;
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Long getCurrentPeriodId() {
        return this.currentPeriodId;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public String getBankName() {
        return this.bankName;
    }

    public BigDecimal getCurrentBalance() {
        return this.currentBalance;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public State getState() {
        return this.state;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public BudgetEntity getToBudget() {
        return this.toBudget;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public PeriodEntity getToCurrentPeriod() {
        return this.toCurrentPeriod;
    }

    @Override
    public int hashCode() {
        return Objects.hash(bankId, budgetId, kvId, currentPeriodId, state, bankName, currentBalance, startDate, endDate, dateCreated, dateUpdated);
    }

    public void setBankName(@NotNull String bankName) {
        if(Objects.equals(this.bankName, bankName)) return;
        this.bankName = bankName;
        setAsDirty();
    }

    public void setCurrentBalance(@NotNull BigDecimal currentBalance) {
        if(Objects.equals(this.currentBalance, currentBalance)) return;
        this.currentBalance = currentBalance;
        setAsDirty();
    }

    public void setStartDate(@Nullable Date startDate) {
        if(Objects.equals(this.startDate, startDate)) return;
        this.startDate = startDate;
        setAsDirty();
    }

    public void setEndDate(@Nullable Date endDate) {
        if(Objects.equals(this.endDate, endDate)) return;
        this.endDate = endDate;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToBudget(BudgetEntity toBudget) {
        if(Objects.equals(this.toBudget, toBudget)) return;
        this.toBudget = toBudget;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setToCurrentPeriod(PeriodEntity toCurrentPeriod) {
        if(Objects.equals(this.toCurrentPeriod, toCurrentPeriod)) return;
        this.toCurrentPeriod = toCurrentPeriod;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    @Contract(pure = true)
    public static @NotNull BankAccountsEntityDao getDao() {
        return BankAccountsEntityDao.shared();
    }

    private boolean _equals(@NotNull BankAccountsEntity other) {/*@f0*/
        return (Objects.equals(bankId, other.bankId)
                && Objects.equals(budgetId, other.budgetId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(currentPeriodId, other.currentPeriodId)
                && Objects.equals(state, other.state)
                && Objects.equals(bankName, other.bankName)
                && Objects.equals(currentBalance, other.currentBalance)
                && Objects.equals(startDate, other.startDate)
                && Objects.equals(endDate, other.endDate)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
