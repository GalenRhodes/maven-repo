package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: State.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 09, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.pgbudget.db.converters.JComboBoxItem;
import org.jetbrains.annotations.NotNull;

import static com.projectgalen.pgbudget.db.C.msgs;

public enum State implements JComboBoxItem {
    INACTIVE(-1), ACTIVE(1);

    private final int id;

    State(int id) {
        this.id = id;
    }

    @Override
    public @NotNull String getComboBoxText() {
        return toString();
    }

    public int getValue() {
        return id;
    }

    @Override
    public String toString() {
        return msgs.getString(String.format("enum.state.name.%d", id + 1), super.toString());
    }

    public static @NotNull State getState(int id) {
        for(State e : State.values()) if(e.id == id) return e;
        throw new IllegalArgumentException(msgs.format("msg.err.invalid_enum_id", msgs.getString("msg.state"), id));
    }
}
