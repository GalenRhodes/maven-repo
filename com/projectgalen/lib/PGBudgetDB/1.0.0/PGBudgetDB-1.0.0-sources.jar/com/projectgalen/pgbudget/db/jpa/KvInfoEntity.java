package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvInfoEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.Null;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.pgbudget.db.jpa.base._KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.dao.KvInfoEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

@PGJPA(daoClass = KvInfoEntityDao.class)
@Entity
@Table(name = "kv_info", schema = "pgbudget")
public class KvInfoEntity extends _KvInfoEntity {

    protected KvInfoEntity() {
        super();
    }

    protected KvInfoEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Transient
    public @NotNull Map<String, String> getAll() {
        Map<String, String> map = new TreeMap<>();
        for(KvDataEntity kvData : getToKvDatas()) map.put(kvData.getKvKey(), kvData.getKvValue());
        return map;
    }

    @Transient
    public @NotNull List<String> getAllNames() {
        List<String> list = new ArrayList<>();
        for(KvDataEntity kvData : getToKvDatas()) list.add(kvData.getKvKey());
        return list;
    }

    public @Nullable KvDataEntity getKvDataForName(@NotNull String name) {
        return HibernateUtil.get(KvDataEntity.class, PGArrays.wrap("state", "toKeyValueInfo", "kvKey"), PGArrays.wrap(State.ACTIVE, this, name));
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    @Transient
    public List<KvDataEntity> getToKvDatas() {
        return HibernateUtil.find(KvDataEntity.class, PGArrays.wrap("state", "toKeyValueInfo"), PGArrays.wrap(State.ACTIVE, this));
    }

    public @Nullable String getValueForName(@NotNull String name) {
        return Null.getIfNotNull(getKvDataForName(name), null, KvDataEntity::getKvValue);
    }

    public @Nullable String removeValueForName(@NotNull String name) {
        return Null.getIfNotNull(getKvDataForName(name), null, kvData -> {
            kvData.setState(State.INACTIVE);
            kvData.saveChanges();
            return kvData.getKvValue();
        });
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    public @Nullable String setValueForName(@NotNull String name, @NotNull String value) {
        KvDataEntity kvData = HibernateUtil.get(KvDataEntity.class, PGArrays.wrap("toKeyValueInfo", "kvKey"), PGArrays.wrap(this, name));

        if(kvData == null) {
            KvDataEntity.createNew(name, value, this);
            return null;
        }

        String pValue = kvData.getKvValue();
        kvData.setKvValue(value);
        kvData.setState(State.ACTIVE);
        kvData.saveChanges();
        return pValue;
    }

    @Contract(" -> new")
    public static @NotNull KvInfoEntity getNewEntity() {
        return new KvInfoEntity(false);
    }
}
