package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvInfoEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 7, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.jpa.base._KvInfoEntity;
import com.projectgalen.pgbudget.db.jpa.dao.KvInfoEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

@PGJPA(daoClass = KvInfoEntityDao.class)
@Entity
@Table(name = "kv_info", schema = "pgbudget")
public class KvInfoEntity extends _KvInfoEntity {

    public KvInfoEntity() { super(); }

    public KvInfoEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    public @NotNull
    @Transient List<String> getAllNames() {
        List<String> list = new ArrayList<>();
        for(KvDataEntity kvData : toKvDatas) if(State.ACTIVE == kvData.getState()) list.add(kvData.getKvKey());
        return list;
    }

    public @Nullable KvDataEntity getKvDataForName(@NotNull String name) {
        KvDataEntity kvData = _getKvDataForName(name);
        return (((kvData != null) && (State.ACTIVE == kvData.getState())) ? kvData : null);
    }

    @Override
    public @NotNull State getState() {
        State _state = super.getState();
        return ((_state == null) ? State.INACTIVE : _state);
    }

    public @Nullable String getValueForName(@NotNull String name) {
        KvDataEntity kvData = getKvDataForName(name);
        return ((kvData == null) ? null : kvData.getKvValue());
    }

    public @Nullable String setValueForName(@NotNull String name, @NotNull String value) {
        KvDataEntity kvData        = _getKvDataForName(name);
        String       previousValue = null;
        if(kvData == null) {
            kvData = KvDataEntity.getNewEntity();
            kvData.setKvKey(name);
            kvData.setToKeyValueInfo(this);
        }
        else {
            previousValue = kvData.getKvValue();
        }
        if(kvData.getState() == State.INACTIVE) kvData.setState(State.ACTIVE);
        kvData.setKvValue(value);
        kvData.saveChanges();
        return previousValue;
    }

    private @Nullable KvDataEntity _getKvDataForName(@NotNull String name) {
        for(KvDataEntity kvData : toKvDatas) if(name.equals(kvData.getKvKey())) return kvData;
        return null;
    }

    public static @NotNull KvInfoEntity getNewEntity() { return KvInfoEntityDao.shared().getNewEntity(); }
}
