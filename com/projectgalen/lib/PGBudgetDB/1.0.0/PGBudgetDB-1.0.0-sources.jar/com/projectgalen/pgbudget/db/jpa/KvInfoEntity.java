package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: KvInfoEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "kv_info", schema = "pgbudget")
public class KvInfoEntity extends JpaBase {
    private @Column(name = "kv_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY)                    Long                               kvId;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                              state;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp                          dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp                          dateUpdated;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<BudgetEntity>           toBudgets;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<IncomeSourceEntity>     toIncomeSources;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<KvDataEntity>           toKvDatas;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<PeriodIncomeEntity>     toPeriodIncomes;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<PeriodItemEntity>       toPeriodItems;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<RecurringPaymentEntity> toRecurringPayments;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<SessionEntity>          toSessions;
    private @OneToMany(mappedBy = "toKv", fetch = FetchType.LAZY)                                                                         Collection<UsersEntity>            toUsers;

    public KvInfoEntity() { }

    public KvInfoEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getKvId() {
        return this.kvId;
    }

    public State getState() {
        return this.state;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public Collection<BudgetEntity> getToBudgets() {
        return Collections.unmodifiableCollection(this.toBudgets);
    }

    public Collection<IncomeSourceEntity> getToIncomeSources() {
        return Collections.unmodifiableCollection(this.toIncomeSources);
    }

    public Collection<KvDataEntity> getToKvDatas() {
        return Collections.unmodifiableCollection(this.toKvDatas);
    }

    public Collection<PeriodIncomeEntity> getToPeriodIncomes() {
        return Collections.unmodifiableCollection(this.toPeriodIncomes);
    }

    public Collection<PeriodItemEntity> getToPeriodItems() {
        return Collections.unmodifiableCollection(this.toPeriodItems);
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public Collection<SessionEntity> getToSessions() {
        return Collections.unmodifiableCollection(this.toSessions);
    }

    public Collection<UsersEntity> getToUsers() {
        return Collections.unmodifiableCollection(this.toUsers);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void addToBudgets(@NotNull BudgetEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToBudgets(object);
        object.setToKv(this);
        if(!this.toBudgets.contains(object)) this.toBudgets.add(object);
        setAsDirty();
    }

    public void addToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToIncomeSources(object);
        object.setToKv(this);
        if(!this.toIncomeSources.contains(object)) this.toIncomeSources.add(object);
        setAsDirty();
    }

    public void addToKvDatas(@NotNull KvDataEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToKvDatas(object);
        object.setToKv(this);
        if(!this.toKvDatas.contains(object)) this.toKvDatas.add(object);
        setAsDirty();
    }

    public void addToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToPeriodIncomes(object);
        object.setToKv(this);
        if(!this.toPeriodIncomes.contains(object)) this.toPeriodIncomes.add(object);
        setAsDirty();
    }

    public void addToPeriodItems(@NotNull PeriodItemEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToPeriodItems(object);
        object.setToKv(this);
        if(!this.toPeriodItems.contains(object)) this.toPeriodItems.add(object);
        setAsDirty();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToRecurringPayments(object);
        object.setToKv(this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public void addToSessions(@NotNull SessionEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToSessions(object);
        object.setToKv(this);
        if(!this.toSessions.contains(object)) this.toSessions.add(object);
        setAsDirty();
    }

    public void addToUsers(@NotNull UsersEntity object) {
        if(Objects.equals(object.getToKv(), this)) return;
        if(object.getToKv() != null) object.getToKv().removeFromToUsers(object);
        object.setToKv(this);
        if(!this.toUsers.contains(object)) this.toUsers.add(object);
        setAsDirty();
    }

    public void removeFromToBudgets(@NotNull BudgetEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toBudgets.remove(object);
        setAsDirty();
    }

    public void removeFromToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toIncomeSources.remove(object);
        setAsDirty();
    }

    public void removeFromToKvDatas(@NotNull KvDataEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toKvDatas.remove(object);
        setAsDirty();
    }

    public void removeFromToPeriodIncomes(@NotNull PeriodIncomeEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toPeriodIncomes.remove(object);
        setAsDirty();
    }

    public void removeFromToPeriodItems(@NotNull PeriodItemEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toPeriodItems.remove(object);
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }

    public void removeFromToSessions(@NotNull SessionEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toSessions.remove(object);
        setAsDirty();
    }

    public void removeFromToUsers(@NotNull UsersEntity object) {
        if(!Objects.equals(object.getToKv(), this)) return;
        object.setToKv(null);
        this.toUsers.remove(object);
        setAsDirty();
    }
}
