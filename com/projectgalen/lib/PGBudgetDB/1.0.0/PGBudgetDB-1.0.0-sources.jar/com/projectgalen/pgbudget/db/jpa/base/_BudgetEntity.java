package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.PeriodTypeConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _BudgetEntity extends JpaBase {

    protected @Column(name = "budget_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         budgetId;
    protected @Column(name = "user_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                           Long         userId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                             Long         kvId;
    protected @Column(name = "name", nullable = false)                                                                                                                     String       name;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                         State        state;
    protected @Column(name = "starting_date", nullable = false)                                                                                                            Date         startingDate;
    protected @Column(name = "ending_date")                                                                                                                                Date         endingDate;
    protected @Column(name = "period_type", nullable = false, precision = 10) @Convert(converter = PeriodTypeConverter.class) @PGDefaultValue("PeriodType.BIWEEKLY")       PeriodType   periodType;
    protected @Column(name = "period_date1", precision = 10)                                                                                                               Integer      periodDate1;
    protected @Column(name = "period_date2", precision = 10)                                                                                                               Integer      periodDate2;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                         Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                                   UsersEntity  toUser;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                       KvInfoEntity toKeyValueInfo;

    protected _BudgetEntity() { }

    protected _BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.periodType = PeriodType.BIWEEKLY;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof BudgetEntity) && _equals((BudgetEntity)o))));
    }

    public Long getBudgetId() {
        return Locks.getWithLock(lock, () -> this.budgetId);
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public Date getEndingDate() {
        return Locks.getWithLock(lock, () -> this.endingDate);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public String getName() {
        return Locks.getWithLock(lock, () -> this.name);
    }

    public Integer getPeriodDate1() {
        return Locks.getWithLock(lock, () -> this.periodDate1);
    }

    public Integer getPeriodDate2() {
        return Locks.getWithLock(lock, () -> this.periodDate2);
    }

    public PeriodType getPeriodType() {
        return Locks.getWithLock(lock, () -> this.periodType);
    }

    public Date getStartingDate() {
        return Locks.getWithLock(lock, () -> this.startingDate);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public List<BankAccountsEntity> getToBankAccounts() {
        return HibernateUtil.find(BankAccountsEntity.class, wrap("toBudget"), wrap(this));
    }

    public List<IncomeSourceEntity> getToIncomeSources() {
        return HibernateUtil.find(IncomeSourceEntity.class, wrap("toBudget"), wrap(this));
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<OtherPeriodDatesEntity> getToOtherPeriodDates() {
        return HibernateUtil.find(OtherPeriodDatesEntity.class, wrap("toBudget"), wrap(this));
    }

    public List<PeriodEntity> getToPeriods() {
        return HibernateUtil.find(PeriodEntity.class, wrap("toBudget"), wrap(this));
    }

    public List<RecurringPaymentEntity> getToRecurringPayments() {
        return HibernateUtil.find(RecurringPaymentEntity.class, wrap("toBudget"), wrap(this));
    }

    public UsersEntity getToUser() {
        return Locks.getWithLock(lock, () -> this.toUser);
    }

    public Long getUserId() {
        return Locks.getWithLock(lock, () -> this.userId);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(budgetId, userId, kvId, name, state, startingDate, endingDate, periodType, periodDate1, periodDate2, dateCreated, dateUpdated));
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setEndingDate(@Nullable Date endingDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.endingDate, endingDate)) {
                this.endingDate = endingDate;
                addValueToChangeMap("endingDate", this.endingDate);
                setAsDirty();
            }
        });
    }

    public void setName(@NotNull String name) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.name, name)) {
                this.name = name;
                addValueToChangeMap("name", this.name);
                setAsDirty();
            }
        });
    }

    public void setPeriodDate1(@Nullable Integer periodDate1) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.periodDate1, periodDate1)) {
                this.periodDate1 = periodDate1;
                addValueToChangeMap("periodDate1", this.periodDate1);
                setAsDirty();
            }
        });
    }

    public void setPeriodDate2(@Nullable Integer periodDate2) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.periodDate2, periodDate2)) {
                this.periodDate2 = periodDate2;
                addValueToChangeMap("periodDate2", this.periodDate2);
                setAsDirty();
            }
        });
    }

    public void setPeriodType(@NotNull PeriodType periodType) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.periodType, periodType)) {
                this.periodType = periodType;
                addValueToChangeMap("periodType", this.periodType);
                setAsDirty();
            }
        });
    }

    public void setStartingDate(@NotNull Date startingDate) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.startingDate, startingDate)) {
                this.startingDate = startingDate;
                addValueToChangeMap("startingDate", this.startingDate);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    public void setToUser(UsersEntity toUser) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toUser, toUser)) {
                this.toUser = toUser;
                addValueToChangeMap("userId", this.userId);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull BudgetEntity other) {/*@f0*/
        return (Objects.equals(budgetId, other.budgetId)
                && Objects.equals(userId, other.userId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(name, other.name)
                && Objects.equals(state, other.state)
                && Objects.equals(startingDate, other.startingDate)
                && Objects.equals(endingDate, other.endingDate)
                && Objects.equals(periodType, other.periodType)
                && Objects.equals(periodDate1, other.periodDate1)
                && Objects.equals(periodDate2, other.periodDate2)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
