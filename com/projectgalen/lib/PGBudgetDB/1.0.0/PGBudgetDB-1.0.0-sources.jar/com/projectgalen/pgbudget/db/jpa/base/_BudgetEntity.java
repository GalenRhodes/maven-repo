package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 20, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import jakarta.persistence.*;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Contract;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.PeriodTypeConverter;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _BudgetEntity extends JpaBase {
    protected @Column(name = "budget_id", precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                               budgetId;
    protected @Column(name = "user_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                           Long                               userId;
    protected @Column(name = "kv_id", precision = 19, scale = 0, insertable = false, updatable = false)                                                             Long                               kvId;
    protected @Column(name = "name", length = 255)                                                                                                                  String                             name;
    protected @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                         State                              state;
    protected @Column(name = "starting_date")                                                                                                                       Date                               startingDate;
    protected @Column(name = "period_type", precision = 10, scale = 0) @Convert(converter = PeriodTypeConverter.class) @PGDefaultValue("PeriodType.BIWEEKLY")       PeriodType                         periodType;
    protected @Column(name = "period_date1", nullable = true, precision = 10, scale = 0)                                                                            Integer                            periodDate1;
    protected @Column(name = "period_date2", nullable = true, precision = 10, scale = 0)                                                                            Integer                            periodDate2;
    protected @Column(name = "date_created") @PGCurrentTimestamp                                                                                                    Timestamp                          dateCreated;
    protected @Column(name = "date_updated") @PGCurrentTimestamp                                                                                                    Timestamp                          dateUpdated;
    protected @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                                            UsersEntity                        toUser;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                KvInfoEntity                       toKeyValueInfo;
    protected @OneToMany(mappedBy = "toBudget", fetch = FetchType.LAZY)                                                                                             Collection<IncomeSourceEntity>     toIncomeSources;
    protected @OneToMany(mappedBy = "toBudget", fetch = FetchType.LAZY)                                                                                             Collection<PeriodEntity>           toPeriods;
    protected @OneToMany(mappedBy = "toBudget", fetch = FetchType.LAZY)                                                                                             Collection<RecurringPaymentEntity> toRecurringPayments;

    public _BudgetEntity() {}

    public _BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.periodType  = PeriodType.BIWEEKLY;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Contract(pure = true)
    public static @NotNull BudgetEntityDao getDao() {
        return BudgetEntityDao.shared();
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Long getUserId() {
        return this.userId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getName() {
        return this.name;
    }

    public State getState() {
        return this.state;
    }

    public Date getStartingDate() {
        return this.startingDate;
    }

    public PeriodType getPeriodType() {
        return this.periodType;
    }

    public Integer getPeriodDate1() {
        return this.periodDate1;
    }

    public Integer getPeriodDate2() {
        return this.periodDate2;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public Collection<IncomeSourceEntity> getToIncomeSources() {
        return Collections.unmodifiableCollection(this.toIncomeSources);
    }

    public Collection<PeriodEntity> getToPeriods() {
        return Collections.unmodifiableCollection(this.toPeriods);
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public void setName(@NotNull String name) {
        if(Objects.equals(this.name, name)) return;
        this.name = name;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setStartingDate(@NotNull Date startingDate) {
        if(Objects.equals(this.startingDate, startingDate)) return;
        this.startingDate = startingDate;
        setAsDirty();
    }

    public void setPeriodType(@NotNull PeriodType periodType) {
        if(Objects.equals(this.periodType, periodType)) return;
        this.periodType = periodType;
        setAsDirty();
    }

    public void setPeriodDate1(@Nullable Integer periodDate1) {
        if(Objects.equals(this.periodDate1, periodDate1)) return;
        this.periodDate1 = periodDate1;
        setAsDirty();
    }

    public void setPeriodDate2(@Nullable Integer periodDate2) {
        if(Objects.equals(this.periodDate2, periodDate2)) return;
        this.periodDate2 = periodDate2;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void addToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(Objects.equals(object.getToBudget(), this)) return;
        if(object.getToBudget() != null) object.getToBudget().removeFromToIncomeSources(object);
        object.setToBudget((BudgetEntity)this);
        if(!this.toIncomeSources.contains(object)) this.toIncomeSources.add(object);
        setAsDirty();
    }

    public void removeFromToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(!Objects.equals(object.getToBudget(), this)) return;
        object.setToBudget(null);
        this.toIncomeSources.remove(object);
        setAsDirty();
    }

    public void addToPeriods(@NotNull PeriodEntity object) {
        if(Objects.equals(object.getToBudget(), this)) return;
        if(object.getToBudget() != null) object.getToBudget().removeFromToPeriods(object);
        object.setToBudget((BudgetEntity)this);
        if(!this.toPeriods.contains(object)) this.toPeriods.add(object);
        setAsDirty();
    }

    public void removeFromToPeriods(@NotNull PeriodEntity object) {
        if(!Objects.equals(object.getToBudget(), this)) return;
        object.setToBudget(null);
        this.toPeriods.remove(object);
        setAsDirty();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToBudget(), this)) return;
        if(object.getToBudget() != null) object.getToBudget().removeFromToRecurringPayments(object);
        object.setToBudget((BudgetEntity)this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToBudget(), this)) return;
        object.setToBudget(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }



    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof BudgetEntity) && _equals((BudgetEntity)o)));
    }

    @Override
    public int hashCode() {
        return Objects.hash(budgetId, userId, kvId, name, state, startingDate, periodType, periodDate1, periodDate2, dateCreated, dateUpdated);
    }

    private boolean _equals(@NotNull BudgetEntity other) {/*@f0*/
        return (Objects.equals(budgetId, other.budgetId)
                && Objects.equals(userId, other.userId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(name, other.name)
                && Objects.equals(state, other.state)
                && Objects.equals(startingDate, other.startingDate)
                && Objects.equals(periodType, other.periodType)
                && Objects.equals(periodDate1, other.periodDate1)
                && Objects.equals(periodDate2, other.periodDate2)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
