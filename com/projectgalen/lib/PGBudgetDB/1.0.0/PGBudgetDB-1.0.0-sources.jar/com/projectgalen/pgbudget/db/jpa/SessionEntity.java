package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: SessionEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.jpa.base._SessionEntity;
import com.projectgalen.pgbudget.db.jpa.dao.SessionEntityDao;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

@PGJPA(daoClass = SessionEntityDao.class)
@Entity
@Table(name = "session", schema = "pgbudget")
public class SessionEntity extends _SessionEntity {

    protected SessionEntity() {
        super();
    }

    protected SessionEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    @Contract(" -> new")
    public static @NotNull SessionEntity getNewEntity() {
        SessionEntity e = new SessionEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        e.setToLogin(LoginHistoryEntity.getNewEntity());
        return e;
    }
}
