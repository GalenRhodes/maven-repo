package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: SessionEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "session", schema = "pgbudget")
public class SessionEntity extends JpaBase {
    private @Column(name = "session_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long               sessionId;
    private @Column(name = "login_id", precision = 19, scale = 0)                                                           Long               loginId;
    private @Column(name = "kv_id", precision = 19, scale = 0)                                                              Long               kvId;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                              Timestamp          dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                              Timestamp          dateUpdated;
    private @ManyToOne @JoinColumn(name = "login_id", referencedColumnName = "history_id")                                  LoginHistoryEntity toLogin;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                          KvInfoEntity       toKv;

    public SessionEntity() { }

    public SessionEntity(@SuppressWarnings("unused") boolean dummy) {
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getSessionId() {
        return this.sessionId;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Long getLoginId() {
        return this.loginId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public LoginHistoryEntity getToLogin() {
        return this.toLogin;
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setLoginId(@NotNull Long loginId) {
        if(Objects.equals(this.loginId, loginId)) return;
        this.loginId = loginId;
        setAsDirty();
    }

    public void setSessionId(@NotNull Long sessionId) {
        if(Objects.equals(this.sessionId, sessionId)) return;
        this.sessionId = sessionId;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void setToLogin(LoginHistoryEntity toLogin) {
        if(Objects.equals(this.toLogin, toLogin)) return;
        this.toLogin = toLogin;
        setAsDirty();
    }
}
