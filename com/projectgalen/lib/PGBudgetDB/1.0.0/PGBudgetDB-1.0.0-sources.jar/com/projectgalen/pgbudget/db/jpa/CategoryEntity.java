package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: CategoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "category", schema = "pgbudget")
public class CategoryEntity extends JpaBase {
    private @Column(name = "category_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY)              Long                               categoryId;
    private @Column(name = "user_id", precision = 19, scale = 0)                                                                          Long                               userId;
    private @Column(name = "name", length = 255)                                                                                          String                             name;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                              state;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp                          dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp                          dateUpdated;
    private @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                    UsersEntity                        toUser;
    private @OneToMany(mappedBy = "toCategory", fetch = FetchType.LAZY)                                                                   Collection<RecurringPaymentEntity> toRecurringPayments;

    public CategoryEntity() { }

    public CategoryEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public String getName() {
        return this.name;
    }

    public State getState() {
        return this.state;
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public Long getUserId() {
        return this.userId;
    }

    public void setCategoryId(@NotNull Long categoryId) {
        if(Objects.equals(this.categoryId, categoryId)) return;
        this.categoryId = categoryId;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setName(@NotNull String name) {
        if(Objects.equals(this.name, name)) return;
        this.name = name;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void setUserId(@NotNull Long userId) {
        if(Objects.equals(this.userId, userId)) return;
        this.userId = userId;
        setAsDirty();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToCategory(), this)) return;
        if(object.getToCategory() != null) object.getToCategory().removeFromToRecurringPayments(object);
        object.setToCategory(this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToCategory(), this)) return;
        object.setToCategory(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }
}
