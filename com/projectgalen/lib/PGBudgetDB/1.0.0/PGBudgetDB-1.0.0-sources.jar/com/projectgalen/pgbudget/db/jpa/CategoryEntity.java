package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: CategoryEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.converters.JComboBoxItem;
import com.projectgalen.pgbudget.db.events.JpaEventBase;
import com.projectgalen.pgbudget.db.events.JpaEventBase.EventType;
import com.projectgalen.pgbudget.db.events.users.UsersCategoryEvent;
import com.projectgalen.pgbudget.db.events.users.UsersCategoryListener;
import com.projectgalen.pgbudget.db.jpa.base._CategoryEntity;
import com.projectgalen.pgbudget.db.jpa.dao.CategoryEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

@SuppressWarnings("UnusedReturnValue")
@PGJPA(daoClass = CategoryEntityDao.class)
@Entity
@Table(name = "category", schema = "pgbudget")
public class CategoryEntity extends _CategoryEntity implements JComboBoxItem {
    private @Transient State oldState = null;

    protected CategoryEntity() {
        super();
    }

    protected CategoryEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Transient
    @Override
    public String getComboBoxText() {
        return getName();
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        JpaEventBase.EventType eventType = ((oldState == null) ? EventType.Changed : EventType.Removed);
        _saveChanges(deep, eventType);
        oldState = null;
    }

    @Override
    public void setState(@NotNull State state) {
        if(state != getState()) {
            if(oldState == null) oldState = getState();
            else if(state == oldState) oldState = null;
            super.setState(state);
        }
    }

    private void _saveChanges(boolean deep, EventType eventType) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
        getToUser().fireUsersEvent(UsersCategoryListener.class, new UsersCategoryEvent(getToUser(), eventType, this));
    }

    @Contract("_, _, _ -> new")
    public static @NotNull CategoryEntity createNewCategory(@NotNull UsersEntity user, @NotNull String name, boolean isDefault) {
        CategoryEntity cat = new CategoryEntity(false);
        cat.setName(name.trim());
        cat.setIsDefault(isDefault);
        cat.setToUser(user);
        cat._saveChanges(true, EventType.Added);
        return cat;
    }
}
