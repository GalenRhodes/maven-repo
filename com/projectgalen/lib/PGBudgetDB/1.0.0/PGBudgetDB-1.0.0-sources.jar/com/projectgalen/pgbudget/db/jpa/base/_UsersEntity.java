package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 4, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

@MappedSuperclass
public class _UsersEntity extends JpaBase {

    protected @Column(name = "user_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         userId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                           Long         kvId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State        state;
    protected @Column(name = "username", nullable = false, unique = true)                                                                                                String       username;
    protected @Column(name = "password", nullable = false)                                                                                                               String       password;
    protected @Column(name = "email_address", nullable = false, unique = true)                                                                                           String       emailAddress;
    protected @Column(name = "name_prefix")                                                                                                                              String       namePrefix;
    protected @Column(name = "first_name", nullable = false)                                                                                                             String       firstName;
    protected @Column(name = "middle_name")                                                                                                                              String       middleName;
    protected @Column(name = "last_name", nullable = false)                                                                                                              String       lastName;
    protected @Column(name = "name_suffix")                                                                                                                              String       nameSuffix;
    protected @Column(name = "date_of_birth", nullable = false)                                                                                                          Date         dateOfBirth;
    protected @Column(name = "date_last_login")                                                                                                                          Timestamp    dateLastLogin;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                     KvInfoEntity toKeyValueInfo;

    protected _UsersEntity() { }

    protected _UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof UsersEntity) && _equals((UsersEntity)o)));
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateLastLogin() {
        return this.dateLastLogin;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public String getNamePrefix() {
        return this.namePrefix;
    }

    public String getNameSuffix() {
        return this.nameSuffix;
    }

    public String getPassword() {
        return this.password;
    }

    public State getState() {
        return this.state;
    }

    public List<BudgetEntity> getToBudgets() {
        return HibernateUtil.find(BudgetEntity.class, PGArrays.wrap("toUser"), PGArrays.wrap(this));
    }

    public List<CategoryEntity> getToCategories() {
        return HibernateUtil.find(CategoryEntity.class, PGArrays.wrap("toUser"), PGArrays.wrap(this));
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public List<LoginHistoryEntity> getToLoginHistories() {
        return HibernateUtil.find(LoginHistoryEntity.class, PGArrays.wrap("toUser"), PGArrays.wrap(this));
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getUsername() {
        return this.username;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, kvId, state, username, password, emailAddress, namePrefix, firstName, middleName, lastName, nameSuffix, dateOfBirth, dateLastLogin, dateCreated, dateUpdated);
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateLastLogin(@Nullable Timestamp dateLastLogin) {
        if(Objects.equals(this.dateLastLogin, dateLastLogin)) return;
        this.dateLastLogin = dateLastLogin;
        setAsDirty();
    }

    public void setDateOfBirth(@NotNull Date dateOfBirth) {
        if(Objects.equals(this.dateOfBirth, dateOfBirth)) return;
        this.dateOfBirth = dateOfBirth;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setEmailAddress(@NotNull String emailAddress) {
        if(Objects.equals(this.emailAddress, emailAddress)) return;
        this.emailAddress = emailAddress;
        setAsDirty();
    }

    public void setFirstName(@NotNull String firstName) {
        if(Objects.equals(this.firstName, firstName)) return;
        this.firstName = firstName;
        setAsDirty();
    }

    public void setLastName(@NotNull String lastName) {
        if(Objects.equals(this.lastName, lastName)) return;
        this.lastName = lastName;
        setAsDirty();
    }

    public void setMiddleName(@Nullable String middleName) {
        if(Objects.equals(this.middleName, middleName)) return;
        this.middleName = middleName;
        setAsDirty();
    }

    public void setNamePrefix(@Nullable String namePrefix) {
        if(Objects.equals(this.namePrefix, namePrefix)) return;
        this.namePrefix = namePrefix;
        setAsDirty();
    }

    public void setNameSuffix(@Nullable String nameSuffix) {
        if(Objects.equals(this.nameSuffix, nameSuffix)) return;
        this.nameSuffix = nameSuffix;
        setAsDirty();
    }

    public void setPassword(@NotNull String password) {
        if(Objects.equals(this.password, password)) return;
        this.password = password;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setUsername(@NotNull String username) {
        if(Objects.equals(this.username, username)) return;
        this.username = username;
        setAsDirty();
    }

    private boolean _equals(@NotNull UsersEntity other) {/*@f0*/
        return (Objects.equals(userId, other.userId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(username, other.username)
                && Objects.equals(password, other.password)
                && Objects.equals(emailAddress, other.emailAddress)
                && Objects.equals(namePrefix, other.namePrefix)
                && Objects.equals(firstName, other.firstName)
                && Objects.equals(middleName, other.middleName)
                && Objects.equals(lastName, other.lastName)
                && Objects.equals(nameSuffix, other.nameSuffix)
                && Objects.equals(dateOfBirth, other.dateOfBirth)
                && Objects.equals(dateLastLogin, other.dateLastLogin)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
