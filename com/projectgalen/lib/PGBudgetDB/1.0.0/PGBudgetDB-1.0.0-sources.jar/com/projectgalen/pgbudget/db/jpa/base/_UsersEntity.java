package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 22, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.dao.UsersEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@MappedSuperclass
public class _UsersEntity extends JpaBase {
    protected @Column(name = "user_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long                           userId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, scale = 0, insertable = false, updatable = false)                                                           Long                           kvId;
    protected @Column(name = "state", nullable = false, precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State                          state;
    protected @Column(name = "username", nullable = false, unique = true, length = 255)                                                                                             String                         username;
    protected @Column(name = "password", nullable = false, length = 255)                                                                                                            String                         password;
    protected @Column(name = "email_address", nullable = false, unique = true, length = 255)                                                                                        String                         emailAddress;
    protected @Column(name = "name_prefix", length = 255)                                                                                                                           String                         namePrefix;
    protected @Column(name = "first_name", nullable = false, length = 255)                                                                                                          String                         firstName;
    protected @Column(name = "middle_name", length = 255)                                                                                                                           String                         middleName;
    protected @Column(name = "last_name", nullable = false, length = 255)                                                                                                           String                         lastName;
    protected @Column(name = "name_suffix", length = 255)                                                                                                                           String                         nameSuffix;
    protected @Column(name = "date_of_birth", nullable = false)                                                                                                                     Date                           dateOfBirth;
    protected @Column(name = "date_last_login")                                                                                                                                     Timestamp                      dateLastLogin;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                                  Timestamp                      dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                                  Timestamp                      dateUpdated;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                                KvInfoEntity                   toKeyValueInfo;
    protected @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                                               Collection<BudgetEntity>       toBudgets;
    protected @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                                               Collection<CategoryEntity>     toCategories;
    protected @OneToMany(mappedBy = "toUser", fetch = FetchType.LAZY)                                                                                                               Collection<LoginHistoryEntity> toLoginHistories;

    public _UsersEntity() { }

    public _UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public void addToBudgets(@NotNull BudgetEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToBudgets(object);
        object.setToUser((UsersEntity)this);
        if(!this.toBudgets.contains(object)) this.toBudgets.add(object);
        setAsDirty();
    }

    public void addToCategories(@NotNull CategoryEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToCategories(object);
        object.setToUser((UsersEntity)this);
        if(!this.toCategories.contains(object)) this.toCategories.add(object);
        setAsDirty();
    }

    public void addToLoginHistories(@NotNull LoginHistoryEntity object) {
        if(Objects.equals(object.getToUser(), this)) return;
        if(object.getToUser() != null) object.getToUser().removeFromToLoginHistories(object);
        object.setToUser((UsersEntity)this);
        if(!this.toLoginHistories.contains(object)) this.toLoginHistories.add(object);
        setAsDirty();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof UsersEntity) && _equals((UsersEntity)o)));
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Timestamp getDateLastLogin() {
        return this.dateLastLogin;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getNameSuffix() {
        return this.nameSuffix;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public String getNamePrefix() {
        return this.namePrefix;
    }

    public String getPassword() {
        return this.password;
    }

    public State getState() {
        return this.state;
    }

    public Collection<BudgetEntity> getToBudgets() {
        return Collections.unmodifiableCollection(this.toBudgets);
    }

    public Collection<CategoryEntity> getToCategories() {
        return Collections.unmodifiableCollection(this.toCategories);
    }

    public Collection<LoginHistoryEntity> getToLoginHistories() {
        return Collections.unmodifiableCollection(this.toLoginHistories);
    }

    public KvInfoEntity getToKeyValueInfo() {
        return this.toKeyValueInfo;
    }

    public Long getUserId() {
        return this.userId;
    }

    public String getUsername() {
        return this.username;
    }

    public void setEmailAddress(@NotNull String emailAddress) {
        if(Objects.equals(this.emailAddress, emailAddress)) return;
        this.emailAddress = emailAddress;
        setAsDirty();
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, kvId, state, username, password, emailAddress, namePrefix, firstName, middleName, lastName, nameSuffix, dateOfBirth, dateLastLogin, dateCreated, dateUpdated);
    }

    public void setFirstName(@NotNull String firstName) {
        if(Objects.equals(this.firstName, firstName)) return;
        this.firstName = firstName;
        setAsDirty();
    }

    public void setMiddleName(@Nullable String middleName) {
        if(Objects.equals(this.middleName, middleName)) return;
        this.middleName = middleName;
        setAsDirty();
    }

    public void removeFromToBudgets(@NotNull BudgetEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toBudgets.remove(object);
        setAsDirty();
    }

    public void setNameSuffix(@Nullable String nameSuffix) {
        if(Objects.equals(this.nameSuffix, nameSuffix)) return;
        this.nameSuffix = nameSuffix;
        setAsDirty();
    }

    public void removeFromToCategories(@NotNull CategoryEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toCategories.remove(object);
        setAsDirty();
    }

    public void removeFromToLoginHistories(@NotNull LoginHistoryEntity object) {
        if(!Objects.equals(object.getToUser(), this)) return;
        object.setToUser(null);
        this.toLoginHistories.remove(object);
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateLastLogin(@Nullable Timestamp dateLastLogin) {
        if(Objects.equals(this.dateLastLogin, dateLastLogin)) return;
        this.dateLastLogin = dateLastLogin;
        setAsDirty();
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        if(Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) return;
        this.toKeyValueInfo = toKeyValueInfo;
        setAsDirty();
    }

    public void setDateOfBirth(@NotNull Date dateOfBirth) {
        if(Objects.equals(this.dateOfBirth, dateOfBirth)) return;
        this.dateOfBirth = dateOfBirth;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setLastName(@NotNull String lastName) {
        if(Objects.equals(this.lastName, lastName)) return;
        this.lastName = lastName;
        setAsDirty();
    }

    public void setNamePrefix(@Nullable String namePrefix) {
        if(Objects.equals(this.namePrefix, namePrefix)) return;
        this.namePrefix = namePrefix;
        setAsDirty();
    }

    public void setPassword(@NotNull String password) {
        if(Objects.equals(this.password, password)) return;
        this.password = password;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setUsername(@NotNull String username) {
        if(Objects.equals(this.username, username)) return;
        this.username = username;
        setAsDirty();
    }

    @Contract(pure = true)
    public static @NotNull UsersEntityDao getDao() {
        return UsersEntityDao.shared();
    }

    private boolean _equals(@NotNull UsersEntity other) {/*@f0*/
        return (Objects.equals(userId, other.userId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(username, other.username)
                && Objects.equals(password, other.password)
                && Objects.equals(emailAddress, other.emailAddress)
                && Objects.equals(namePrefix, other.namePrefix)
                && Objects.equals(firstName, other.firstName)
                && Objects.equals(middleName, other.middleName)
                && Objects.equals(lastName, other.lastName)
                && Objects.equals(nameSuffix, other.nameSuffix)
                && Objects.equals(dateOfBirth, other.dateOfBirth)
                && Objects.equals(dateLastLogin, other.dateLastLogin)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
