package com.projectgalen.pgbudget.db.jpa.base;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: UsersEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: May 25, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.lib.utils.concurrency.Locks;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.*;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

import static com.projectgalen.lib.utils.PGArrays.wrap;

@MappedSuperclass
@SuppressWarnings("unused")
public class _UsersEntity extends JpaBase {

    protected @Column(name = "user_id", nullable = false, precision = 19, insertable = false, updatable = false) @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long         userId;
    protected @Column(name = "kv_id", nullable = false, precision = 19, insertable = false, updatable = false)                                                           Long         kvId;
    protected @Column(name = "state", nullable = false, precision = 10) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE")                       State        state;
    protected @Column(name = "username", nullable = false, unique = true)                                                                                                String       username;
    protected @Column(name = "password", nullable = false)                                                                                                               String       password;
    protected @Column(name = "email_address", nullable = false, unique = true)                                                                                           String       emailAddress;
    protected @Column(name = "name_prefix")                                                                                                                              String       namePrefix;
    protected @Column(name = "first_name", nullable = false)                                                                                                             String       firstName;
    protected @Column(name = "middle_name")                                                                                                                              String       middleName;
    protected @Column(name = "last_name", nullable = false)                                                                                                              String       lastName;
    protected @Column(name = "name_suffix")                                                                                                                              String       nameSuffix;
    protected @Column(name = "date_of_birth", nullable = false)                                                                                                          Date         dateOfBirth;
    protected @Column(name = "date_last_login")                                                                                                                          Timestamp    dateLastLogin;
    protected @Column(name = "date_created", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateCreated;
    protected @Column(name = "date_updated", nullable = false) @PGCurrentTimestamp                                                                                       Timestamp    dateUpdated;
    protected @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                                                     KvInfoEntity toKeyValueInfo;

    protected _UsersEntity() { }

    protected _UsersEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
        this.state = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    @Override
    public boolean equals(@Nullable Object o) {
        return Locks.getWithLock(lock, () -> ((this == o) || ((o instanceof UsersEntity) && _equals((UsersEntity)o))));
    }

    public Timestamp getDateCreated() {
        return Locks.getWithLock(lock, () -> this.dateCreated);
    }

    public Timestamp getDateLastLogin() {
        return Locks.getWithLock(lock, () -> this.dateLastLogin);
    }

    public Date getDateOfBirth() {
        return Locks.getWithLock(lock, () -> this.dateOfBirth);
    }

    public Timestamp getDateUpdated() {
        return Locks.getWithLock(lock, () -> this.dateUpdated);
    }

    public String getEmailAddress() {
        return Locks.getWithLock(lock, () -> this.emailAddress);
    }

    public String getFirstName() {
        return Locks.getWithLock(lock, () -> this.firstName);
    }

    public Long getKvId() {
        return Locks.getWithLock(lock, () -> this.kvId);
    }

    public String getLastName() {
        return Locks.getWithLock(lock, () -> this.lastName);
    }

    public String getMiddleName() {
        return Locks.getWithLock(lock, () -> this.middleName);
    }

    public String getNamePrefix() {
        return Locks.getWithLock(lock, () -> this.namePrefix);
    }

    public String getNameSuffix() {
        return Locks.getWithLock(lock, () -> this.nameSuffix);
    }

    public String getPassword() {
        return Locks.getWithLock(lock, () -> this.password);
    }

    public State getState() {
        return Locks.getWithLock(lock, () -> this.state);
    }

    public List<BudgetEntity> getToBudgets() {
        return HibernateUtil.find(BudgetEntity.class, wrap("toUser"), wrap(this));
    }

    public List<CategoryEntity> getToCategories() {
        return HibernateUtil.find(CategoryEntity.class, wrap("toUser"), wrap(this));
    }

    public KvInfoEntity getToKeyValueInfo() {
        return Locks.getWithLock(lock, () -> this.toKeyValueInfo);
    }

    public List<LoginHistoryEntity> getToLoginHistories() {
        return HibernateUtil.find(LoginHistoryEntity.class, wrap("toUser"), wrap(this));
    }

    public Long getUserId() {
        return Locks.getWithLock(lock, () -> this.userId);
    }

    public String getUsername() {
        return Locks.getWithLock(lock, () -> this.username);
    }

    @Override
    public int hashCode() {
        return Locks.getWithLock(lock, () -> Objects.hash(userId, kvId, state, username, password, emailAddress, namePrefix, firstName, middleName, lastName, nameSuffix, dateOfBirth, dateLastLogin, dateCreated, dateUpdated));
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateCreated, dateCreated)) {
                this.dateCreated = dateCreated;
                addValueToChangeMap("dateCreated", this.dateCreated);
                setAsDirty();
            }
        });
    }

    public void setDateLastLogin(@Nullable Timestamp dateLastLogin) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateLastLogin, dateLastLogin)) {
                this.dateLastLogin = dateLastLogin;
                addValueToChangeMap("dateLastLogin", this.dateLastLogin);
                setAsDirty();
            }
        });
    }

    public void setDateOfBirth(@NotNull Date dateOfBirth) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateOfBirth, dateOfBirth)) {
                this.dateOfBirth = dateOfBirth;
                addValueToChangeMap("dateOfBirth", this.dateOfBirth);
                setAsDirty();
            }
        });
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.dateUpdated, dateUpdated)) {
                this.dateUpdated = dateUpdated;
                addValueToChangeMap("dateUpdated", this.dateUpdated);
                setAsDirty();
            }
        });
    }

    public void setEmailAddress(@NotNull String emailAddress) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.emailAddress, emailAddress)) {
                this.emailAddress = emailAddress;
                addValueToChangeMap("emailAddress", this.emailAddress);
                setAsDirty();
            }
        });
    }

    public void setFirstName(@NotNull String firstName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.firstName, firstName)) {
                this.firstName = firstName;
                addValueToChangeMap("firstName", this.firstName);
                setAsDirty();
            }
        });
    }

    public void setLastName(@NotNull String lastName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.lastName, lastName)) {
                this.lastName = lastName;
                addValueToChangeMap("lastName", this.lastName);
                setAsDirty();
            }
        });
    }

    public void setMiddleName(@Nullable String middleName) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.middleName, middleName)) {
                this.middleName = middleName;
                addValueToChangeMap("middleName", this.middleName);
                setAsDirty();
            }
        });
    }

    public void setNamePrefix(@Nullable String namePrefix) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.namePrefix, namePrefix)) {
                this.namePrefix = namePrefix;
                addValueToChangeMap("namePrefix", this.namePrefix);
                setAsDirty();
            }
        });
    }

    public void setNameSuffix(@Nullable String nameSuffix) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.nameSuffix, nameSuffix)) {
                this.nameSuffix = nameSuffix;
                addValueToChangeMap("nameSuffix", this.nameSuffix);
                setAsDirty();
            }
        });
    }

    public void setPassword(@NotNull String password) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.password, password)) {
                this.password = password;
                addValueToChangeMap("password", this.password);
                setAsDirty();
            }
        });
    }

    public void setState(@NotNull State state) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.state, state)) {
                this.state = state;
                addValueToChangeMap("state", this.state);
                setAsDirty();
            }
        });
    }

    public void setToKeyValueInfo(KvInfoEntity toKeyValueInfo) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.toKeyValueInfo, toKeyValueInfo)) {
                this.toKeyValueInfo = toKeyValueInfo;
                addValueToChangeMap("kvId", this.kvId);
                setAsDirty();
            }
        });
    }

    public void setUsername(@NotNull String username) {
        Locks.doWithLock(lock, () -> {
            if(!Objects.equals(this.username, username)) {
                this.username = username;
                addValueToChangeMap("username", this.username);
                setAsDirty();
            }
        });
    }

    private boolean _equals(@NotNull UsersEntity other) {/*@f0*/
        return (Objects.equals(userId, other.userId)
                && Objects.equals(kvId, other.kvId)
                && Objects.equals(state, other.state)
                && Objects.equals(username, other.username)
                && Objects.equals(password, other.password)
                && Objects.equals(emailAddress, other.emailAddress)
                && Objects.equals(namePrefix, other.namePrefix)
                && Objects.equals(firstName, other.firstName)
                && Objects.equals(middleName, other.middleName)
                && Objects.equals(lastName, other.lastName)
                && Objects.equals(nameSuffix, other.nameSuffix)
                && Objects.equals(dateOfBirth, other.dateOfBirth)
                && Objects.equals(dateLastLogin, other.dateLastLogin)
                && Objects.equals(dateCreated, other.dateCreated)
                && Objects.equals(dateUpdated, other.dateUpdated));
    }/*@f1*/
}
