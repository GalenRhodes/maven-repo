package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: DueFrequency.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.pgbudget.db.converters.JComboBoxItem;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Range;

import static com.projectgalen.pgbudget.db.C.msgs;

public enum DueFrequency implements JComboBoxItem {
    OTHER(0), MONTHLY(1), TWICE_MONTHLY(2), WEEKLY(3), BIWEEKLY(4), YEARLY(5), TWICE_YEARLY(6);

    @Range(from = 0, to = 6) private final int id;

    DueFrequency(@Range(from = 0, to = 6) int id) {
        this.id = id;
    }

    @Override
    public @NotNull String getComboBoxText() {
        return toString();
    }

    public @Range(from = 0, to = 6) int getId() {
        return id;
    }

    @Contract(pure = true)
    @Override
    public @NotNull String toString() {
        return msgs.getString(String.format("enum.due_frequency.name.%d", id), super.toString());
    }

    public static @NotNull DueFrequency getType(@Range(from = 0, to = 6) int id) {
        for(DueFrequency e : DueFrequency.values()) if(e.id == id) return e;
        throw new IllegalArgumentException(msgs.format("msg.err.invalid_enum_id", msgs.getString("msg.due_date_frequency"), id));
    }
}
