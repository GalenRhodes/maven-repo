package com.projectgalen.pgbudget.db.jpa.enums;

// ===========================================================================
//     PROJECT: PGBudgetDB
//    FILENAME: DueFrequency.java
//         IDE: IntelliJ IDEA
//      AUTHOR: Galen Rhodes
//        DATE: February 13, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public enum DueFrequency {
    MONTHLY(1), WEEKLY(2), BIWEEKLY(3), TWICE_MONTHLY(4), YEARLY(5), TWICE_YEARLY(6), OTHER(0);

    private final int id;

    DueFrequency(int id) {
        this.id = id;
    }

    public int getId() { return id; }

    @Contract(pure = true)
    @Override
    public @NotNull String toString() {
        switch(id) {/*@f0*/
            case 1:  return "Monthly";
            case 2:  return "Weekly";
            case 3:  return "Bi-Weekly";
            case 4:  return "2x Monthly";
            case 5:  return "Yearly";
            case 6:  return "2x Yearly";
            default: return "Other";
        }/*@f1*/
    }

    public static DueFrequency getType(int id) {
        switch(id) {/*@f0*/
            case 1: return MONTHLY;
            case 2: return WEEKLY;
            case 3: return BIWEEKLY;
            case 4: return TWICE_MONTHLY;
            case 5: return YEARLY;
            case 6: return TWICE_YEARLY;
            default: return OTHER;
        }/*@f1*/
    }
}
