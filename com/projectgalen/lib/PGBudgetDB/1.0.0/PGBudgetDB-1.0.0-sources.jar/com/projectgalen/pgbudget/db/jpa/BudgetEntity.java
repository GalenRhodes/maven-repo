package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGCalendar;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.enums.WeekDay;
import com.projectgalen.pgbudget.db.C;
import com.projectgalen.pgbudget.db.errors.PGBudgetDBException;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.events.JpaEventBase.EventType;
import com.projectgalen.pgbudget.db.events.users.UsersBudgetEvent;
import com.projectgalen.pgbudget.db.events.users.UsersBudgetListener;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodState;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.projectgalen.lib.utils.PGArrays.wrap;
import static com.projectgalen.lib.utils.PGCollections.getFirst;
import static com.projectgalen.pgbudget.db.C.msgs;

@SuppressWarnings("unused")
@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    private @Transient State oldState = null;

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    public @NotNull List<PeriodEntity> createNextPeriods(@NotNull Date until, @NotNull BigDecimal rollOverAmount) {
        PeriodEntity lastPeriod = getLastPeriod();
        Date         startDate  = lastPeriod == null ? getVeryFirstPeriodDate() : getNextPeriodDateFollowing(lastPeriod);
        Date         endDate    = Dates.toSQLDate(until); // Sets the time fields to zero.

        // Null means we're already past the ending date.
        return ((startDate == null) ? Collections.emptyList() : createPeriods(startDate, endDate, rollOverAmount));
    }

    public @NotNull List<PeriodEntity> createNextPeriods(int count, @NotNull BigDecimal rollOverAmount) {
        return Collections.emptyList();
    }

    public @NotNull List<PeriodEntity> createPeriods(@NotNull Date startDate, @NotNull Date endDate, @NotNull BigDecimal rollOverAmount) {
        List<IncomeSourceEntity>     incomeSources     = getIncomeSources();
        List<RecurringPaymentEntity> recurringPayments = getRecurringPayments();
        List<PeriodEntity>           list              = new ArrayList<>();
        Date                         now               = Dates.toSQLDate(new Date()); // Sets the time fields to zero.
        Date                         periodDate        = startDate;

        while(periodDate.compareTo(endDate) <= 0) {
            Date                     nextPeriodDate  = getNextPeriodDate(periodDate);
            PeriodEntity             period          = PeriodEntity.createPeriodEntity();
            List<PeriodIncomeEntity> periodIncomes   = calculatePeriodIncome(period, periodDate, incomeSources);
            List<PeriodItemEntity>   periodItems     = calculatePeriodDebits(period, periodDate, nextPeriodDate, recurringPayments);
            BigDecimal               totalIncome     = BigDecimal.valueOf(periodIncomes.stream().mapToDouble(i -> i.getAmount().doubleValue()).sum());
            BigDecimal               totalDebits     = BigDecimal.valueOf(periodItems.stream().mapToDouble(i -> i.getAmount().doubleValue()).sum());
            BigDecimal               remainingAmount = totalIncome.add(rollOverAmount).subtract(totalDebits);

            period.setPeriodDate(Dates.toSQLDate(periodDate));
            period.setPeriodState((now.compareTo(periodDate) < 0) ? PeriodState.FUTURE : ((now.compareTo(nextPeriodDate) < 0) ? PeriodState.IN_PROGRESS : PeriodState.CLOSED));
            period.setRollOverAmount(rollOverAmount);
            period.setTotalIncome(totalIncome);
            period.setTotalDebit(totalDebits);
            period.setRemainingAmount(remainingAmount);
            period.setToBudget(this);
            period.saveChanges();

            periodIncomes.forEach(PeriodIncomeEntity::saveChanges);
            periodItems.forEach(PeriodItemEntity::saveChanges);
            list.add(period);

            periodDate = nextPeriodDate;
            rollOverAmount = remainingAmount;
        }

        return list;
    }

    @NotNull
    @Transient
    public List<BankAccountsEntity> getAllDefaultBankAccounts() {
        return HibernateUtil.find(BankAccountsEntity.class, wrap("state", "toBudget", "isDefault"), wrap(State.ACTIVE, this, true), 0, 1);
    }

    @Transient
    public @NotNull List<BankAccountsEntity> getBankAccounts() {
        return find(BankAccountsEntity.class);
    }

    @Transient
    public @Nullable BankAccountsEntity getDefaultBankAccount() {
        BankAccountsEntity bank = getFirst(getAllDefaultBankAccounts());
        if(bank == null) bank = getFirst(getBankAccounts());
        return bank;
    }

    public @Nullable BankAccountsEntity getDefaultBankAccountActiveOn(@NotNull Date date) {
        List<BankAccountsEntity> bankAccounts = getAllDefaultBankAccounts().stream().filter(b -> b.isInRange(date)).collect(Collectors.toList());
        if(bankAccounts.isEmpty()) return null;
        for(BankAccountsEntity bank : bankAccounts) if(bank.getIsDefault()) return bank;
        return bankAccounts.get(0);
    }

    @Transient
    public @NotNull List<IncomeSourceEntity> getIncomeSources() {
        return find(IncomeSourceEntity.class, "isDefault", "amount desc", "sourceName");
    }

    @Transient
    public @Nullable PeriodEntity getLastPeriod() {
        return getFirst(HibernateUtil.find(PeriodEntity.class, wrap("state", "toBudget"), wrap(State.ACTIVE, this), wrap("periodDate desc"), 0, 1));
    }

    public @NotNull Date getNextPeriodDate(@NotNull Date lastDate) {
        PGCalendar _lastDate = PGCalendar.getInstance(lastDate);
        switch(getPeriodType()) {/*@f0*/
            case BIWEEKLY:      return _lastDate.addDays(14).getTime();
            case WEEKLY:        return _lastDate.addDays(7).getTime();
            case TWICE_MONTHLY: if(_lastDate.getDate() == getPeriodDate1()) return _lastDate.setDate(getPeriodDate2()).getTime();
            case MONTHLY:       return _lastDate.addMonths(1).setDate(getPeriodDate1()).getTime();
            default:            return getNextOtherPeriodDate(_lastDate);
        }/*@f1*/
    }

    @Transient
    public @NotNull List<OtherPeriodDatesEntity> getOtherPeriodDates() {
        return find(OtherPeriodDatesEntity.class, "otherDate");
    }

    public @NotNull List<PGCalendar> getOtherPeriodDates(int year) {
        return find(OtherPeriodDatesEntity.class, "otherDate").stream().map(o -> PGCalendar.getInstance(o.getOtherDate()).setYear(year)).sorted(Calendar::compareTo).collect(Collectors.toList());
    }

    @Transient
    public @NotNull List<PeriodEntity> getPeriods() {
        return find(PeriodEntity.class, "periodDate");
    }

    @Transient
    public @NotNull List<RecurringPaymentEntity> getRecurringPayments() {
        return find(RecurringPaymentEntity.class, "amount desc", "payeeName");
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        _saveChanges(deep, ((oldState == null) ? EventType.Changed : EventType.Removed));
        oldState = null;
    }

    @Override
    public void setState(@NotNull State state) {
        if(state != getState()) {
            if(oldState == null) oldState = getState();
            else if(state == oldState) oldState = null;
            super.setState(state);
        }
    }

    protected @Nullable Date checkBudgetEndDate(@NotNull Date firstDate) {
        Date endDate = getEndingDate();
        return (((endDate == null) || (firstDate.compareTo(endDate) <= 0)) ? firstDate : null);
    }

    protected <T extends JpaBase> @NotNull List<T> find(Class<T> cls, String... sortFields) {
        return HibernateUtil.find(cls, wrap("state", "toBudget"), wrap(State.ACTIVE, this), sortFields);
    }

    protected @NotNull PGCalendar getNextOtherDate(@NotNull PGCalendar startDate) {
        List<PGCalendar> others = getOtherPeriodDates(startDate.getYear());
        for(PGCalendar d : others) if(d.compareTo(startDate) >= 0) return d;
        return others.get(0).addYears(1);
    }

    @NotNull
    protected Date getNextOtherPeriodDate(@NotNull PGCalendar lastDate) {
        List<PGCalendar> others = getOtherPeriodDates(lastDate.getYear());
        if(others.isEmpty()) throw new PGBudgetDBException(C.msgs.getString("msg.err.no_other_dates"));
        for(PGCalendar o : others) if(o.compareTo(lastDate) > 0) return o.getTime();
        return others.get(0).addYears(1).getTime();
    }

    protected @Nullable Date getNextPeriodDateFollowing(@NotNull PeriodEntity lastPeriod) {
        return checkBudgetEndDate(getNextPeriodDate(lastPeriod.getPeriodDate()));
    }

    @Transient
    protected @Nullable Date getVeryFirstPeriodDate() {
        PGCalendar startDate = Dates.max(PGCalendar.getInstance(Dates.toSQLDate(new Date())), PGCalendar.getInstance(getStartingDate()));

        switch(getPeriodType()) {
            case WEEKLY: {
                int weekday = getPeriodDate1();
                while(startDate.getDayOfWeek() != weekday) startDate.addDays(1);
                break;
            }
            case BIWEEKLY: {
                PGCalendar sd = PGCalendar.getInstance(getStartingDate());
                while(sd.before(startDate)) sd.addDays(14);
                startDate = sd;
                break;
            }
            case MONTHLY: {
                int dayOfMonth = getPeriodDate1();
                if(dayOfMonth < startDate.getDate()) startDate.addMonths(1);
                startDate.setDate(dayOfMonth);
                break;
            }
            case TWICE_MONTHLY: {
                int d1 = Math.min(getPeriodDate1(), getPeriodDate2());
                int d2 = Math.max(getPeriodDate1(), getPeriodDate2());
                int dt = startDate.getDate();

                if(dt > d2) {
                    startDate.addMonths(1);
                    startDate.setDate(d1);
                    break;
                }
                startDate.setDate((dt > d1) ? d2 : d1);
                break;
            }
            case OTHER: {
                startDate = getNextOtherDate(startDate);
                break;
            }
            default: {
                return null;
            }
        }

        return checkBudgetEndDate(Dates.toSQLDate(startDate.getTime()));
    }

    private void _saveChanges(boolean deep, EventType eventType) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
        getToUser().fireUsersEvent(UsersBudgetListener.class, new UsersBudgetEvent(getToUser(), eventType, this));
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user,
                                                        @NotNull String name,
                                                        @NotNull PeriodType periodType,
                                                        @NotNull Date startDate,
                                                        int periodDate,
                                                        WeekDay periodWeekDay,
                                                        int twiceMonthlyDate1,
                                                        int twiceMonthlyDate2,
                                                        List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = new BudgetEntity(false);

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);
        budget.setToKeyValueInfo(KvInfoEntity.getNewEntity());

        switch(periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                budget.setPeriodDate2(null);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay.getId());
                budget.setPeriodDate2(null);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(Math.min(twiceMonthlyDate1, twiceMonthlyDate2));
                budget.setPeriodDate2(Math.max(twiceMonthlyDate1, twiceMonthlyDate2));
                break;
            case BIWEEKLY:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);
                break;
            case OTHER:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);

                for(Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = OtherPeriodDatesEntity.getNewEntity();
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }

                break;
            default:
                break;
        }

        budget._saveChanges(true, EventType.Added);

        for(OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }

        return budget;
    }

    public static @NotNull ValidationResponse validateBudgetData(String budgetName, PeriodType periodType, Date startDate, WeekDay weekDay, int date, int date1, int date2, List<Date> otherDates) {
        if(U.z(U.tr(budgetName))) return new ValidationResponse(msgs.getString("validate.budget.budget_name_required"));
        if(periodType == null) return new ValidationResponse(msgs.getString("validate.budget.period.period_type_required"));
        if(startDate == null) return new ValidationResponse(msgs.getString("validate.budget.start_date_required"));
        return validatePeriodTypeData(periodType, weekDay, date, date1, date2, otherDates);
    }

    public static @NotNull ValidationResponse validatePeriodTypeData(@NotNull PeriodType periodType, @Nullable WeekDay weekDay, int date, int date1, int date2, @NotNull List<Date> otherDates) {
        switch(periodType) {/*@f0*/
            case MONTHLY:       return new ValidationResponse(!(date <= 0), msgs.getString("validate.budget.period.pay_date_required"));
            case WEEKLY:        return new ValidationResponse(!(weekDay == null), msgs.getString("validate.budget.period.weekday_required"));
            case BIWEEKLY:      return new ValidationResponse();
            case TWICE_MONTHLY: return new ValidationResponse(!((date1 <= 0) || (date2 <= 0)), msgs.getString("validate.budget.period.2x_dates_required"));
            case OTHER:         return new ValidationResponse(!(otherDates.size() == 0), msgs.getString("validate.budget.period.other_period_date_required"));
            default:            return new ValidationResponse(msgs.getString("validate.budget.period.bad_period_type"));
        }/*@f1*/
    }

    protected static @NotNull List<PeriodItemEntity> calculatePeriodDebits(@NotNull PeriodEntity period,
                                                                           @NotNull Date thisPeriodDate,
                                                                           @NotNull Date nextPeriodDate,
                                                                           @NotNull List<RecurringPaymentEntity> recurringPayments) {
        List<PeriodItemEntity> list = new ArrayList<>();
        for(RecurringPaymentEntity r : recurringPayments) {
            if(Dates.isInOpenRange(thisPeriodDate, r.getStartDate(), r.getEndDate())) {
                int cc = r.isInRange(thisPeriodDate, nextPeriodDate);
                if(cc > 0) {
                    PeriodItemEntity item = PeriodItemEntity.createNewPeriodItem(cc, thisPeriodDate, nextPeriodDate, r);
                    item.setToPeriod(period);
                    list.add(item);
                }
            }
        }
        return list;
    }

    protected static @NotNull List<PeriodIncomeEntity> calculatePeriodIncome(@NotNull PeriodEntity period, @NotNull Date thisPeriodDate, @NotNull List<IncomeSourceEntity> incomeSources) {
        List<PeriodIncomeEntity> list = new ArrayList<>();
        for(IncomeSourceEntity i : incomeSources) {
            if(Dates.isInOpenRange(thisPeriodDate, i.getStartDate(), i.getEndDate())) {
                PeriodIncomeEntity pi = PeriodIncomeEntity.createNewPeriodIncome(i);
                pi.setToPeriod(period);
                list.add(pi);
            }
        }
        return list;
    }
}
