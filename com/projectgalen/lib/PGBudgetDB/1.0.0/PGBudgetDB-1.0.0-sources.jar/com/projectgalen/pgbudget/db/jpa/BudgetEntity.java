package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGCalendar;
import com.projectgalen.lib.utils.PGCollections;
import com.projectgalen.lib.utils.U;
import com.projectgalen.lib.utils.enums.WeekDay;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.ItemState;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodState;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.projectgalen.lib.utils.PGArrays.wrap;
import static com.projectgalen.pgbudget.db.C.msgs;

@SuppressWarnings("unused")
@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    public @NotNull List<PeriodEntity> createNextPeriods(@NotNull Date until, @NotNull BigDecimal rollOverAmount) {
        PeriodEntity       lastPeriod = getLastPeriod();
        List<PeriodEntity> list       = new ArrayList<>();

        if(lastPeriod == null) {
            Date periodDate = getVeryFirstPeriodDate();
            // Null means we're already past the ending date.
            if(periodDate == null) return Collections.emptyList();

            List<IncomeSourceEntity>     incomeSources     = getIncomeSources();
            List<RecurringPaymentEntity> recurringPayments = getRecurringPayments();
            Date                         now               = new Date();

            while(periodDate.compareTo(until) <= 0) {
                Date         nextPeriodDate  = getNextPeriodDate(periodDate);
                PeriodEntity period          = new PeriodEntity(false);
                BigDecimal   totalIncome     = calculatePeriodIncome(period, periodDate, incomeSources);
                BigDecimal   totalDebits     = calculatePeriodDebits(period, periodDate, nextPeriodDate, recurringPayments);
                BigDecimal   remainingAmount = totalIncome.add(rollOverAmount).subtract(totalDebits);

                period.setPeriodDate(Dates.toSQLDate(periodDate));
                period.setPeriodState((periodDate.compareTo(now) >= 0) ? PeriodState.IN_PROGRESS : PeriodState.CLOSED);
                period.setRollOverAmount(rollOverAmount);
                period.setTotalIncome(totalIncome);
                period.setTotalDebit(totalDebits);
                period.setRemainingAmount(remainingAmount);
                period.setToKeyValueInfo(KvInfoEntity.getNewEntity());
                period.setToBudget(this);
                period.saveChanges();
                list.add(period);

                periodDate = nextPeriodDate;
                rollOverAmount = remainingAmount;
            }
        }

        return list;
    }

    public @NotNull List<PeriodEntity> createNextPeriods(int count, @NotNull BigDecimal rollOverAmount) {
        return Collections.emptyList();
    }

    public @NotNull List<PeriodEntity> createPeriods(@NotNull Date startDate, @NotNull Date endDate, @NotNull BigDecimal rollOverAmount) {
        return Collections.emptyList();
    }

    @Transient
    public @NotNull List<BankAccountsEntity> getBankAccounts() {
        return find(BankAccountsEntity.class);
    }

    public @Nullable BankAccountsEntity getDefaultBankAccountActiveOn(@NotNull Date date) {
        List<BankAccountsEntity> bankAccounts = getBankAccounts().stream().filter(b -> b.isInRange(date)).collect(Collectors.toList());
        if(bankAccounts.isEmpty()) return null;
        for(BankAccountsEntity bank : bankAccounts) if(bank.getIsDefault()) return bank;
        return bankAccounts.get(0);
    }

    @Transient
    public @NotNull List<IncomeSourceEntity> getIncomeSources() {
        return find(IncomeSourceEntity.class, "isDefault", "amount desc", "sourceName");
    }

    @Transient
    public @Nullable PeriodEntity getLastPeriod() {
        return PGCollections.getFirst(HibernateUtil.find(PeriodEntity.class, wrap("state", "toBudget"), wrap(State.ACTIVE, this), wrap("periodDate desc"), 0, 1));
    }

    public @NotNull Date getNextPeriodDate(@NotNull Date lastDate) {
        PGCalendar _lastDate = PGCalendar.getInstance(lastDate);
        switch(getPeriodType()) {/*@f0*/
            case BIWEEKLY:      return _lastDate.addDays(14).getTime();
            case WEEKLY:        return _lastDate.addDays(7).getTime();
            case TWICE_MONTHLY: if(_lastDate.getDate() == getPeriodDate1()) return _lastDate.setDate(getPeriodDate2()).getTime();
            case MONTHLY:       return _lastDate.addMonths(1).setDate(getPeriodDate1()).getTime();
            default: {
                List<PGCalendar> others = getOtherPeriodDates(_lastDate.getYear());
                for(PGCalendar o : others) if(o.compareTo(_lastDate) > 0) return o.getTime();
                return others.get(0).addYears(1).getTime();
            }
        }/*@f1*/
    }

    @Transient
    public @NotNull List<OtherPeriodDatesEntity> getOtherPeriodDates() {
        return find(OtherPeriodDatesEntity.class, "otherDate");
    }

    public @NotNull List<PGCalendar> getOtherPeriodDates(int year) {
        return find(OtherPeriodDatesEntity.class, "otherDate").stream().map(o -> PGCalendar.getInstance(o.getOtherDate()).setYear(year)).sorted(Calendar::compareTo).collect(Collectors.toList());
    }

    @Transient
    public @NotNull List<PeriodEntity> getPeriods() {
        return find(PeriodEntity.class, "periodDate");
    }

    @Transient
    public @NotNull List<RecurringPaymentEntity> getRecurringPayments() {
        return find(RecurringPaymentEntity.class, "amount desc", "payeeName");
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Override
    public void saveChanges(boolean deep) {
        setDateUpdated(Dates.getTimestamp());
        super.saveChanges(deep);
    }

    @Override
    public void saveChanges() {
        saveChanges(true);
    }

    protected <T extends JpaBase> @NotNull List<T> find(Class<T> cls, String... sortFields) {
        return HibernateUtil.find(cls, wrap("state", "toBudget"), wrap(State.ACTIVE, this), sortFields);
    }

    private @NotNull PGCalendar getNextOtherDate(PGCalendar startDate) {
        List<PGCalendar> others = getOtherPeriodDates(startDate.getYear());
        for(PGCalendar d : others) if(d.compareTo(startDate) >= 0) return d;
        return others.get(0).addYears(1);
    }

    @Transient
    private @Nullable Date getVeryFirstPeriodDate() {
        PGCalendar startDate = Dates.max(PGCalendar.getInstance(), PGCalendar.getInstance(getStartingDate()));

        switch(getPeriodType()) {
            case WEEKLY: {
                int weekday = getPeriodDate1();
                while(startDate.getDayOfWeek() != weekday) startDate.addDays(1);
                break;
            }
            case BIWEEKLY: {
                PGCalendar sd = PGCalendar.getInstance(getStartingDate());
                while(sd.before(startDate)) sd.addDays(14);
                startDate = sd;
                break;
            }
            case MONTHLY: {
                int dayOfMonth = getPeriodDate1();
                if(dayOfMonth < startDate.getDate()) startDate.addMonths(1);
                startDate.setDate(dayOfMonth);
                break;
            }
            case TWICE_MONTHLY: {
                int d1 = Math.min(getPeriodDate1(), getPeriodDate2());
                int d2 = Math.max(getPeriodDate1(), getPeriodDate2());
                int dt = startDate.getDate();

                if(dt > d2) {
                    startDate.addMonths(1);
                    startDate.setDate(d1);
                    break;
                }
                startDate.setDate((dt > d1) ? d2 : d1);
                break;
            }
            case OTHER: {
                startDate = getNextOtherDate(startDate);
                break;
            }
            default: {
                return null;
            }
        }

        Date firstDate = startDate.getTime();
        Date endDate   = getEndingDate();
        return (((endDate == null) || (firstDate.compareTo(endDate) < 0)) ? firstDate : null);
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user,
                                                        @NotNull String name,
                                                        @NotNull PeriodType periodType,
                                                        @NotNull Date startDate,
                                                        int periodDate,
                                                        WeekDay periodWeekDay,
                                                        int twiceMonthlyDate1,
                                                        int twiceMonthlyDate2,
                                                        List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = new BudgetEntity(false);

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);
        budget.setToKeyValueInfo(KvInfoEntity.getNewEntity());

        switch(periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                budget.setPeriodDate2(null);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay.getId());
                budget.setPeriodDate2(null);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(Math.min(twiceMonthlyDate1, twiceMonthlyDate2));
                budget.setPeriodDate2(Math.max(twiceMonthlyDate1, twiceMonthlyDate2));
                break;
            case BIWEEKLY:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);
                break;
            case OTHER:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);

                for(Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = OtherPeriodDatesEntity.getNewEntity();
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }

                break;
            default:
                break;
        }

        budget.saveChanges();

        for(OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }

        return budget;
    }

    public static @NotNull ValidationResponse validateBudgetData(String budgetName, PeriodType periodType, Date startDate, WeekDay weekDay, int date, int date1, int date2, List<Date> otherDates) {
        if(U.z(U.tr(budgetName))) return new ValidationResponse(msgs.getString("validate.budget.budget_name_required"));
        if(periodType == null) return new ValidationResponse(msgs.getString("validate.budget.period.period_type_required"));
        if(startDate == null) return new ValidationResponse(msgs.getString("validate.budget.start_date_required"));
        return validatePeriodTypeData(periodType, weekDay, date, date1, date2, otherDates);
    }

    public static @NotNull ValidationResponse validatePeriodTypeData(@NotNull PeriodType periodType, @Nullable WeekDay weekDay, int date, int date1, int date2, @NotNull List<Date> otherDates) {
        switch(periodType) {/*@f0*/
            case MONTHLY:       return new ValidationResponse(!(date <= 0), msgs.getString("validate.budget.period.pay_date_required"));
            case WEEKLY:        return new ValidationResponse(!(weekDay == null), msgs.getString("validate.budget.period.weekday_required"));
            case BIWEEKLY:      return new ValidationResponse();
            case TWICE_MONTHLY: return new ValidationResponse(!((date1 <= 0) || (date2 <= 0)), msgs.getString("validate.budget.period.2x_dates_required"));
            case OTHER:         return new ValidationResponse(!(otherDates.size() == 0), msgs.getString("validate.budget.period.other_period_date_required"));
            default:            return new ValidationResponse(msgs.getString("validate.budget.period.bad_period_type"));
        }/*@f1*/
    }

    private static @NotNull BigDecimal calculatePeriodDebits(@NotNull PeriodEntity period, @NotNull Date periodDate, @NotNull Date nextDate, @NotNull List<RecurringPaymentEntity> recurringPayments) {
        double debits = 0.0;
        for(RecurringPaymentEntity r : recurringPayments) {
            if(Dates.isInOpenRange(periodDate, r.getStartDate(), r.getEndDate())) {
                int cc = r.isInRange(periodDate, nextDate);
                if(cc > 0) {
                    double           amount = (r.getAmount().doubleValue() * cc);
                    String           payee  = r.getPayeeName();
                    PeriodItemEntity item   = new PeriodItemEntity(false);

                    item.setToPeriod(period);
                    item.setToRecurring(r);
                    item.setToCategory(r.getToCategory());
                    item.setToBank(r.getToBank());
                    item.setToKeyValueInfo(KvInfoEntity.getNewEntity());
                    item.setAmount(BigDecimal.valueOf(amount));
                    item.setPayeeName((cc > 1) ? String.format("%s (x%d)", payee, cc) : payee);
                    item.setItemState(ItemState.NONE);
                    item.saveChanges();
                    debits += amount;
                }
            }
        }
        return BigDecimal.valueOf(debits);
    }

    private static @NotNull BigDecimal calculatePeriodIncome(@NotNull PeriodEntity period, @NotNull Date periodDate, @NotNull List<IncomeSourceEntity> incomeSources) {
        double income = 0.0;
        for(IncomeSourceEntity i : incomeSources) {
            if(Dates.isInOpenRange(periodDate, i.getStartDate(), i.getEndDate())) {
                PeriodIncomeEntity pi = PeriodIncomeEntity.createNewPeriodIncome(i);
                pi.setToPeriod(period);
                pi.saveChanges();
                income += i.getAmount().doubleValue();
            }
        }
        return BigDecimal.valueOf(income);
    }

    private interface Foo {
        boolean isDone(int numberCreated, PGCalendar periodDate);
    }
}
