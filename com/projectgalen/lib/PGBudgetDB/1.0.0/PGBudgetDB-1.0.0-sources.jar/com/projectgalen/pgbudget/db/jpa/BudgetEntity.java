package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.Kalendar;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.errors.PGBudgetDBException;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.ItemState;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import com.projectgalen.pgbudget.db.jpa.enums.WeekDay;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.*;

import static com.projectgalen.lib.utils.PGArrays.wrap;
import static com.projectgalen.pgbudget.db.C.isDateInRange;
import static com.projectgalen.pgbudget.db.C.msgs;

@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Transient
    public @NotNull List<PeriodEntity> createNextPeriods(Date until, @NotNull BigDecimal carryOverAmount) {
        PeriodEntity last  = getLastActivePeriod();
        Kalendar     start = ((last == null) ? getInitialPeriodDate() : getNextPeriodDate(last));
        Kalendar     stop  = new Kalendar(until);
        if(start.compareTo(stop) >= 0) throw new PGBudgetDBException(msgs.getString("msg.err.invalid_until_date"));
        return createPeriods(start, stop, Integer.MAX_VALUE, ((last == null) ? carryOverAmount : last.getRemainingAmount()));
    }

    @Transient
    public @NotNull List<PeriodEntity> createNextPeriods(int count, @NotNull BigDecimal carryOverAmount) {
        if(count <= 0) return new ArrayList<>();
        PeriodEntity last  = getLastActivePeriod();
        Kalendar     start = ((last == null) ? getInitialPeriodDate() : getNextPeriodDate(last));
        Kalendar     stop  = start.clone();
        stop.addYears(100);
        return createPeriods(start, stop, count, ((last == null) ? carryOverAmount : last.getRemainingAmount()));
    }

    @Transient
    public @NotNull List<BankAccountsEntity> getActiveBankAccounts() {
        Date                     now  = new Date();
        List<BankAccountsEntity> list = find(BankAccountsEntity.class);
        List<BankAccountsEntity> out  = new ArrayList<>();
        list.forEach(b -> { if(isDateInRange(now, b.getStartDate(), b.getEndDate())) out.add(b); });
        return out;
    }

    @Transient
    public @NotNull List<IncomeSourceEntity> getActiveIncomeSources() {
        Date                     now  = new Date();
        List<IncomeSourceEntity> list = find(IncomeSourceEntity.class);
        List<IncomeSourceEntity> out  = new ArrayList<>();
        list.forEach(i -> { if(isDateInRange(now, i.getStartDate(), i.getEndDate())) out.add(i); });
        return out;
    }

    @Transient
    public @NotNull List<Date> getActiveOtherPeriodDates() {
        List<Date>                   out    = new ArrayList<>();
        List<OtherPeriodDatesEntity> others = find(OtherPeriodDatesEntity.class, "otherDate");
        others.forEach(od -> out.add(od.getOtherDate()));
        return out;
    }

    @Transient
    public List<PeriodEntity> getActivePeriods() {
        return find(PeriodEntity.class, "periodDate");
    }

    @Transient
    public @NotNull List<RecurringPaymentEntity> getActiveRecurringPayments() {
        Date                         now  = new Date();
        List<RecurringPaymentEntity> list = find(RecurringPaymentEntity.class);
        List<RecurringPaymentEntity> out  = new ArrayList<>();
        list.forEach(r -> { if(isDateInRange(now, r.getStartDate(), r.getEndDate())) out.add(r); });
        return out;
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    protected <T extends JpaBase> List<T> find(@NotNull Class<T> entityClass, String... sortBy) {
        return find(entityClass, Integer.MAX_VALUE, sortBy);
    }

    protected <T extends JpaBase> List<T> find(@NotNull Class<T> entityClass, int maxRecords, String... sortBy) {
        return HibernateUtil.find(entityClass, wrap("state", "toBudget"), wrap(State.ACTIVE, this), sortBy);
    }

    @Transient
    protected Kalendar getNextPeriodDate(@NotNull PeriodEntity previousPeriod) {
        Kalendar cal     = new Kalendar(previousPeriod.getPeriodDate());
        Kalendar nextCal = cal.clone();

        switch(getPeriodType()) {
            case OTHER: {
                List<Kalendar> otherDates = getActiveOtherPeriodCalendarDates();
                if(otherDates.size() == 0) throw new PGBudgetDBException(msgs.getString("msg.err.no_active_period_dates"));

                for(int i = 0, j = otherDates.size(); i < j; i++) {
                    Kalendar od = otherDates.get(i);
                    od.setYear(cal.getYear());

                    if(cal.after(od)) od.addYears(1);
                    else if(cal.equals(od)) return otherDates.get((i + 1) % j);
                    else if(cal.before(od)) return od;
                }
                return otherDates.get(0);
            }
            case TWICE_MONTHLY: {
                if(nextCal.getDate() == getPeriodDate1()) {
                    nextCal.setDate(getPeriodDate2());
                }
                else {
                    nextCal.setDate(getPeriodDate1());
                    nextCal.addMonths(1);
                }
                return nextCal;
            }
            case MONTHLY: {
                nextCal.addMonths(1);
                return nextCal;
            }
            case WEEKLY: {
                nextCal.addDays(7);
                return nextCal;
            }
            default: {
                nextCal.addDays(14);
                return nextCal;
            }
        }
    }

    private double createPeriodItemsFromRecurringPayments(@NotNull PeriodEntity period,
                                                          PeriodEntity nextPeriod,
                                                          double rollOver,
                                                          @NotNull List<IncomeSourceEntity> incomeSources,
                                                          @NotNull List<RecurringPaymentEntity> recurringPayments) {
        Date                     periodDate          = period.getPeriodDate();
        Date                     nextPeriodDate      = ((nextPeriod == null) ? getNextPeriodDate(period).getTime() : nextPeriod.getPeriodDate());
        List<IncomeSourceEntity> activeIncomeSources = filterIncomeSourcesByDate(incomeSources, periodDate, nextPeriodDate);

        if(activeIncomeSources.size() > 0) {
            IncomeSourceEntity defaultIncomeSource = getDefaultIncomeSource(activeIncomeSources);
            double             incomeAmount        = getPeriodIncomeAmount(activeIncomeSources);
            double             debitAmount         = createPeriodItemsFromRecurringPayments(period, defaultIncomeSource, activeIncomeSources, recurringPayments);
            double             remainingAmount     = ((incomeAmount + rollOver) - debitAmount);

            period.setRollOverAmount(BigDecimal.valueOf(rollOver));
            period.setTotalIncome(BigDecimal.valueOf(incomeAmount));
            period.setTotalDebit(BigDecimal.valueOf(debitAmount));
            period.setRemainingAmount(BigDecimal.valueOf(remainingAmount));
            period.saveChanges();
            return remainingAmount;
        }
        else {
            BigDecimal ro = BigDecimal.valueOf(rollOver);
            period.setRollOverAmount(ro);
            period.setRemainingAmount(ro);
            period.setTotalIncome(BigDecimal.ZERO);
            period.setTotalDebit(BigDecimal.ZERO);
            period.saveChanges();
            return rollOver;
        }
    }

    private @NotNull List<PeriodEntity> createPeriods(@NotNull Kalendar start, @NotNull Kalendar stop, int count) {
        List<PeriodEntity> out = new ArrayList<>();
        Kalendar           end = Dates.min(stop, Kalendar.getInstance(getEndingDate()));

        switch(getPeriodType()) {
            case MONTHLY: {
                while((start.compareTo(end) <= 0) && (count > 0)) {
                    out.add(PeriodEntity.getNewEntity(this, start.getTime()));
                    start.addMonths(1);
                    count--;
                }
                break;
            }
            case WEEKLY: {
                while(start.getDayOfWeek() != getPeriodDate1()) start.addDays(1);
                while((start.compareTo(end) <= 0) && (count > 0)) {
                    out.add(PeriodEntity.getNewEntity(this, start.getTime()));
                    start.addDays(7);
                    count--;
                }
                break;
            }
            case BIWEEKLY: {
                while((start.compareTo(end) <= 0) && (count > 0)) {
                    out.add(PeriodEntity.getNewEntity(this, start.getTime()));
                    start.addDays(14);
                    count--;
                }
                break;
            }
            case TWICE_MONTHLY: {
                int      date1 = getPeriodDate1();
                int      date2 = getPeriodDate2();
                Kalendar k1    = start.clone();
                Kalendar k2    = start.clone();
                k1.setDate(date1);
                k2.setDate(date2);
                if(start.compareTo(k1) > 0) k1.addMonths(1);
                if(start.compareTo(k2) > 0) k2.addMonths(1);
                Kalendar[] dates = new Kalendar[]{ k1, k2 };

                for(int i = 0; i < count; i++) {
                    Kalendar dt = dates[i % 2];
                    if(dt.compareTo(end) > 0) break;
                    out.add(PeriodEntity.getNewEntity(this, dt.toSQLDate()));
                    dt.addMonths(1);
                }

                break;
            }
            case OTHER: {
                List<Kalendar> cals = getActiveOtherPeriodCalendarDates();
                cals.forEach(k -> {
                    k.setYear(start.getYear());
                    if(k.compareTo(start) < 0) k.addYears(1);
                });
                cals.sort(Calendar::compareTo);
                for(int i = 0, lim = cals.size(); i < count; i++) {
                    Kalendar dt = cals.get(i % lim);
                    if(dt.compareTo(end) > 0) break;
                    out.add(PeriodEntity.getNewEntity(this, dt.toSQLDate()));
                    dt.addYears(1);
                }
                break;
            }
        }
        return out;
    }

    private @NotNull List<PeriodEntity> createPeriods(@NotNull Kalendar start, @NotNull Kalendar stop, int count, @NotNull BigDecimal rollOver) {
        List<PeriodEntity>           list              = createPeriods(start, stop, count);
        List<IncomeSourceEntity>     incomeSources     = find(IncomeSourceEntity.class);
        List<RecurringPaymentEntity> recurringPayments = find(RecurringPaymentEntity.class);
        double                       rollOverAmount    = rollOver.doubleValue();

        for(int i = 0, j = list.size(); i < j; i++) {
            PeriodEntity period     = list.get(i);
            PeriodEntity nextPeriod = (((i + 1) < j) ? list.get(i + 1) : null);
            rollOverAmount = createPeriodItemsFromRecurringPayments(period, nextPeriod, rollOverAmount, incomeSources, recurringPayments);
        }

        return list;
    }

    @Transient
    private @NotNull List<Kalendar> getActiveOtherPeriodCalendarDates() {
        List<Kalendar>               out    = new ArrayList<>();
        List<OtherPeriodDatesEntity> others = find(OtherPeriodDatesEntity.class, "otherDate");
        others.forEach(od -> out.add(new Kalendar(od.getOtherDate())));
        return out;
    }

    @Transient
    private @NotNull Kalendar getInitialPeriodDate() {
        switch(getPeriodType()) {
            case OTHER: {
                List<Kalendar> otherDates = getActiveOtherPeriodCalendarDates();
                if(otherDates.size() == 0) throw new PGBudgetDBException(msgs.getString("msg.err.no_active_period_dates"));

                Kalendar budgetStart = getStartingDateCalendar();

                for(Kalendar od : otherDates) {
                    od.setYear(budgetStart.getYear());
                    if(budgetStart.after(od)) od.addYears(1);
                    else return od;
                }
                return otherDates.get(0);
            }
            case MONTHLY: {
                Kalendar k = getStartingDateCalendar();
                Kalendar c = k.clone();
                c.setDate(getPeriodDate1());
                if(k.after(c)) c.addMonths(1);
                return c;
            }
            case WEEKLY: {
                Kalendar k  = getStartingDateCalendar();
                Kalendar c  = k.clone();
                int      pd = getPeriodDate1();

                if(pd < 1) throw new PGBudgetDBException(msgs.format("msg.err.invalid_weekday", pd, "< 1"));
                if(pd > 7) throw new PGBudgetDBException(msgs.format("msg.err.invalid_weekday", pd, "> 7"));

                while(c.getDayOfWeek() != getPeriodDate1()) c.addDays(1);
                return c;
            }
            case BIWEEKLY: {
                return getStartingDateCalendar();
            }
            case TWICE_MONTHLY: {
                Kalendar k  = getStartingDateCalendar();
                Kalendar c1 = k.clone();
                Kalendar c2 = k.clone();

                c1.setDate(getPeriodDate1());
                c2.setDate(getPeriodDate2());
                if(k.compareTo(c1) <= 0) return c1;
                if(k.compareTo(c2) <= 0) return c2;
                c1.addMonths(1);
                return c1;
            }
            default:
                throw new PGBudgetDBException(msgs.getString("msg.err.validation.bad_period_type"));
        }
    }

    @Transient
    @Nullable
    private PeriodEntity getLastActivePeriod() {
        List<PeriodEntity> list = find(PeriodEntity.class, 1, "periodDate desc");
        return ((list.size() >= 1) ? list.get(0) : null);
    }

    @Contract(" -> new")
    @Transient
    private @NotNull Kalendar getStartingDateCalendar() {
        return new Kalendar(getStartingDate());
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user,
                                                        @NotNull String name,
                                                        @NotNull PeriodType periodType,
                                                        @NotNull Date startDate,
                                                        int periodDate,
                                                        WeekDay periodWeekDay,
                                                        int twiceMonthlyDate1,
                                                        int twiceMonthlyDate2,
                                                        List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = new BudgetEntity(false);

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);
        budget.setToKeyValueInfo(KvInfoEntity.getNewEntity());

        switch(periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                budget.setPeriodDate2(null);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay.getId());
                budget.setPeriodDate2(null);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(Math.min(twiceMonthlyDate1, twiceMonthlyDate2));
                budget.setPeriodDate2(Math.max(twiceMonthlyDate1, twiceMonthlyDate2));
                break;
            case BIWEEKLY:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);
                break;
            case OTHER:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);

                for(Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = OtherPeriodDatesEntity.getNewEntity();
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }

                break;
            default:
                break;
        }

        budget.saveChanges();

        for(OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }

        return budget;
    }

    public static @NotNull ValidationResponse validateBudgetData(String budgetName, PeriodType periodType, Date startDate, WeekDay weekDay, int date, int date1, int date2, List<Date> otherDates) {
        String name = U.tr(budgetName);
        if(U.z(name)) return new ValidationResponse(msgs.getString("msg.err.validation.budget_name_required"));
        if(periodType == null) return new ValidationResponse(msgs.getString("msg.err.validation.period_type_required"));
        if(startDate == null) return new ValidationResponse(msgs.getString("msg.err.validation.start_date_required"));
        return validatePeriodTypeData(periodType, weekDay, date, date1, date2, otherDates);
    }

    private static double createPeriodItemFromRecurringPayment(@NotNull PeriodEntity period,
                                                               @NotNull RecurringPaymentEntity recurringPayment,
                                                               @NotNull IncomeSourceEntity defaultIncomeSource,
                                                               double debitAmount) {
        BigDecimal       amount = recurringPayment.getAmount();
        PeriodItemEntity item   = PeriodItemEntity.getNewEntity();

        item.setPayeeName(recurringPayment.getPayeeName());
        item.setAmount(amount);
        item.setItemState(ItemState.NONE);
        item.setToPeriod(period);
        item.setToCategory(recurringPayment.getToCategory());
        item.setToRecurring(recurringPayment);

        PeriodIncomeEntity pIncome = PeriodIncomeEntity.getNewEntity();
        pIncome.setToPeriod(period);
        pIncome.setToIncomeSource(Objects.requireNonNullElse(recurringPayment.getToIncomeSource(), defaultIncomeSource));
        pIncome.saveChanges();

        item.setToPeriodIncomeSource(pIncome);
        item.saveChanges();
        debitAmount += amount.doubleValue();
        return debitAmount;
    }

    private static double createPeriodItemsFromRecurringPayments(@NotNull PeriodEntity period,
                                                                 @NotNull IncomeSourceEntity defaultIncomeSource,
                                                                 @NotNull List<IncomeSourceEntity> activeIncomeSources,
                                                                 @NotNull List<RecurringPaymentEntity> recurringPayments) {
        double debitAmount = 0;
        for(RecurringPaymentEntity rPayment : recurringPayments) debitAmount = createPeriodItemFromRecurringPayment(period, rPayment, defaultIncomeSource, debitAmount);
        return debitAmount;
    }

    private static @NotNull List<IncomeSourceEntity> filterIncomeSourcesByDate(@NotNull List<IncomeSourceEntity> incomeSources, @NotNull Date periodDate, @NotNull Date nextPeriodDate) {
        List<IncomeSourceEntity> activeIncomeSources = new ArrayList<>();
        for(IncomeSourceEntity src : incomeSources) if(Dates.datesOverlap(periodDate, nextPeriodDate, src.getStartDate(), src.getEndDate())) activeIncomeSources.add(src);
        return activeIncomeSources;
    }

    private static IncomeSourceEntity getDefaultIncomeSource(@NotNull List<IncomeSourceEntity> incomeSources) {
        for(IncomeSourceEntity src : incomeSources) if(src.getIsDefault()) return src;
        return incomeSources.get(0);
    }

    private static double getPeriodIncomeAmount(@NotNull List<IncomeSourceEntity> activeIncomeSources) {
        double incomeAmount = 0;
        for(IncomeSourceEntity src : activeIncomeSources) incomeAmount += src.getAmount().doubleValue();
        return incomeAmount;
    }

    private static @NotNull ValidationResponse getValidationResponse(boolean notValid, String msg) {
        return (notValid ? new ValidationResponse(false, msg) : new ValidationResponse(true, null));
    }

    private static @NotNull ValidationResponse validatePeriodTypeData(@NotNull PeriodType periodType,
                                                                      @Nullable WeekDay weekDay,
                                                                      int date,
                                                                      int date1,
                                                                      int date2,
                                                                      @NotNull List<Date> otherDates) {
        switch(periodType) {/*@f0*/
            case MONTHLY:       return getValidationResponse((date <= 0), msgs.getString("msg.err.validation.pay_date_required"));
            case WEEKLY:        return getValidationResponse((weekDay == null), msgs.getString("msg.err.validation.weekday_required"));
            case BIWEEKLY:      return new ValidationResponse();
            case TWICE_MONTHLY: return getValidationResponse(((date1 <= 0) || (date2 <= 0)), msgs.getString("msg.err.validation.2x_dates_required"));
            case OTHER:         return getValidationResponse((otherDates.size() == 0), msgs.getString("msg.err.validation.other_period_date_required"));
            default:            return new ValidationResponse(msgs.getString("msg.err.validation.bad_period_type"));
        }/*@f1*/
    }
}
