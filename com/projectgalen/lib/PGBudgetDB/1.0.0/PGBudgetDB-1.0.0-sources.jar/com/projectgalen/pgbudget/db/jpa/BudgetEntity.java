package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: March 27, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.annotations.PGCurrentTimestamp;
import com.projectgalen.lib.utils.annotations.PGDefaultValue;
import com.projectgalen.pgbudget.db.converters.StateConverter;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.*;
import org.jetbrains.annotations.NotNull;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

@PGJPA
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends JpaBase {
    private @Column(name = "budget_id", precision = 19, scale = 0) @Id @GeneratedValue(strategy = GenerationType.IDENTITY)                Long                               budgetId;
    private @Column(name = "user_id", precision = 19, scale = 0)                                                                          Long                               userId;
    private @Column(name = "kv_id", precision = 19, scale = 0)                                                                            Long                               kvId;
    private @Column(name = "name", length = 255)                                                                                          String                             name;
    private @Column(name = "state", precision = 10, scale = 0) @Convert(converter = StateConverter.class) @PGDefaultValue("State.ACTIVE") State                              state;
    private @Column(name = "starting_date")                                                                                               Date                               startingDate;
    private @Column(name = "period_type", precision = 10, scale = 0)                                                                      Integer                            periodType;
    private @Column(name = "period_length", precision = 10, scale = 0)                                                                    Integer                            periodLength;
    private @Column(name = "date_created") @PGCurrentTimestamp                                                                            Timestamp                          dateCreated;
    private @Column(name = "date_updated") @PGCurrentTimestamp                                                                            Timestamp                          dateUpdated;
    private @ManyToOne @JoinColumn(name = "user_id", referencedColumnName = "user_id")                                                    UsersEntity                        toUser;
    private @ManyToOne @JoinColumn(name = "kv_id", referencedColumnName = "kv_id")                                                        KvInfoEntity                       toKv;
    private @OneToMany(mappedBy = "toBudget", fetch = FetchType.LAZY)                                                                     Collection<IncomeSourceEntity>     toIncomeSources;
    private @OneToMany(mappedBy = "toBudget", fetch = FetchType.LAZY)                                                                     Collection<RecurringPaymentEntity> toRecurringPayments;

    public BudgetEntity() { }

    public BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        this.state       = State.ACTIVE;
        this.dateCreated = Dates.getTimestamp();
        this.dateUpdated = Dates.getTimestamp();
    }

    public Long getBudgetId() {
        return this.budgetId;
    }

    public Timestamp getDateCreated() {
        return this.dateCreated;
    }

    public Long getKvId() {
        return this.kvId;
    }

    public Timestamp getDateUpdated() {
        return this.dateUpdated;
    }

    public State getState() {
        return this.state;
    }

    public String getName() {
        return this.name;
    }

    public Integer getPeriodLength() {
        return this.periodLength;
    }

    public Integer getPeriodType() {
        return this.periodType;
    }

    public Date getStartingDate() {
        return this.startingDate;
    }

    public Collection<IncomeSourceEntity> getToIncomeSources() {
        return Collections.unmodifiableCollection(this.toIncomeSources);
    }

    public Collection<RecurringPaymentEntity> getToRecurringPayments() {
        return Collections.unmodifiableCollection(this.toRecurringPayments);
    }

    public KvInfoEntity getToKv() {
        return this.toKv;
    }

    public UsersEntity getToUser() {
        return this.toUser;
    }

    public Long getUserId() {
        return this.userId;
    }

    public void setBudgetId(@NotNull Long budgetId) {
        if(Objects.equals(this.budgetId, budgetId)) return;
        this.budgetId = budgetId;
        setAsDirty();
    }

    public void setDateCreated(@NotNull Timestamp dateCreated) {
        if(Objects.equals(this.dateCreated, dateCreated)) return;
        this.dateCreated = dateCreated;
        setAsDirty();
    }

    public void setDateUpdated(@NotNull Timestamp dateUpdated) {
        if(Objects.equals(this.dateUpdated, dateUpdated)) return;
        this.dateUpdated = dateUpdated;
        setAsDirty();
    }

    public void setKvId(@NotNull Long kvId) {
        if(Objects.equals(this.kvId, kvId)) return;
        this.kvId = kvId;
        setAsDirty();
    }

    public void setName(@NotNull String name) {
        if(Objects.equals(this.name, name)) return;
        this.name = name;
        setAsDirty();
    }

    public void setPeriodLength(@NotNull Integer periodLength) {
        if(Objects.equals(this.periodLength, periodLength)) return;
        this.periodLength = periodLength;
        setAsDirty();
    }

    public void setPeriodType(@NotNull Integer periodType) {
        if(Objects.equals(this.periodType, periodType)) return;
        this.periodType = periodType;
        setAsDirty();
    }

    public void setStartingDate(@NotNull Date startingDate) {
        if(Objects.equals(this.startingDate, startingDate)) return;
        this.startingDate = startingDate;
        setAsDirty();
    }

    public void setState(@NotNull State state) {
        if(Objects.equals(this.state, state)) return;
        this.state = state;
        setAsDirty();
    }

    public void setToKv(KvInfoEntity toKv) {
        if(Objects.equals(this.toKv, toKv)) return;
        this.toKv = toKv;
        setAsDirty();
    }

    public void setToUser(UsersEntity toUser) {
        if(Objects.equals(this.toUser, toUser)) return;
        this.toUser = toUser;
        setAsDirty();
    }

    public void setUserId(@NotNull Long userId) {
        if(Objects.equals(this.userId, userId)) return;
        this.userId = userId;
        setAsDirty();
    }

    public void addToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(Objects.equals(object.getToBudget(), this)) return;
        if(object.getToBudget() != null) object.getToBudget().removeFromToIncomeSources(object);
        object.setToBudget(this);
        if(!this.toIncomeSources.contains(object)) this.toIncomeSources.add(object);
        setAsDirty();
    }

    public void addToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(Objects.equals(object.getToBudget(), this)) return;
        if(object.getToBudget() != null) object.getToBudget().removeFromToRecurringPayments(object);
        object.setToBudget(this);
        if(!this.toRecurringPayments.contains(object)) this.toRecurringPayments.add(object);
        setAsDirty();
    }

    public void removeFromToIncomeSources(@NotNull IncomeSourceEntity object) {
        if(!Objects.equals(object.getToBudget(), this)) return;
        object.setToBudget(null);
        this.toIncomeSources.remove(object);
        setAsDirty();
    }

    public void removeFromToRecurringPayments(@NotNull RecurringPaymentEntity object) {
        if(!Objects.equals(object.getToBudget(), this)) return;
        object.setToBudget(null);
        this.toRecurringPayments.remove(object);
        setAsDirty();
    }
}
