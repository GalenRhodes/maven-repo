package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.pgbudget.db.C;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.*;

import static com.projectgalen.pgbudget.db.C.isDateInRange;

@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user, @NotNull String name, @NotNull PeriodType periodType, @NotNull Date startDate, int periodDate, int periodWeekDay, int twiceMonthlyDate1, int twiceMonthlyDate2, List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = getNewEntity();

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);

        switch (periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(twiceMonthlyDate1);
                budget.setPeriodDate2(twiceMonthlyDate2);
                break;
            case BIWEEKLY:
                break;
            case OTHER:
                for (Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = new OtherPeriodDatesEntity(false);
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }
                break;
            default:
                break;
        }

        budget.saveChanges();
        for (OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }
        return budget;
    }

    @Contract(" -> new")
    public static @NotNull BudgetEntity getNewEntity() {
        BudgetEntity e = new BudgetEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }

    @SuppressWarnings("MagicConstant")
    public void createPeriods() {
        //----------------------------------------------------------------------------------------------------
        // Create budget periods for the next year.
        //
        C.ForDate noop = c -> {
        };
        C.ForDate createAction = c -> {
            PeriodEntity period = PeriodEntity.getNewEntity();
            period.setPeriodDate(Dates.toSQLDate(c));
            period.setToBudget(this);
            period.saveChanges();
        };

        switch (getPeriodType()) {
            case OTHER: {
                Calendar start = Dates.toCalendar(getStartingDate());
                for (OtherPeriodDatesEntity other : getToOtherPeriodDates()) {
                    Calendar c = Dates.toCalendar(other.getOtherDate());
                    if (start.before(c)) createAction.action(c);
                }
                break;
            }
            case MONTHLY: {
                int d1 = getPeriodDate1();
                C.IncrementCalendar inc = c -> {
                    c.set(Calendar.DATE, 1);
                    c.add(Calendar.MONTH, 1);
                    c.set(Calendar.DATE, Math.min(d1, c.getActualMaximum(Calendar.DATE)));
                };
                Calendar startDate = Dates.toCalendar(getStartingDate());
                startDate.set(Calendar.DATE, d1);
                startDate = C.enumerateDates(startDate, Dates.toCalendar(getStartingDate()), inc, noop);
                C.enumerateDates(startDate, C.getNextYear(startDate), inc, createAction);
                break;
            }
            case WEEKLY: {
                Calendar startDate = Dates.toCalendar(getStartingDate());
                int      wd        = getPeriodDate1();
                if (wd < 0 || wd > 7) wd = Calendar.FRIDAY; // Friday is typical.
                while (wd != startDate.get(Calendar.DAY_OF_WEEK)) startDate.add(Calendar.DATE, 1);
                C.enumerateDates(startDate, C.getNextYear(startDate), c -> c.add(Calendar.DATE, 7), createAction);
                break;
            }
            case BIWEEKLY: {
                Calendar startDate = Dates.toCalendar(getStartingDate());
                C.enumerateDates(startDate, C.getNextYear(startDate), c -> c.add(Calendar.DATE, 14), createAction);
                break;
            }
            case TWICE_MONTHLY: {
                int d1 = Math.min(getPeriodDate1(), getPeriodDate2());
                int d2 = Math.max(getPeriodDate1(), getPeriodDate2());
                C.IncrementCalendar inc = c -> {
                    if (c.get(Calendar.DATE) == d1) {
                        c.set(Calendar.DATE, d2);
                    }
                    else {
                        c.set(Calendar.DATE, d1);
                        c.add(Calendar.MONTH, 1);
                    }
                };

                Calendar start = Dates.toCalendar(getStartingDate());
                start.set(Calendar.DATE, d1);
                start = C.enumerateDates(start, Dates.toCalendar(getStartingDate()), inc, noop);

                C.enumerateDates(start, C.getNextYear(start), inc, createAction);
                break;
            }
        }
        //
        //----------------------------------------------------------------------------------------------------
    }

    @Transient
    public @NotNull List<BankAccountsEntity> getActiveBankAccounts() {
        Date                     now  = Calendar.getInstance().getTime();
        List<BankAccountsEntity> list = new ArrayList<>();

        for (BankAccountsEntity bankAccount : getToBankAccounts()) {
            if ((bankAccount.getState() == State.ACTIVE) && isDateInRange(now, bankAccount.getStartDate(), bankAccount.getEndDate()))
                list.add(bankAccount);
        }

        return list;
    }

    @Transient
    public @NotNull List<IncomeSourceEntity> getActiveIncomeSources() {
        Date                     now  = Calendar.getInstance().getTime();
        List<IncomeSourceEntity> list = new ArrayList<>();

        for (IncomeSourceEntity incomeSource : getToIncomeSources()) {
            if ((incomeSource.getState() == State.ACTIVE) && isDateInRange(now, incomeSource.getStartDate(), incomeSource.getEndDate()))
                list.add(incomeSource);
        }

        return list;
    }

    @Transient
    public @NotNull List<RecurringPaymentEntity> getActiveRecurringPayments() {
        List<RecurringPaymentEntity> list = new ArrayList<>();
        Date                         now  = Calendar.getInstance().getTime();

        for (RecurringPaymentEntity recurringPayment : getToRecurringPayments()) {
            if ((recurringPayment.getState() == State.ACTIVE) && isDateInRange(now, recurringPayment.getStartDate(), recurringPayment.getEndDate()))
                list.add(recurringPayment);
        }

        return list;
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }
}
