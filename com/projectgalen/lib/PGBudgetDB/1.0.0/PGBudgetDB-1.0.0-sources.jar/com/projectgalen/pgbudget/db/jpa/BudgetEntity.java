package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGArrays;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodState;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import com.projectgalen.pgbudget.db.jpa.enums.WeekDay;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.projectgalen.pgbudget.db.C.isDateInRange;

@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    @Transient public @NotNull List<PeriodEntity> createNextPeriods(Date until) {
        List<PeriodEntity> list  = HibernateUtil.find(PeriodEntity.class, PGArrays.wrap("state", "toBudget"), PGArrays.wrap(State.ACTIVE, this), PGArrays.wrap("periodDate desc"), 0, 1);
        List<PeriodEntity> out   = new ArrayList<>();
        PeriodEntity       last  = ((list.size() == 1) ? list.get(0) : null);
        Calendar           start = ((last == null) ? null : Dates.toCalendar(last.getPeriodDate()));
        Calendar           stop  = Dates.toCalendar(until);

        if(start == null) start = Objects.requireNonNullElse(Dates.toCalendar(getStartingDate()), Calendar.getInstance()); // This should never be null but just in case...
        fooMe(out, start, stop);

        return out;
    }

    @Transient public @NotNull List<BankAccountsEntity> getActiveBankAccounts() {
        Date                     now  = Calendar.getInstance().getTime();
        List<BankAccountsEntity> list = new ArrayList<>();

        for(BankAccountsEntity bankAccount : getToBankAccounts()) {
            if((bankAccount.getState() == State.ACTIVE) && isDateInRange(now, bankAccount.getStartDate(), bankAccount.getEndDate())) list.add(bankAccount);
        }

        return list;
    }

    @Transient public @NotNull List<IncomeSourceEntity> getActiveIncomeSources() {
        Date                     now  = Calendar.getInstance().getTime();
        List<IncomeSourceEntity> list = new ArrayList<>();

        for(IncomeSourceEntity incomeSource : getToIncomeSources()) {
            if((incomeSource.getState() == State.ACTIVE) && isDateInRange(now, incomeSource.getStartDate(), incomeSource.getEndDate())) list.add(incomeSource);
        }

        return list;
    }

    @Transient public List<PeriodEntity> getActivePeriods() {
        return HibernateUtil.find(PeriodEntity.class, PGArrays.wrap("state", "toBudget"), PGArrays.wrap(State.ACTIVE, this), PGArrays.wrap("periodDate"));
    }

    @Transient public @NotNull List<RecurringPaymentEntity> getActiveRecurringPayments() {
        List<RecurringPaymentEntity> list = new ArrayList<>();
        Date                         now  = new Date();

        for(RecurringPaymentEntity recurringPayment : getToRecurringPayments()) {
            if((recurringPayment.getState() == State.ACTIVE) && isDateInRange(now, recurringPayment.getStartDate(), recurringPayment.getEndDate())) list.add(recurringPayment);
        }

        return list;
    }

    @Override public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    @Transient private @NotNull PeriodEntity createNewPeriod(Calendar cal) {
        PeriodEntity pe = PeriodEntity.getNewEntity();
        pe.setPeriodDate(Dates.toSQLDate(cal));
        pe.setPeriodState(cal.before(Calendar.getInstance()) ? PeriodState.IN_PROGRESS : PeriodState.FUTURE);
        pe.setToBudget(this);
        pe.saveChanges();
        return pe;
    }

    private void fooMe(List<PeriodEntity> out, Calendar start, Calendar stop) {
        if(stop == null) {
            Date e = getEndingDate();
            stop = (Calendar)start.clone();
            stop.add(Calendar.YEAR, 1);
            if((e != null) && stop.getTime().after(e)) stop = Dates.toCalendar(e);
        }

        switch(getPeriodType()) {
            case MONTHLY:
                if(start.get(Calendar.DATE) < getPeriodDate1()) start.add(Calendar.MONTH, 1);
                start.set(Calendar.DATE, getPeriodDate1());
                fooMe1(out, start, stop, Calendar.MONTH, 1);
                break;
            case WEEKLY:
                while(start.get(Calendar.DAY_OF_WEEK) != WeekDay.getWeekDay(getPeriodDate1()).toCalendarWeekDay()) start.add(Calendar.DATE, 1);
                fooMe1(out, start, stop, Calendar.DATE, 7);
                break;
            case BIWEEKLY:
                fooMe1(out, start, stop, Calendar.DATE, 14);
                break;
            case TWICE_MONTHLY:
                Calendar[] dates = foo(start, getPeriodDate1(), getPeriodDate2());
                int idx = 0;

                while(dates[idx].compareTo(stop) <= 0) {
                    fooMe2(out, dates[idx], Calendar.MONTH, 1);
                    idx = ((idx + 1) % 2);
                }

                break;
            default:
                List<OtherPeriodDatesEntity> others = HibernateUtil.find(OtherPeriodDatesEntity.class,
                                                                         PGArrays.wrap("state", "toBudget"),
                                                                         PGArrays.wrap(State.ACTIVE, this),
                                                                         PGArrays.wrap("otherDate"));
                List<Calendar> cals = new ArrayList<>();
                others.forEach(o -> cals.add(Dates.toCalendar(o.getOtherDate())));
                boolean flag = true;

                do {
                    for(int i = 0; flag && i < cals.size(); i++) {
                        Calendar other = cals.get(i);
                        if(other.after(stop)) flag = false;
                        else if(other.compareTo(start) >= 0) fooMe2(out, other, Calendar.YEAR, 1);
                        else other.add(Calendar.YEAR, 1);
                    }
                }
                while(flag);
                break;
        }
    }

    private void fooMe1(@NotNull List<PeriodEntity> out, @NotNull Calendar cal, @NotNull Calendar stop, int field, int inc) {
        while(cal.compareTo(stop) <= 0) fooMe2(out, cal, field, inc);
    }

    private void fooMe2(@NotNull List<PeriodEntity> out, @NotNull Calendar cal, int field, int inc) {
        out.add(createNewPeriod(cal));
        cal.add(field, inc);
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user,
                                                        @NotNull String name,
                                                        @NotNull PeriodType periodType,
                                                        @NotNull Date startDate,
                                                        int periodDate,
                                                        int periodWeekDay,
                                                        int twiceMonthlyDate1,
                                                        int twiceMonthlyDate2,
                                                        List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = getNewEntity();

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);

        switch(periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(twiceMonthlyDate1);
                budget.setPeriodDate2(twiceMonthlyDate2);
                break;
            case BIWEEKLY:
                break;
            case OTHER:
                for(Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = new OtherPeriodDatesEntity(false);
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }
                break;
            default:
                break;
        }

        budget.saveChanges();
        for(OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }
        return budget;
    }

    private static @NotNull ValidationResponse getValidationResponse(boolean notValid, String msg) {
        return (notValid ? new ValidationResponse(false, msg) : new ValidationResponse(true, null));
    }

    public static @NotNull ValidationResponse validateBudgetData(String budgetName, PeriodType periodType, Date startDate, WeekDay weekDay, int date, int date1, int date2, List<Date> otherDates) {
        String name = U.tr(budgetName);
        if(U.z(name)) return new ValidationResponse("The budget name field is required");
        if(periodType == null) return new ValidationResponse("You must select a period type.");
        if(startDate == null) return new ValidationResponse("Starting Date is required.");
        return validatePeriodTypeData(periodType, startDate, weekDay, date, date1, date2, otherDates);
    }

    private static @NotNull ValidationResponse validatePeriodTypeData(@NotNull PeriodType periodType,
                                                                      Date startDate,
                                                                      @Nullable WeekDay weekDay,
                                                                      int date,
                                                                      int date1,
                                                                      int date2,
                                                                      @NotNull List<Date> otherDates) {
        switch(periodType) {/*@f0*/
            case MONTHLY:       return getValidationResponse((date <= 0), "The monthly pay date is required.");
            case WEEKLY:        return getValidationResponse((weekDay == null), "The weekly weekday is required.");
            case BIWEEKLY:      return new ValidationResponse();
            case TWICE_MONTHLY: return getValidationResponse(((date1 <= 0) || (date2 <= 0)), "The twice monthly pay dates are required.");
            case OTHER:         return getValidationResponse((otherDates.size() == 0), "You must enter at least one other period date.");
            default:            return new ValidationResponse("Unsupported Period Type");
        }/*@f1*/
    }

    @Contract(" -> new") public static @NotNull BudgetEntity getNewEntity() {
        BudgetEntity e = new BudgetEntity(false);
        e.setToKeyValueInfo(KvInfoEntity.getNewEntity());
        return e;
    }

    private static Calendar @NotNull [] foo(@NotNull Calendar cal, int date1, int date2) {
        int      cd = cal.get(Calendar.DATE);
        int      d1 = Math.min(date1, date2);
        int      d2 = Math.max(date1, date2);
        Calendar c  = (Calendar)cal.clone();
        return (((d1 < cd) && (d2 < cd)) ? foo1(c, d1, d2) : ((d1 < cd) ? foo2(c, d1, d2) : foo3(c, d1, d2)));
    }

    private static @NotNull Calendar @NotNull [] foo1(@NotNull Calendar c, int d1, int d2) {
        c.add(Calendar.MONTH, 1);
        return foo3(c, d1, d2);
    }

    private static @NotNull Calendar @NotNull [] foo2(@NotNull Calendar c, int d1, int d2) {
        Calendar[] out = new Calendar[2];
        c.set(Calendar.DATE, d2);
        out[0] = (Calendar)c.clone();
        c.add(Calendar.MONTH, 1);
        c.set(Calendar.DATE, d1);
        out[1] = c;
        return out;
    }

    private static @NotNull Calendar @NotNull [] foo3(@NotNull Calendar c, int d1, int d2) {
        Calendar[] out = new Calendar[2];
        c.set(Calendar.DATE, d1);
        out[0] = (Calendar)c.clone();
        c.set(Calendar.DATE, d2);
        out[1] = c;
        return out;
    }
}
