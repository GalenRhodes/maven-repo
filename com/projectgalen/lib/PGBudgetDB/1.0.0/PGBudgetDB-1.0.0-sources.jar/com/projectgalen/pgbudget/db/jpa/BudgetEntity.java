package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 7, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.jetbrains.annotations.NotNull;

@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    public BudgetEntity() { super(); }

    public BudgetEntity(@SuppressWarnings("unused") boolean dummy) { super(dummy); }

    public static @NotNull BudgetEntity getNewEntity() { return BudgetEntityDao.shared().getNewEntity(); }

    @Override
    public @NotNull State getState() {
        State _state = super.getState();
        return ((_state == null) ? State.INACTIVE : _state);
    }
}
