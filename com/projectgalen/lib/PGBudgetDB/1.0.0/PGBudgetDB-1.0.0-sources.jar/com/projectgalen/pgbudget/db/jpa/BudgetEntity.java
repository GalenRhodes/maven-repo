package com.projectgalen.pgbudget.db.jpa;

// ===========================================================================
//     PROJECT: PG Budget
//    FILENAME: BudgetEntity.java
//      AUTHOR: Galen Rhodes
//        DATE: April 30, 2023
//
// Copyright © 2023 Project Galen. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
//
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR
// IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
// ===========================================================================

import com.projectgalen.lib.jpa.utils.HibernateUtil;
import com.projectgalen.lib.jpa.utils.annotations.PGJPA;
import com.projectgalen.lib.jpa.utils.base.JpaBase;
import com.projectgalen.lib.utils.Dates;
import com.projectgalen.lib.utils.PGCalendar;
import com.projectgalen.lib.utils.PGCollections;
import com.projectgalen.lib.utils.U;
import com.projectgalen.pgbudget.db.errors.PGBudgetDBException;
import com.projectgalen.pgbudget.db.errors.ValidationResponse;
import com.projectgalen.pgbudget.db.jpa.base._BudgetEntity;
import com.projectgalen.pgbudget.db.jpa.dao.BudgetEntityDao;
import com.projectgalen.pgbudget.db.jpa.enums.PeriodType;
import com.projectgalen.pgbudget.db.jpa.enums.State;
import com.projectgalen.pgbudget.db.jpa.enums.WeekDay;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.projectgalen.lib.utils.PGArrays.wrap;
import static com.projectgalen.pgbudget.db.C.msgs;

@PGJPA(daoClass = BudgetEntityDao.class)
@Entity
@Table(name = "budget", schema = "pgbudget")
public class BudgetEntity extends _BudgetEntity {

    protected BudgetEntity() {
        super();
    }

    protected BudgetEntity(@SuppressWarnings("unused") boolean dummy) {
        super(dummy);
    }

    public @NotNull List<PeriodEntity> createNextPeriods(Date until, @NotNull BigDecimal rollOverAmount) {
        PGCalendar stopDate = getStopDate(until);
        return createNextPeriods(rollOverAmount, (cc, dt) -> (dt.compareTo(stopDate) <= 0));
    }

    public @NotNull List<PeriodEntity> createNextPeriods(int count, @NotNull BigDecimal rollOverAmount) {
        if(count <= 0) return new ArrayList<>();
        PGCalendar stopDate = Objects.requireNonNullElse(PGCalendar.getInstance(getEndingDate()), PGCalendar.distantFuture());
        return createNextPeriods(rollOverAmount, (cc, dt) -> ((cc < count) && (dt.compareTo(stopDate) <= 0)));
    }

    @Transient
    public List<BankAccountsEntity> getBankAccounts() {
        return find(BankAccountsEntity.class);
    }

    public @Nullable BankAccountsEntity getDefaultBankAccountActiveOn(@NotNull Date date) {
        List<BankAccountsEntity> bankAccounts = getBankAccounts().stream().filter(b -> b.isInRange(date)).collect(Collectors.toList());
        if(bankAccounts.isEmpty()) return null;
        for(BankAccountsEntity bank : bankAccounts) if(bank.getIsDefault()) return bank;
        return bankAccounts.get(0);
    }

    @Transient
    public List<IncomeSourceEntity> getIncomeSources() {
        return find(IncomeSourceEntity.class);
    }

    @Transient
    public PeriodEntity getLastPeriod() {
        List<PeriodEntity> list = find(PeriodEntity.class, 1, "periodDate desc");
        return ((list.size() >= 1) ? list.get(0) : null);
    }

    public Date getNextPeriodDate(Date periodDate) {
        return getNextPeriodDate(PGCalendar.getInstance(periodDate)).getTime();
    }

    @Transient
    public List<OtherPeriodDatesEntity> getOtherPeriodDates() {
        return find(OtherPeriodDatesEntity.class, "otherDate");
    }

    @Transient
    public @NotNull List<PGCalendar> getOtherPeriodDatesAsCalendar() {
        return getOtherPeriodDates().stream().map(od -> new PGCalendar(od.getOtherDate())).collect(Collectors.toList());
    }

    @Transient
    public @NotNull List<Date> getOtherPeriodDatesAsDates() {
        return getOtherPeriodDates().stream().map(OtherPeriodDatesEntity::getOtherDate).collect(Collectors.toList());
    }

    @Transient
    public List<PeriodEntity> getPeriods() {
        return find(PeriodEntity.class, "periodDate");
    }

    @Transient
    public List<RecurringPaymentEntity> getRecurringPayments() {
        return find(RecurringPaymentEntity.class);
    }

    @Override
    public @NotNull State getState() {
        return Objects.requireNonNullElse(super.getState(), State.INACTIVE);
    }

    private @NotNull BigDecimal createNewBudgetPeriod(@NotNull PGCalendar periodDate, BigDecimal rollOver, @NotNull List<IncomeSourceEntity> incomes, @NotNull List<RecurringPaymentEntity> payments) {
        List<IncomeSourceEntity>     pIncomes  = incomes.stream().filter(i -> i.isInRange(periodDate)).collect(Collectors.toList());
        List<RecurringPaymentEntity> pPayments = payments.stream().filter(p -> p.isInRange(periodDate)).collect(Collectors.toList());
        List<PeriodItemEntity>       pItems    = pPayments.stream().map(p -> PeriodItemEntity.createNewPeriodItem(periodDate, p)).collect(Collectors.toList());
        BigDecimal                   income    = PGCollections.bigDecimalSum(pIncomes, IncomeSourceEntity::getAmount);
        BigDecimal                   debit     = PGCollections.bigDecimalSum(pPayments, RecurringPaymentEntity::getAmount);
        BigDecimal                   remaining = income.add(rollOver).subtract(debit);
        PeriodEntity                 period    = PeriodEntity.createPeriodEntity(this, periodDate.getTime(), income, rollOver, debit, remaining);

        period.saveChanges();
        pItems.forEach(item -> item.setToPeriod(period));
        pItems.forEach(PeriodItemEntity::saveChanges);

        return remaining;
    }

    private @NotNull List<PeriodEntity> createNextPeriods(@NotNull BigDecimal rollOverAmount, @NotNull Foo delegate) {
        List<PeriodEntity>           out        = new ArrayList<>();
        PeriodEntity                 prevPeriod = getLastPeriod();
        PGCalendar                   periodDate = getNextPeriodDate(prevPeriod);
        BigDecimal                   rollOver   = ((prevPeriod == null) ? rollOverAmount : prevPeriod.getRemainingAmount());
        List<IncomeSourceEntity>     incomes    = getIncomeSources();
        List<RecurringPaymentEntity> payments   = getRecurringPayments();
        int                          i          = 0;

        while(!delegate.isDone(i++, periodDate)) {
            rollOver = createNewBudgetPeriod(periodDate, rollOver, incomes, payments);
            periodDate = getNextPeriodDate(periodDate);
        }

        return out;
    }

    private <T extends JpaBase> @NotNull List<T> find(@NotNull Class<T> entityClass, String... sortBy) {
        return find(entityClass, Integer.MAX_VALUE, sortBy);
    }

    private <T extends JpaBase> @NotNull List<T> find(@NotNull Class<T> entityClass, int maxRecords, String... sortBy) {
        return HibernateUtil.find(entityClass, wrap("state", "toBudget"), wrap(State.ACTIVE, this), sortBy);
    }

    @Transient
    private @NotNull PGCalendar getInitialPeriodDate() {
        switch(getPeriodType()) {
            case OTHER: {
                List<PGCalendar> otherDates = getOtherPeriodDatesAsCalendar();
                if(otherDates.size() == 0) throw new PGBudgetDBException(msgs.getString("msg.err.no_active_period_dates"));

                PGCalendar budgetStart = new PGCalendar(getStartingDate());

                for(PGCalendar od : otherDates) {
                    od.setYear(budgetStart.getYear());
                    if(budgetStart.after(od)) od.addYears(1);
                    else return od;
                }
                return otherDates.get(0);
            }
            case MONTHLY: {
                PGCalendar k = new PGCalendar(getStartingDate());
                PGCalendar c = k.clone();
                c.setDate(getPeriodDate1());
                if(k.after(c)) c.addMonths(1);
                return c;
            }
            case WEEKLY: {
                PGCalendar k  = new PGCalendar(getStartingDate());
                PGCalendar c  = k.clone();
                int        pd = getPeriodDate1();

                if(pd < 1) throw new PGBudgetDBException(msgs.format("msg.err.invalid_weekday", pd, "< 1"));
                if(pd > 7) throw new PGBudgetDBException(msgs.format("msg.err.invalid_weekday", pd, "> 7"));

                while(c.getDayOfWeek() != getPeriodDate1()) c.addDays(1);
                return c;
            }
            case BIWEEKLY: {
                return new PGCalendar(getStartingDate());
            }
            case TWICE_MONTHLY: {
                PGCalendar k  = new PGCalendar(getStartingDate());
                PGCalendar c1 = k.clone();
                PGCalendar c2 = k.clone();

                c1.setDate(getPeriodDate1());
                c2.setDate(getPeriodDate2());
                if(k.compareTo(c1) <= 0) return c1;
                if(k.compareTo(c2) <= 0) return c2;
                c1.addMonths(1);
                return c1;
            }
            default:
                throw new PGBudgetDBException(msgs.getString("validate.budget.period.bad_period_type"));
        }
    }

    private @NotNull PGCalendar getNextPeriodDate(@NotNull PGCalendar date) {
        PGCalendar cal = date.clone();

        switch(getPeriodType()) {
            case TWICE_MONTHLY: {
                if(cal.getDate() == getPeriodDate1()) {
                    cal.setDate(getPeriodDate2());
                }
                else {
                    cal.setDate(getPeriodDate1());
                    cal.addMonths(1);
                }
                return cal;
            }
            case MONTHLY: {
                cal.addMonths(1);
                return cal;
            }
            case WEEKLY: {
                cal.addDays(7);
                return cal;
            }
            case BIWEEKLY: {
                cal.addDays(14);
                return cal;
            }
            default: { // OTHER
                List<PGCalendar> otherDates = getOtherPeriodDatesAsCalendar();
                if(otherDates.size() == 0) throw new PGBudgetDBException(msgs.getString("msg.err.no_active_period_dates"));

                for(int i = 0, j = otherDates.size(); i < j; i++) {
                    PGCalendar od = otherDates.get(i);
                    od.setYear(cal.getYear());

                    if(cal.after(od)) od.addYears(1);
                    else if(cal.equals(od)) return otherDates.get((i + 1) % j);
                    else if(cal.before(od)) return od;
                }
                return otherDates.get(0);
            }
        }
    }

    private @NotNull PGCalendar getNextPeriodDate(@Nullable PeriodEntity prevPeriod) {
        return ((prevPeriod == null) ? getInitialPeriodDate() : PGCalendar.getInstance(getNextPeriodDate(prevPeriod.getPeriodDate())));
    }

    private @NotNull PGCalendar getStopDate(Date stop) {
        Date distantFuture = Dates.distantFuture().getTime();
        return new PGCalendar(Dates.min(Objects.requireNonNullElse(stop, distantFuture), Objects.requireNonNullElse(getEndingDate(), distantFuture)));
    }

    public static @NotNull BudgetEntity createNewBudget(@NotNull UsersEntity user,
                                                        @NotNull String name,
                                                        @NotNull PeriodType periodType,
                                                        @NotNull Date startDate,
                                                        int periodDate,
                                                        WeekDay periodWeekDay,
                                                        int twiceMonthlyDate1,
                                                        int twiceMonthlyDate2,
                                                        List<Date> oDates) {
        List<OtherPeriodDatesEntity> list   = new ArrayList<>();
        BudgetEntity                 budget = new BudgetEntity(false);

        budget.setName(name);
        budget.setStartingDate(Dates.toSQLDate(startDate));
        budget.setPeriodType(periodType);
        budget.setToUser(user);
        budget.setToKeyValueInfo(KvInfoEntity.getNewEntity());

        switch(periodType) {
            case MONTHLY:
                budget.setPeriodDate1(periodDate);
                budget.setPeriodDate2(null);
                break;
            case WEEKLY:
                budget.setPeriodDate1(periodWeekDay.getId());
                budget.setPeriodDate2(null);
                break;
            case TWICE_MONTHLY:
                budget.setPeriodDate1(Math.min(twiceMonthlyDate1, twiceMonthlyDate2));
                budget.setPeriodDate2(Math.max(twiceMonthlyDate1, twiceMonthlyDate2));
                break;
            case BIWEEKLY:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);
                break;
            case OTHER:
                budget.setPeriodDate1(null);
                budget.setPeriodDate2(null);

                for(Date otherDate : oDates) {
                    OtherPeriodDatesEntity otherPeriodDate = OtherPeriodDatesEntity.getNewEntity();
                    otherPeriodDate.setOtherDate(Dates.toSQLDate(otherDate));
                    list.add(otherPeriodDate);
                }

                break;
            default:
                break;
        }

        budget.saveChanges();

        for(OtherPeriodDatesEntity o : list) {
            o.setToBudget(budget);
            o.saveChanges();
        }

        return budget;
    }

    public static @NotNull ValidationResponse validateBudgetData(String budgetName, PeriodType periodType, Date startDate, WeekDay weekDay, int date, int date1, int date2, List<Date> otherDates) {
        if(U.z(U.tr(budgetName))) return new ValidationResponse(msgs.getString("validate.budget.budget_name_required"));
        if(periodType == null) return new ValidationResponse(msgs.getString("validate.budget.period.period_type_required"));
        if(startDate == null) return new ValidationResponse(msgs.getString("validate.budget.start_date_required"));
        return validatePeriodTypeData(periodType, weekDay, date, date1, date2, otherDates);
    }

    public static @NotNull ValidationResponse validatePeriodTypeData(@NotNull PeriodType periodType, @Nullable WeekDay weekDay, int date, int date1, int date2, @NotNull List<Date> otherDates) {
        switch(periodType) {/*@f0*/
            case MONTHLY:       return new ValidationResponse(!(date <= 0), msgs.getString("validate.budget.period.pay_date_required"));
            case WEEKLY:        return new ValidationResponse(!(weekDay == null), msgs.getString("validate.budget.period.weekday_required"));
            case BIWEEKLY:      return new ValidationResponse();
            case TWICE_MONTHLY: return new ValidationResponse(!((date1 <= 0) || (date2 <= 0)), msgs.getString("validate.budget.period.2x_dates_required"));
            case OTHER:         return new ValidationResponse(!(otherDates.size() == 0), msgs.getString("validate.budget.period.other_period_date_required"));
            default:            return new ValidationResponse(msgs.getString("validate.budget.period.bad_period_type"));
        }/*@f1*/
    }

    private interface Foo {
        boolean isDone(int numberCreated, PGCalendar periodDate);
    }
}
