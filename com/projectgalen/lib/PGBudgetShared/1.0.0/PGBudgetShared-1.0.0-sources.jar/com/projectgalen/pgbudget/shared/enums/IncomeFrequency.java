package com.projectgalen.pgbudget.shared.enums;

public enum IncomeFrequency {

    Daily(1), Weekly(2), BiWeekly(3), TwiceMonthly(4), Monthly(4);

    private final short frequency;

    IncomeFrequency(int frequency) {
        this.frequency = (short)frequency;
    }

    public short getFrequency() {
        return this.frequency;
    }
}
