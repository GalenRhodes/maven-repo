package com.projectgalen.pgbudget.shared.enums;

public enum BankAccountType {

    Checking(1), Savings(2), Investment(3), PayPal(4), ApplePay(5), Other(-1);

    private final short type;

    BankAccountType(int type) {
        this.type = (short)type;
    }

    public short getType() {
        return type;
    }
}
