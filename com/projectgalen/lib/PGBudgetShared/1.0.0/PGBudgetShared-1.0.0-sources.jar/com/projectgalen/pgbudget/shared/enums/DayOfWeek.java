package com.projectgalen.pgbudget.shared.enums;

import com.projectgalen.lib.utils.PGResourceBundle;
import org.jetbrains.annotations.NotNull;

public enum DayOfWeek {

    Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday;

    private static final PGResourceBundle msgs = PGResourceBundle.getSharedBundle("com.projectgalen.pgbudget.shared.Messages");

    public byte getDow() {
        return (byte)(ordinal() + 1);
    }

    public @NotNull String longName() {
        return msgs.format("info.days.long.%d", ordinal() + 1);
    }

    public @NotNull String shortName() {
        return msgs.format("info.days.short.%d", ordinal() + 1);
    }
}
