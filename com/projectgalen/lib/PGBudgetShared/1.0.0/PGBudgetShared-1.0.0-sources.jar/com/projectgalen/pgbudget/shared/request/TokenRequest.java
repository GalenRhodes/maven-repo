package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "token" })
public class TokenRequest {

    @JsonProperty("token") protected String token;

    public TokenRequest() {
    }

    public TokenRequest(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override public int hashCode() {
        return Objects.hash(token);
    }

    @Override public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof TokenRequest)) return false;
        TokenRequest that = (TokenRequest)o;
        return Objects.equals(token, that.token);
    }
}
