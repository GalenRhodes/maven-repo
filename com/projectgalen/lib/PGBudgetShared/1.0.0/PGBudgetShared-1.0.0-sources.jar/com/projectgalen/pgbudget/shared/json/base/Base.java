package com.projectgalen.pgbudget.shared.json.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.projectgalen.lib.utils.annotations.PGJSON;

import java.util.Objects;

@PGJSON
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Base {

    protected @JsonProperty("isNew")   boolean isNew;
    protected @JsonProperty("isDirty") boolean isDirty;

    public Base() {
    }

    public @JsonIgnore boolean isDirty() {
        return isDirty;
    }

    public @JsonIgnore void setDirty(boolean dirty) {
        isDirty = dirty;
    }

    public @JsonIgnore boolean isNew() {
        return isNew;
    }

    public @JsonIgnore void setNew(boolean aNew) {
        isNew = aNew;
    }

    @Override public boolean equals(Object o) {
        return ((this == o) || ((o instanceof Base) && _equals((Base)o)));
    }

    private boolean _equals(Base base) {
        return ((isNew == base.isNew) && (isDirty == base.isDirty));
    }

    @Override public int hashCode() {
        return Objects.hash(isNew, isDirty);
    }
}
