package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.lib.utils.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.json.base.Base;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.LoginHistoryEntity", idField = "pkey")
@JsonPropertyOrder({ "pkey", "pkeyUser", "dateLogin", "user", "clientSessions" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
public class LoginHistoryEntity extends Base {

    protected @JsonProperty("pkey")                                                                                           long                      pkey;
    protected @JsonProperty("pkeyUser")                                                                                       long                      pkeyUser;
    protected @JsonProperty("dateLogin") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp                 dateLogin;
    protected @JsonProperty("user")                                                                                           UsersEntity               user;
    protected @JsonProperty("clientSessions")                                                                                 List<ClientSessionEntity> clientSessions;

    public LoginHistoryEntity() {
    }

    public List<ClientSessionEntity> getClientSessions() {
        return clientSessions;
    }

    public void setClientSessions(List<ClientSessionEntity> clientSessions) {
        this.clientSessions = clientSessions;
    }

    public Timestamp getDateLogin() {
        return dateLogin;
    }

    public void setDateLogin(Timestamp dateLogin) {
        this.dateLogin = dateLogin;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyUser() {
        return pkeyUser;
    }

    public void setPkeyUser(long pkeyUser) {
        this.pkeyUser = pkeyUser;
    }

    public UsersEntity getUser() {
        return user;
    }

    public void setUser(UsersEntity user) {
        this.user = user;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyUser, dateLogin, user, clientSessions);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof LoginHistoryEntity) && _equals((LoginHistoryEntity)o));
    }

    private boolean _equals(@NotNull LoginHistoryEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyUser, other.pkeyUser) &&
               Objects.equals(dateLogin, other.dateLogin) &&
               Objects.equals(user, other.user) &&
               Objects.equals(clientSessions, other.clientSessions);
    }
}
