package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Date;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "username", "password", "firstName", "middleName", "lastName", "email", "phone", "stateOfResidence", "dateOfBirth" })
public class CreateUser {
    protected @JsonProperty("username")                                                                              String username;
    protected @JsonProperty("password")                                                                              String password;
    protected @JsonProperty("firstName")                                                                             String firstName;
    protected @JsonProperty("lastName")                                                                              String lastName;
    protected @JsonProperty("middleName")                                                                            String middleName;
    protected @JsonProperty("email")                                                                                 String email;
    protected @JsonProperty("phone")                                                                                 String phone;
    protected @JsonProperty("stateOfResidence")                                                                      String stateOfResidence;
    protected @JsonProperty("dateOfBirth") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z") Date   dateOfBirth;

    public CreateUser() {
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStateOfResidence() {
        return stateOfResidence;
    }

    public void setStateOfResidence(String stateOfResidence) {
        this.stateOfResidence = stateOfResidence;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public @Override
    int hashCode() {
        return Objects.hash(username, password, firstName, lastName, middleName, email, phone, stateOfResidence, dateOfBirth);
    }

    public @Override
    boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof CreateUser)) return false;
        CreateUser that = (CreateUser)o;
        return super.equals(o) &&
               Objects.equals(username, that.username) &&
               Objects.equals(password, that.password) &&
               Objects.equals(firstName, that.firstName) &&
               Objects.equals(lastName, that.lastName) &&
               Objects.equals(middleName, that.middleName) &&
               Objects.equals(email, that.email) &&
               Objects.equals(phone, that.phone) &&
               Objects.equals(stateOfResidence, that.stateOfResidence) &&
               Objects.equals(dateOfBirth, that.dateOfBirth);
    }
}
