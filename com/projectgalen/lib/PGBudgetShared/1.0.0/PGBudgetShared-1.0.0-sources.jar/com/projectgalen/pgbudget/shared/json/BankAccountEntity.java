package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.enums.BankAccountType;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyUser", "dateCreated", "dateUpdated", "status", "name", "balance", "type", "user", "ledgerItems" })
public class BankAccountEntity {

    protected @JsonProperty("pkey")                                                                                             long                   pkey;
    protected @JsonProperty("pkeyUser")                                                                                         long                   pkeyUser;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                   dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                   dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus           status;
    protected @JsonProperty("name")                                                                                             String                 name;
    protected @JsonProperty("balance")                                                                                          BigDecimal             balance;
    protected @JsonProperty("type")                                                                                             BankAccountType        type;
    protected @JsonProperty("user") @JsonBackReference                                                                          UsersEntity            user;
    protected @JsonProperty("ledgerItems") @JsonManagedReference                                                                List<LedgerItemEntity> ledgerItems;

    public BankAccountEntity() {
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public List<LedgerItemEntity> getLedgerItems() {
        return ledgerItems;
    }

    public void setLedgerItems(List<LedgerItemEntity> ledgerItems) {
        this.ledgerItems = ledgerItems;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyUser() {
        return pkeyUser;
    }

    public void setPkeyUser(long pkeyUser) {
        this.pkeyUser = pkeyUser;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public BankAccountType getType() {
        return type;
    }

    public void setType(BankAccountType type) {
        this.type = type;
    }

    public UsersEntity getUser() {
        return user;
    }

    public void setUser(UsersEntity user) {
        this.user = user;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyUser, dateCreated, dateUpdated, status, name, balance, type, user, ledgerItems);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof BankAccountEntity) && _equals((BankAccountEntity)o));
    }

    private boolean _equals(@NotNull BankAccountEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyUser, other.pkeyUser) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(balance, other.balance) &&
               Objects.equals(type, other.type) &&
               Objects.equals(user, other.user) &&
               Objects.equals(ledgerItems, other.ledgerItems);
    }
}
