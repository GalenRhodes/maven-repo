package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.annotations.PGJSON;
import com.projectgalen.pgbudget.shared.enums.DayOfWeek;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/*@f:0*/@PGJSON
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyBudget", "dateCreated", "dateUpdated", "status", "name", "dateStarted", "dateEnded", "frequency", "daysOfMonth", "dayOfWeek", "amount", "budget", "ledgerIncomes" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.IncomeSourceEntity", idField = "pkey", fieldNames = { "pkey", "pkeyBudget", "dateCreated", "dateUpdated", "status", "name", "dateStarted", "dateEnded", "frequency", "daysOfMonth", "dayOfWeek", "amount", "budget", "ledgerIncomes" })
/*@f:1*/ public class IncomeSourceEntity {

    protected @JsonProperty("pkey")                                                                                             long                     pkey;
    protected @JsonProperty("pkeyBudget")                                                                                       long                     pkeyBudget;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp                dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp                dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus             status;
    protected @JsonProperty("name")                                                                                             String                   name;
    protected @JsonProperty("dateStarted") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z")            Date                     dateStarted;
    protected @JsonProperty("dateEnded") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z")              Date                     dateEnded;
    protected @JsonProperty("frequency")                                                                                        short                    frequency;
    protected @JsonProperty("daysOfMonth")                                                                                      Set<Byte>                daysOfMonth;
    protected @JsonProperty("dayOfWeek")                                                                                        DayOfWeek                dayOfWeek;
    protected @JsonProperty("amount")                                                                                           BigDecimal               amount;
    protected @JsonProperty("budget")                                                                                           BudgetEntity             budget;
    protected @JsonProperty("ledgerIncomes")                                                                                    List<LedgerIncomeEntity> ledgerIncomes;

    public IncomeSourceEntity() {
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BudgetEntity getBudget() {
        return budget;
    }

    public void setBudget(BudgetEntity budget) {
        this.budget = budget;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateEnded() {
        return dateEnded;
    }

    public void setDateEnded(Date dateEnded) {
        this.dateEnded = dateEnded;
    }

    public Date getDateStarted() {
        return dateStarted;
    }

    public void setDateStarted(Date dateStarted) {
        this.dateStarted = dateStarted;
    }

    public Timestamp getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Timestamp dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public DayOfWeek getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(DayOfWeek dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public Set<Byte> getDaysOfMonth() {
        return daysOfMonth;
    }

    public void setDaysOfMonth(Set<Byte> daysOfMonth) {
        this.daysOfMonth = daysOfMonth;
    }

    public short getFrequency() {
        return frequency;
    }

    public void setFrequency(short frequency) {
        this.frequency = frequency;
    }

    public List<LedgerIncomeEntity> getLedgerIncomes() {
        return ledgerIncomes;
    }

    public void setLedgerIncomes(List<LedgerIncomeEntity> ledgerIncomes) {
        this.ledgerIncomes = ledgerIncomes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyBudget() {
        return pkeyBudget;
    }

    public void setPkeyBudget(long pkeyBudget) {
        this.pkeyBudget = pkeyBudget;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyBudget, dateCreated, dateUpdated, status, name, dateStarted, dateEnded, frequency, daysOfMonth, dayOfWeek, amount, budget, ledgerIncomes);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof IncomeSourceEntity) && _equals((IncomeSourceEntity)o));
    }

    private boolean _equals(@NotNull IncomeSourceEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyBudget, other.pkeyBudget) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(dateStarted, other.dateStarted) &&
               Objects.equals(dateEnded, other.dateEnded) &&
               Objects.equals(frequency, other.frequency) &&
               Objects.equals(daysOfMonth, other.daysOfMonth) &&
               Objects.equals(dayOfWeek, other.dayOfWeek) &&
               Objects.equals(amount, other.amount) &&
               Objects.equals(budget, other.budget) &&
               Objects.equals(ledgerIncomes, other.ledgerIncomes);
    }
}
