package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "username", "password" })
public class Login {
    protected @JsonProperty("username") String username;
    protected @JsonProperty("password") String password;

    public Login() {
    }

    public Login(@NotNull String username, @NotNull String password) {
        this.username = username;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public @Override
    int hashCode() {
        return Objects.hash(username, password);
    }

    public @Override
    boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Login)) return false;
        Login login = (Login)o;
        return Objects.equals(username, login.username) && Objects.equals(password, login.password);
    }
}
