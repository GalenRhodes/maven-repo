package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.annotations.PGDoppelganger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Date;
import java.util.Objects;

/*@f:0*/@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sessionId", "pkeyUser", "pkeyLoginHistory", "dateCreated", "symmetricKey", "iv", "user", "loginHistory" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "sessionId")
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.ClientSessionEntity", idField = "sessionId", fieldNames = { "sessionId", "pkeyUser", "pkeyLoginHistory", "dateCreated", "symmetricKey", "iv", "user", "loginHistory" })
/*@f:1*/ public class ClientSessionEntity {

    protected @JsonProperty("sessionId")                                                                                        String             sessionId;
    protected @JsonProperty("pkeyUser")                                                                                         Long               pkeyUser;
    protected @JsonProperty("pkeyLoginHistory")                                                                                 Long               pkeyLoginHistory;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date               dateCreated;
    protected @JsonProperty("symmetricKey")                                                                                     String             symmetricKey;
    protected @JsonProperty("iv")                                                                                               String             iv;
    protected @JsonProperty("user")                                                                                             UsersEntity        user;
    protected @JsonProperty("loginHistory")                                                                                     LoginHistoryEntity loginHistory;

    public ClientSessionEntity() {
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getIv() {
        return iv;
    }

    public void setIv(String iv) {
        this.iv = iv;
    }

    public LoginHistoryEntity getLoginHistory() {
        return loginHistory;
    }

    public void setLoginHistory(LoginHistoryEntity loginHistory) {
        this.loginHistory = loginHistory;
    }

    public Long getPkeyLoginHistory() {
        return pkeyLoginHistory;
    }

    public void setPkeyLoginHistory(Long pkeyLoginHistory) {
        this.pkeyLoginHistory = pkeyLoginHistory;
    }

    public Long getPkeyUser() {
        return pkeyUser;
    }

    public void setPkeyUser(Long pkeyUser) {
        this.pkeyUser = pkeyUser;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSymmetricKey() {
        return symmetricKey;
    }

    public void setSymmetricKey(String symmetricKey) {
        this.symmetricKey = symmetricKey;
    }

    public UsersEntity getUser() {
        return user;
    }

    public void setUser(UsersEntity user) {
        this.user = user;
    }

    public @Override int hashCode() {
        return Objects.hash(sessionId, pkeyUser, pkeyLoginHistory, dateCreated, symmetricKey, iv, user, loginHistory);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof ClientSessionEntity) && _equals((ClientSessionEntity)o));
    }

    private boolean _equals(@NotNull ClientSessionEntity other) {
        return Objects.equals(sessionId, other.sessionId) &&
               Objects.equals(pkeyUser, other.pkeyUser) &&
               Objects.equals(pkeyLoginHistory, other.pkeyLoginHistory) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(symmetricKey, other.symmetricKey) &&
               Objects.equals(iv, other.iv) &&
               Objects.equals(user, other.user) &&
               Objects.equals(loginHistory, other.loginHistory);
    }
}
