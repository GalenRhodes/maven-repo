package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.lib.utils.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.json.base.Base;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Timestamp;
import java.util.Objects;

@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.ClientSessionEntity", idField = "sessionId")
@JsonPropertyOrder({ "sessionId", "pkeyLoginHistory", "dateCreated", "lastPingTime", "symmetricKey", "iv", "loginHistory" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "sessionId")
public class ClientSessionEntity extends Base {

    protected @JsonProperty("sessionId")                                                                                         String             sessionId;
    protected @JsonProperty("pkeyLoginHistory")                                                                                  Long               pkeyLoginHistory;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")  Timestamp          dateCreated;
    protected @JsonProperty("lastPingTime") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp          lastPingTime;
    protected @JsonProperty("symmetricKey")                                                                                      String             symmetricKey;
    protected @JsonProperty("iv")                                                                                                String             iv;
    protected @JsonProperty("loginHistory")                                                                                      LoginHistoryEntity loginHistory;

    public ClientSessionEntity() {
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getIv() {
        return iv;
    }

    public void setIv(String iv) {
        this.iv = iv;
    }

    public Timestamp getLastPingTime() {
        return lastPingTime;
    }

    public void setLastPingTime(Timestamp lastPingTime) {
        this.lastPingTime = lastPingTime;
    }

    public LoginHistoryEntity getLoginHistory() {
        return loginHistory;
    }

    public void setLoginHistory(LoginHistoryEntity loginHistory) {
        this.loginHistory = loginHistory;
    }

    public Long getPkeyLoginHistory() {
        return pkeyLoginHistory;
    }

    public void setPkeyLoginHistory(Long pkeyLoginHistory) {
        this.pkeyLoginHistory = pkeyLoginHistory;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSymmetricKey() {
        return symmetricKey;
    }

    public void setSymmetricKey(String symmetricKey) {
        this.symmetricKey = symmetricKey;
    }

    public @Override int hashCode() {
        return Objects.hash(sessionId, pkeyLoginHistory, dateCreated, lastPingTime, symmetricKey, iv, loginHistory);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof ClientSessionEntity) && _equals((ClientSessionEntity)o));
    }

    private boolean _equals(@NotNull ClientSessionEntity other) {
        return Objects.equals(sessionId, other.sessionId) &&
               Objects.equals(pkeyLoginHistory, other.pkeyLoginHistory) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(lastPingTime, other.lastPingTime) &&
               Objects.equals(symmetricKey, other.symmetricKey) &&
               Objects.equals(iv, other.iv) &&
               Objects.equals(loginHistory, other.loginHistory);
    }
}
