package com.projectgalen.pgbudget.shared.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.projectgalen.lib.utils.PGResourceBundle;
import com.projectgalen.lib.utils.U;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "code", "severity", "name", "message" })
public class SvcError {
    private static final PGResourceBundle errors = PGResourceBundle.getSharedBundle("com.projectgalen.pgbudget.svc.rest.Errors");

    protected @JsonProperty("code") @NotNull     String   code;
    protected @JsonProperty("name") @NotNull     String   name;
    protected @JsonProperty("message") @NotNull  String   message;
    protected @JsonProperty("severity") @NotNull Severity severity;

    public SvcError(@Nullable Severity severity, @NotNull String code, Object... args) {
        super();
        this.severity = U.ifNull(severity, Severity.INFO);
        this.code     = code;
        this.name     = errors.getString(code + "-Name");
        this.message  = errors.format(code + "-Desc", args);
    }

    public @NotNull String getCode() {
        return code;
    }

    public @NotNull String getMessage() {
        return message;
    }

    public @NotNull String getName() {
        return name;
    }

    public @Override int hashCode() {
        return Objects.hash(code, name, message);
    }

    public @Override boolean equals(Object o) {
        return ((this == o) || ((o instanceof SvcError) && _equals((SvcError)o)));
    }

    public @Override
    String toString() {
        return String.format("[%s][%s][%s] - %s", code, severity, name, message);
    }

    private boolean _equals(@NotNull SvcError o) {
        return (code.equals(o.code) && name.equals(o.name) && message.equals(o.message));
    }

    public enum Severity {
        INFO, WARN, ERROR
    }
}
