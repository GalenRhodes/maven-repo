package com.projectgalen.pgbudget.shared.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.projectgalen.pgbudget.shared.json.UsersEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "token", "error", "user" })
@JsonRootName("Response")
public class Response {

    protected @JsonProperty("token") @Nullable Token       token;
    protected @JsonProperty("error") @Nullable SvcError    error;
    protected @JsonProperty("status") @NotNull String      status;
    protected @JsonProperty("user") @Nullable  UsersEntity user;

    public Response() {
        this.status = "N/A";
    }

    public @Nullable SvcError getError() {
        return error;
    }

    public void setError(@Nullable SvcError error) {
        this.error = error;
    }

    public @NotNull String getStatus() {
        return status;
    }

    public void setStatus(@NotNull String status) {
        this.status = status;
    }

    public @Nullable Token getToken() {
        return token;
    }

    public void setToken(@Nullable Token token) {
        this.token = token;
    }

    public @Nullable UsersEntity getUser() {
        return user;
    }

    public void setUser(@Nullable UsersEntity user) {
        this.user = user;
    }

    public @Override int hashCode() {
        return Objects.hash(token, error);
    }

    public @Override boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof Response) && _equals((Response)o)));
    }

    private boolean _equals(@NotNull Response r) {
        return (Objects.equals(token, r.token) && Objects.equals(error, r.error) && Objects.equals(status, r.status) && Objects.equals(user, r.user));
    }
}
