package com.projectgalen.pgbudget.shared.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response {

    @JsonProperty("token") @Nullable protected Token    token;
    @JsonProperty("error") @Nullable protected SvcError error;
    @JsonProperty("status") protected          String   status;

    public Response() {
    }

    public @Nullable SvcError getError() {
        return error;
    }

    public void setError(@Nullable SvcError error) {
        this.error = error;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public @Nullable Token getToken() {
        return token;
    }

    public void setToken(@Nullable Token token) {
        this.token = token;
    }

    public @Override int hashCode() {
        return Objects.hash(token, error);
    }

    public @Override boolean equals(@Nullable Object o) {
        return ((this == o) || ((o instanceof Response) && _equals((Response)o)));
    }

    private boolean _equals(@NotNull Response r) {
        return Objects.equals(token, r.token) && Objects.equals(error, r.error);
    }
}
