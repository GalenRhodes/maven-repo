package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.lib.utils.annotations.PGDoppelganger;
import com.projectgalen.lib.utils.annotations.PGJSON;
import com.projectgalen.pgbudget.shared.enums.Months;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

@PGJSON
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.RecurringItemEntity", idField = "pkey")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyBudget", "dateCreated", "dateUpdated", "status", "name", "amount", "recurringMonth", "recurringDate", "dateStarts", "dateEnds", "budget" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
public class RecurringItemEntity {

    protected @JsonProperty("pkey")                                                                                             long         pkey;
    protected @JsonProperty("pkeyBudget")                                                                                       long         pkeyBudget;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp    dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp    dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus status;
    protected @JsonProperty("name")                                                                                             String       name;
    protected @JsonProperty("amount")                                                                                           BigDecimal   amount;
    protected @JsonProperty("recurringMonth")                                                                                   Months       recurringMonth;
    protected @JsonProperty("recurringDate")                                                                                    Byte         recurringDate;
    protected @JsonProperty("dateStarts") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z")             Date         dateStarts;
    protected @JsonProperty("dateEnds") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z")               Date         dateEnds;
    protected @JsonProperty("budget")                                                                                           BudgetEntity budget;

    public RecurringItemEntity() {
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BudgetEntity getBudget() {
        return budget;
    }

    public void setBudget(BudgetEntity budget) {
        this.budget = budget;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateEnds() {
        return dateEnds;
    }

    public void setDateEnds(Date dateEnds) {
        this.dateEnds = dateEnds;
    }

    public Date getDateStarts() {
        return dateStarts;
    }

    public void setDateStarts(Date dateStarts) {
        this.dateStarts = dateStarts;
    }

    public Timestamp getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Timestamp dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyBudget() {
        return pkeyBudget;
    }

    public void setPkeyBudget(long pkeyBudget) {
        this.pkeyBudget = pkeyBudget;
    }

    public Byte getRecurringDate() {
        return recurringDate;
    }

    public void setRecurringDate(Byte recurringDate) {
        this.recurringDate = recurringDate;
    }

    public Months getRecurringMonth() {
        return recurringMonth;
    }

    public void setRecurringMonth(Months recurringMonth) {
        this.recurringMonth = recurringMonth;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyBudget, dateCreated, dateUpdated, status, name, amount, recurringMonth, recurringDate, dateStarts, dateEnds, budget);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof RecurringItemEntity) && _equals((RecurringItemEntity)o));
    }

    private boolean _equals(@NotNull RecurringItemEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyBudget, other.pkeyBudget) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(amount, other.amount) &&
               Objects.equals(recurringMonth, other.recurringMonth) &&
               Objects.equals(recurringDate, other.recurringDate) &&
               Objects.equals(dateStarts, other.dateStarts) &&
               Objects.equals(dateEnds, other.dateEnds) &&
               Objects.equals(budget, other.budget);
    }
}
