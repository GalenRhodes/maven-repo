package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.annotations.PGIdentity;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyUser", "dateCreated", "dateUpdated", "status", "name", "user", "incomeSources", "ledgers", "recurringItems" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.BudgetEntity", idField = "pkey", fieldNames = {})
public class BudgetEntity {

    protected @JsonProperty("pkey") @PGIdentity                                                                                 long                      pkey;
    protected @JsonProperty("pkeyUser")                                                                                         long                      pkeyUser;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                      dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                      dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus              status;
    protected @JsonProperty("name")                                                                                             String                    name;
    protected @JsonProperty("user")                                                                                             UsersEntity               user;
    protected @JsonProperty("incomeSources")                                                                                    List<IncomeSourceEntity>  incomeSources;
    protected @JsonProperty("ledgers")                                                                                          List<LedgerEntity>        ledgers;
    protected @JsonProperty("recurringItems")                                                                                   List<RecurringItemEntity> recurringItems;

    public BudgetEntity() {
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public List<IncomeSourceEntity> getIncomeSources() {
        return incomeSources;
    }

    public void setIncomeSources(List<IncomeSourceEntity> incomeSources) {
        this.incomeSources = incomeSources;
    }

    public List<LedgerEntity> getLedgers() {
        return ledgers;
    }

    public void setLedgers(List<LedgerEntity> ledgers) {
        this.ledgers = ledgers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyUser() {
        return pkeyUser;
    }

    public void setPkeyUser(long pkeyUser) {
        this.pkeyUser = pkeyUser;
    }

    public List<RecurringItemEntity> getRecurringItems() {
        return recurringItems;
    }

    public void setRecurringItems(List<RecurringItemEntity> recurringItems) {
        this.recurringItems = recurringItems;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public UsersEntity getUser() {
        return user;
    }

    public void setUser(UsersEntity user) {
        this.user = user;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyUser, dateCreated, dateUpdated, status, name, user, incomeSources, ledgers, recurringItems);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof BudgetEntity) && _equals((BudgetEntity)o));
    }

    private boolean _equals(@NotNull BudgetEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyUser, other.pkeyUser) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(user, other.user) &&
               Objects.equals(incomeSources, other.incomeSources) &&
               Objects.equals(ledgers, other.ledgers) &&
               Objects.equals(recurringItems, other.recurringItems);
    }
}
