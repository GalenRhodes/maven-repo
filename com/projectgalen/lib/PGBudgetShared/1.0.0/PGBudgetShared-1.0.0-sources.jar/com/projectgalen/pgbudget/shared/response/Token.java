package com.projectgalen.pgbudget.shared.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Token {
    @JsonProperty("publicKey") protected @NotNull String publicKey;
    @JsonProperty("iv") protected @NotNull        String iv;
    @JsonProperty("sessionId") protected @NotNull String sessionId;
    @JsonProperty("message") protected @NotNull   String message;

    public Token(@NotNull String publicKey, @NotNull String iv, @NotNull String sessionId, @NotNull String message) {
        this.publicKey = publicKey;
        this.iv        = iv;
        this.sessionId = sessionId;
        this.message   = message;
    }

    public @NotNull String getIv() {
        return iv;
    }

    public void setIv(@NotNull String iv) {
        this.iv = iv;
    }

    public @NotNull String getMessage() {
        return message;
    }

    public @NotNull String getPublicKey() {
        return publicKey;
    }

    public @NotNull String getSessionId() {
        return sessionId;
    }

    public @Override int hashCode() {
        return Objects.hash(publicKey, sessionId, message);
    }

    public @Override boolean equals(Object o) {
        return ((this == o) || ((o instanceof Token) && _equals((Token)o)));
    }

    private boolean _equals(@NotNull Token o) {
        return (publicKey.equals(o.publicKey) && sessionId.equals(o.sessionId) && message.equals(o.message));
    }
}
