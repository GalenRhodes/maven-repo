package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyBudget", "dateCreated", "dateUpdated", "status", "periodDate", "closed", "startAmount", "closeAmount", "budget", "ledgerIncomes", "ledgerItems" })
public class LedgerEntity {

    protected @JsonProperty("pkey")                                                                                             long                     pkey;
    protected @JsonProperty("pkeyBudget")                                                                                       long                     pkeyBudget;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                     dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date                     dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus             status;
    protected @JsonProperty("periodDate") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")  Date                     periodDate;
    protected @JsonProperty("closed")                                                                                           boolean                  closed;
    protected @JsonProperty("startAmount")                                                                                      BigDecimal               startAmount;
    protected @JsonProperty("closeAmount")                                                                                      BigDecimal               closeAmount;
    protected @JsonProperty("budget") @JsonBackReference                                                                        BudgetEntity             budget;
    protected @JsonProperty("ledgerIncomes") @JsonManagedReference                                                              List<LedgerIncomeEntity> ledgerIncomes;
    protected @JsonProperty("ledgerItems") @JsonManagedReference                                                                List<LedgerItemEntity>   ledgerItems;

    public LedgerEntity() {
    }

    public BudgetEntity getBudget() {
        return budget;
    }

    public void setBudget(BudgetEntity budget) {
        this.budget = budget;
    }

    public BigDecimal getCloseAmount() {
        return closeAmount;
    }

    public void setCloseAmount(BigDecimal closeAmount) {
        this.closeAmount = closeAmount;
    }

    public boolean getClosed() {
        return closed;
    }

    public void setClosed(boolean closed) {
        this.closed = closed;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public List<LedgerIncomeEntity> getLedgerIncomes() {
        return ledgerIncomes;
    }

    public void setLedgerIncomes(List<LedgerIncomeEntity> ledgerIncomes) {
        this.ledgerIncomes = ledgerIncomes;
    }

    public List<LedgerItemEntity> getLedgerItems() {
        return ledgerItems;
    }

    public void setLedgerItems(List<LedgerItemEntity> ledgerItems) {
        this.ledgerItems = ledgerItems;
    }

    public Date getPeriodDate() {
        return periodDate;
    }

    public void setPeriodDate(Date periodDate) {
        this.periodDate = periodDate;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyBudget() {
        return pkeyBudget;
    }

    public void setPkeyBudget(long pkeyBudget) {
        this.pkeyBudget = pkeyBudget;
    }

    public BigDecimal getStartAmount() {
        return startAmount;
    }

    public void setStartAmount(BigDecimal startAmount) {
        this.startAmount = startAmount;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyBudget, dateCreated, dateUpdated, status, periodDate, closed, startAmount, closeAmount, budget, ledgerIncomes, ledgerItems);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof LedgerEntity) && _equals((LedgerEntity)o));
    }

    private boolean _equals(@NotNull LedgerEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyBudget, other.pkeyBudget) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(periodDate, other.periodDate) &&
               Objects.equals(closed, other.closed) &&
               Objects.equals(startAmount, other.startAmount) &&
               Objects.equals(closeAmount, other.closeAmount) &&
               Objects.equals(budget, other.budget) &&
               Objects.equals(ledgerIncomes, other.ledgerIncomes) &&
               Objects.equals(ledgerItems, other.ledgerItems);
    }
}
