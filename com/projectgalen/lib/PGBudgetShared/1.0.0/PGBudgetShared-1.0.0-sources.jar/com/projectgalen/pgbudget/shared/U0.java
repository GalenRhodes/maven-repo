package com.projectgalen.pgbudget.shared;

import com.projectgalen.lib.crypto.Crypto;
import com.projectgalen.lib.utils.U;
import org.jetbrains.annotations.NotNull;

import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;

public class U0 {
    private U0() {
    }

    public static @NotNull String getPasswordHash(String password) throws NoSuchAlgorithmException {
        return U.base64Encode(Crypto.createSHA256Digest(password.getBytes(StandardCharsets.UTF_8)));
    }
}
