package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.annotations.PGJSON;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

/*@f:0*/@PGJSON
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "dateCreated", "dateUpdated", "status", "username", "password", "dateLastLogin", "firstName", "middleName", "lastName", "namePrefix", "nameSuffix", "preferredName", "dateOfBirth", "bankAccounts", "budgets", "loginHistory" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.UsersEntity", idField = "pkey", fieldNames = { "pkey", "dateCreated", "dateUpdated", "status", "username", "password", "dateLastLogin", "firstName", "middleName", "lastName", "namePrefix", "nameSuffix", "preferredName", "dateOfBirth", "bankAccounts", "budgets", "loginHistory" })
/*@f:1*/ public class UsersEntity {

    protected @JsonProperty("pkey")                                                                                               long                     pkey;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")   Timestamp                dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")   Timestamp                dateUpdated;
    protected @JsonProperty("status")                                                                                             RecordStatus             status;
    protected @JsonProperty("username")                                                                                           String                   username;
    protected @JsonProperty("password")                                                                                           String                   password;
    protected @JsonProperty("dateLastLogin") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp                dateLastLogin;
    protected @JsonProperty("firstName")                                                                                          String                   firstName;
    protected @JsonProperty("middleName")                                                                                         String                   middleName;
    protected @JsonProperty("lastName")                                                                                           String                   lastName;
    protected @JsonProperty("namePrefix")                                                                                         String                   namePrefix;
    protected @JsonProperty("nameSuffix")                                                                                         String                   nameSuffix;
    protected @JsonProperty("preferredName")                                                                                      String                   preferredName;
    protected @JsonProperty("dateOfBirth") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'TZ'Z")              Date                     dateOfBirth;
    protected @JsonProperty("bankAccounts")                                                                                       List<BankAccountEntity>  bankAccounts;
    protected @JsonProperty("budgets")                                                                                            List<BudgetEntity>       budgets;
    protected @JsonProperty("loginHistory")                                                                                       List<LoginHistoryEntity> loginHistory;

    public UsersEntity() {
    }

    public List<BankAccountEntity> getBankAccounts() {
        return bankAccounts;
    }

    public void setBankAccounts(List<BankAccountEntity> bankAccounts) {
        this.bankAccounts = bankAccounts;
    }

    public List<BudgetEntity> getBudgets() {
        return budgets;
    }

    public void setBudgets(List<BudgetEntity> budgets) {
        this.budgets = budgets;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Timestamp getDateLastLogin() {
        return dateLastLogin;
    }

    public void setDateLastLogin(Timestamp dateLastLogin) {
        this.dateLastLogin = dateLastLogin;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Timestamp getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Timestamp dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<LoginHistoryEntity> getLoginHistory() {
        return loginHistory;
    }

    public void setLoginHistory(List<LoginHistoryEntity> loginHistory) {
        this.loginHistory = loginHistory;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getNamePrefix() {
        return namePrefix;
    }

    public void setNamePrefix(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey,
                            dateCreated,
                            dateUpdated,
                            status,
                            username,
                            password,
                            dateLastLogin,
                            firstName,
                            middleName,
                            lastName,
                            namePrefix,
                            nameSuffix,
                            preferredName,
                            dateOfBirth,
                            bankAccounts,
                            budgets,
                            loginHistory);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof UsersEntity) && _equals((UsersEntity)o));
    }

    private boolean _equals(@NotNull UsersEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(username, other.username) &&
               Objects.equals(password, other.password) &&
               Objects.equals(dateLastLogin, other.dateLastLogin) &&
               Objects.equals(firstName, other.firstName) &&
               Objects.equals(middleName, other.middleName) &&
               Objects.equals(lastName, other.lastName) &&
               Objects.equals(namePrefix, other.namePrefix) &&
               Objects.equals(nameSuffix, other.nameSuffix) &&
               Objects.equals(preferredName, other.preferredName) &&
               Objects.equals(dateOfBirth, other.dateOfBirth) &&
               Objects.equals(bankAccounts, other.bankAccounts) &&
               Objects.equals(budgets, other.budgets) &&
               Objects.equals(loginHistory, other.loginHistory);
    }
}
