package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.lib.utils.annotations.PGDoppelganger;
import com.projectgalen.lib.utils.annotations.PGJSON;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@PGJSON
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.LedgerIncomeEntity", idField = "pkey")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyLedger", "pkeyIncomeSource", "dateCreated", "dateUpdated", "status", "name", "amount", "ledger", "incomeSource" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
public class LedgerIncomeEntity {

    protected @JsonProperty("pkey")                                                                                             long               pkey;
    protected @JsonProperty("pkeyLedger")                                                                                       long               pkeyLedger;
    protected @JsonProperty("pkeyIncomeSource")                                                                                 long               pkeyIncomeSource;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp          dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Timestamp          dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus       status;
    protected @JsonProperty("name")                                                                                             String             name;
    protected @JsonProperty("amount")                                                                                           BigDecimal         amount;
    protected @JsonProperty("ledger")                                                                                           LedgerEntity       ledger;
    protected @JsonProperty("incomeSource")                                                                                     IncomeSourceEntity incomeSource;

    public LedgerIncomeEntity() {
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Timestamp getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Timestamp dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public IncomeSourceEntity getIncomeSource() {
        return incomeSource;
    }

    public void setIncomeSource(IncomeSourceEntity incomeSource) {
        this.incomeSource = incomeSource;
    }

    public LedgerEntity getLedger() {
        return ledger;
    }

    public void setLedger(LedgerEntity ledger) {
        this.ledger = ledger;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public long getPkeyIncomeSource() {
        return pkeyIncomeSource;
    }

    public void setPkeyIncomeSource(long pkeyIncomeSource) {
        this.pkeyIncomeSource = pkeyIncomeSource;
    }

    public long getPkeyLedger() {
        return pkeyLedger;
    }

    public void setPkeyLedger(long pkeyLedger) {
        this.pkeyLedger = pkeyLedger;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyLedger, pkeyIncomeSource, dateCreated, dateUpdated, status, name, amount, ledger, incomeSource);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof LedgerIncomeEntity) && _equals((LedgerIncomeEntity)o));
    }

    private boolean _equals(@NotNull LedgerIncomeEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyLedger, other.pkeyLedger) &&
               Objects.equals(pkeyIncomeSource, other.pkeyIncomeSource) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(amount, other.amount) &&
               Objects.equals(ledger, other.ledger) &&
               Objects.equals(incomeSource, other.incomeSource);
    }
}
