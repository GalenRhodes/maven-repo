package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sessionId", "data", "user" })
@JsonRootName("RequestMain")
public class RequestMain {
    @JsonProperty("sessionId") protected String     sessionId;
    @JsonProperty("data") protected      String     data;
    @JsonProperty("user") protected      CreateUser user;

    public RequestMain() {
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public CreateUser getUser() {
        return user;
    }

    public void setUser(CreateUser user) {
        this.user = user;
    }

    @Override
    public int hashCode() {
        return Objects.hash(sessionId, data, user);
    }

    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof RequestMain)) return false;
        RequestMain that = (RequestMain)o;
        return Objects.equals(sessionId, that.sessionId) && Objects.equals(data, that.data) && Objects.equals(user, that.user);
    }
}
