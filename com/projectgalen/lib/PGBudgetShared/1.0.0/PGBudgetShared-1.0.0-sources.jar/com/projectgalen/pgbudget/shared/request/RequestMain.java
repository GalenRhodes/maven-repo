package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.projectgalen.lib.utils.Dates;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sessionId", "data" })
public class RequestMain {
    protected @JsonProperty("requestTime") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone = "EST") Timestamp requestTime;
    protected @JsonProperty("sessionId")                                 String    sessionId;
    protected @JsonProperty("data")        String    data;

    public RequestMain() {
        this.requestTime = Dates.getTimestamp();
    }

    public RequestMain(@NotNull String sessionId, @NotNull String data) {
        this.requestTime = Dates.getTimestamp();
        this.sessionId   = sessionId;
        this.data        = data;
    }

    public Timestamp getRequestTime() {
        return requestTime;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public @Override
    int hashCode() {
        return Objects.hash(requestTime, sessionId, data);
    }

    public @Override
    boolean equals(Object o) {
        return ((this == o) || ((o instanceof RequestMain) && _equals((RequestMain)o)));
    }

    private boolean _equals(RequestMain other) {
        return Objects.equals(requestTime, other.requestTime) && Objects.equals(sessionId, other.sessionId) && Objects.equals(data, other.data);
    }
}
