package com.projectgalen.pgbudget.shared.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sessionId", "data" })
public class RequestMain {
    @JsonProperty("sessionId") protected String sessionId;
    @JsonProperty("data") protected      String data;

    public RequestMain() {
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(sessionId, data);
    }

    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof RequestMain)) return false;
        RequestMain that = (RequestMain)o;
        return Objects.equals(sessionId, that.sessionId) && Objects.equals(data, that.data);
    }
}
