package com.projectgalen.pgbudget.shared.enums;

import com.projectgalen.lib.utils.PGResourceBundle;

public enum Months {
    January, February, March, April, May, June, July, August, September, October, November, December;

    private static final PGResourceBundle msgs = PGResourceBundle.getSharedBundle("com.projectgalen.pgbudget.svc.rest.Messages");

    public byte getMonth() {
        return (byte)(ordinal() + 1);
    }

    public String longName() {
        return msgs.format("info.months.long.%02d", ordinal() + 1);
    }

    public String shortName() {
        return msgs.format("info.months.short.%02d", ordinal() + 1);
    }
}
