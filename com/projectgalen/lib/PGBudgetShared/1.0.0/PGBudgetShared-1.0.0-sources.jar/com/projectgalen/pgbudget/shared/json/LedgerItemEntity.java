package com.projectgalen.pgbudget.shared.json;

import com.fasterxml.jackson.annotation.*;
import com.projectgalen.pgbudget.shared.annotations.PGDoppelganger;
import com.projectgalen.pgbudget.shared.annotations.PGJSON;
import com.projectgalen.pgbudget.shared.enums.RecordStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/*@f:0*/@PGJSON
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "pkey", "pkeyLedger", "pkeyAccount", "dateCreated", "dateUpdated", "status", "name", "amount", "datePayed", "cleared", "ledger", "bankAccount" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pkey")
@PGDoppelganger(className = "com.projectgalen.pgbudget.svc.rest.jpa.LedgerItemEntity", idField = "pkey", fieldNames = { "pkey", "pkeyLedger", "pkeyAccount", "dateCreated", "dateUpdated", "status", "name", "amount", "datePayed", "cleared", "ledger", "bankAccount" })
/*@f:1*/ public class LedgerItemEntity {

    protected @JsonProperty("pkey")                                                                                             long              pkey;
    protected @JsonProperty("pkeyLedger")                                                                                       long              pkeyLedger;
    protected @JsonProperty("pkeyAccount")                                                                                      Long              pkeyAccount;
    protected @JsonProperty("dateCreated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date              dateCreated;
    protected @JsonProperty("dateUpdated") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ") Date              dateUpdated;
    protected @JsonProperty("status")                                                                                           RecordStatus      status;
    protected @JsonProperty("name")                                                                                             String            name;
    protected @JsonProperty("amount")                                                                                           BigDecimal        amount;
    protected @JsonProperty("datePayed") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd Z")                 java.sql.Date     datePayed;
    protected @JsonProperty("cleared")                                                                                          boolean           cleared;
    protected @JsonProperty("ledger")                                                                                           LedgerEntity      ledger;
    protected @JsonProperty("bankAccount")                                                                                      BankAccountEntity bankAccount;

    public LedgerItemEntity() {
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BankAccountEntity getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(BankAccountEntity bankAccount) {
        this.bankAccount = bankAccount;
    }

    public boolean getCleared() {
        return cleared;
    }

    public void setCleared(boolean cleared) {
        this.cleared = cleared;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public java.sql.Date getDatePayed() {
        return datePayed;
    }

    public void setDatePayed(java.sql.Date datePayed) {
        this.datePayed = datePayed;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public LedgerEntity getLedger() {
        return ledger;
    }

    public void setLedger(LedgerEntity ledger) {
        this.ledger = ledger;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPkey() {
        return pkey;
    }

    public void setPkey(long pkey) {
        this.pkey = pkey;
    }

    public Long getPkeyAccount() {
        return pkeyAccount;
    }

    public void setPkeyAccount(Long pkeyAccount) {
        this.pkeyAccount = pkeyAccount;
    }

    public long getPkeyLedger() {
        return pkeyLedger;
    }

    public void setPkeyLedger(long pkeyLedger) {
        this.pkeyLedger = pkeyLedger;
    }

    public RecordStatus getStatus() {
        return status;
    }

    public void setStatus(RecordStatus status) {
        this.status = status;
    }

    public @Override int hashCode() {
        return Objects.hash(pkey, pkeyLedger, pkeyAccount, dateCreated, dateUpdated, status, name, amount, datePayed, cleared, ledger, bankAccount);
    }

    public @Override boolean equals(@Nullable Object o) {
        return (this == o) || ((o instanceof LedgerItemEntity) && _equals((LedgerItemEntity)o));
    }

    private boolean _equals(@NotNull LedgerItemEntity other) {
        return Objects.equals(pkey, other.pkey) &&
               Objects.equals(pkeyLedger, other.pkeyLedger) &&
               Objects.equals(pkeyAccount, other.pkeyAccount) &&
               Objects.equals(dateCreated, other.dateCreated) &&
               Objects.equals(dateUpdated, other.dateUpdated) &&
               Objects.equals(status, other.status) &&
               Objects.equals(name, other.name) &&
               Objects.equals(amount, other.amount) &&
               Objects.equals(datePayed, other.datePayed) &&
               Objects.equals(cleared, other.cleared) &&
               Objects.equals(ledger, other.ledger) &&
               Objects.equals(bankAccount, other.bankAccount);
    }
}
