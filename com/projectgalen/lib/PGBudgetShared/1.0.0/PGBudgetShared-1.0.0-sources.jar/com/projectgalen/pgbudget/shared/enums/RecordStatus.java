package com.projectgalen.pgbudget.shared.enums;

public enum RecordStatus {
    Active(1), Deleted(-1), Hidden(0), Expired(-2);

    private final byte status;

    RecordStatus(int status) {
        this.status = (byte)status;
    }

    public byte getStatus() {
        return status;
    }
}
